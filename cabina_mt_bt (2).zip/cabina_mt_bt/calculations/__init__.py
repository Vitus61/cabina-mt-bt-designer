"""
Calculations Package - Moduli di Calcolo
Moduli per calcoli carichi e validazioni
Software Cabina MT/BT Professional v2.0
"""

from .loads import LoadCalculator, SimpleLoad
from .validation import (
    validate_distributor_data,
    validate_transformer_config,
    validate_load_data
)

__all__ = [
    'LoadCalculator',
    'SimpleLoad',
    'validate_distributor_data',
    'validate_transformer_config',
    'validate_load_data'
]

__version__ = "1.0.0"
__author__ = "Software Cabina MT/BT Professional"
