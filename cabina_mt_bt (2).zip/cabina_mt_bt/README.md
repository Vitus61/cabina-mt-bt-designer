# ⚡ Software Cabina MT/BT Professional v2.0

**Sistema completo per progettazione di cabine elettriche MT/BT con database ABB Emax 2 integrato**

![Status](https://img.shields.io/badge/Status-Operativo-green)
![Version](https://img.shields.io/badge/Version-2.0-blue)
![Python](https://img.shields.io/badge/Python-3.7+-blue)
![ABB](https://img.shields.io/badge/ABB-Emax%202-red)

## 🚀 AVVIO RAPIDO

### Metodo 1: Script automatico (Raccomandato)

**Linux/macOS:**
```bash
cd /projects/Desktop/cabina_mt_bt
chmod +x run_app.sh
./run_app.sh
```

**Windows:**
```cmd
cd C:\projects\Desktop\cabina_mt_bt
run_app.bat
```

### Metodo 2: Avvio diretto
```bash
cd /projects/Desktop/cabina_mt_bt
streamlit run main.py --server.port=8501
```

### Metodo 3: Script Python avanzato
```bash
cd /projects/Desktop/cabina_mt_bt
python3 scripts/run_app.py
```

## 🧪 TEST SISTEMA

Prima dell'avvio, verifica che tutto funzioni:
```bash
python3 scripts/quick_test.py
```

## 📋 FUNZIONALITÀ PRINCIPALI

### ✅ Core System
- **Step 1:** Dati Distributore (CEI 0-16)
- **Step 2:** Calcolo Carichi Elettrici
- **Step 3:** Dimensionamento Trasformatori ABB
- **Step 3.5:** Sezionatore di Terra (CEI 11-27)
- **Step 4:** Progettazione Quadro MT (UniSec)
- **Step 5:** Coordinamento Protezioni ABB Emax 2
- **Step 6:** Progettazione Quadro BT
- **Step 8:** Impianto di Terra
- **Step 9:** Analisi Finale e Report

### 🔵 Sistema ABB Emax 2 Avanzato
- **Database Completo:** E1.2, E2.2, E4.2, E6.2 (100+ modelli)
- **Selettività Automatica:** Tabelle certificate ABB
- **Coordinamento Energetico:** Calcoli I²t precisi
- **Curve L-S-G:** Visualizzazione curve tempo-corrente
- **Ottimizzazione:** Algoritmi intelligenti per cascate ottimali

### 🏭 Database Prodotti Industriali
- **Trasformatori:** Hi-T Plus, RESIBLOC, ONAN
- **Interruttori MT:** UniSec, Sace Emax
- **Interruttori BT:** Tmax, Emax 2, Formula
- **Sezionatori:** Disconnettori MT/BT
- **Sistemi di Terra:** Calcoli automatici

## 🛠️ REQUISITI SISTEMA

### Requisiti Minimi
- **Python:** 3.7 o superiore
- **RAM:** 4 GB
- **Storage:** 500 MB
- **Browser:** Chrome, Firefox, Safari
- **OS:** Windows 10+, macOS 10.14+, Linux Ubuntu 18.04+

### Dipendenze Python
```txt
streamlit>=1.28.0
pandas>=1.3.0
numpy>=1.21.0
plotly>=5.0.0
```

Installazione automatica:
```bash
pip install -r requirements.txt
```

## 📁 STRUTTURA PROGETTO

```
cabina_mt_bt/
├── 📄 main.py                    # Applicazione principale
├── 📄 run_app.sh/.bat           # Script avvio automatico
├── 📂 abb_database/             # 🔵 Sistema ABB Emax 2
│   ├── abb_python_interface.py  # Interfaccia Python-JavaScript
│   ├── abb_selectivity_system.js # Sistema selettività avanzato
│   └── abb_emax2_curves.js      # Database curve ABB
├── 📂 ui/                       # Interfaccia utente
│   ├── steps.py                 # ⚡ Tutti gli step del processo
│   ├── sidebar.py               # Pannello laterale input
│   └── progress.py              # Barra avanzamento
├── 📂 bt_equipment/             # Apparecchiature BT
├── 📂 mt_equipment/             # Apparecchiature MT
├── 📂 calculations/             # Moduli di calcolo
├── 📂 database/                 # Database prodotti
├── 📂 protection_system/        # Sistema protezioni
├── 📂 report/                   # Generazione report
└── 📂 scripts/                  # Script utilità
    ├── run_app.py              # Runner avanzato
    └── quick_test.py           # Test sistema
```

## 🔧 CONFIGURAZIONE

### Configurazione Base
Il software funziona immediatamente dopo l'avvio. Non richiede configurazioni particolari.

### Sistema ABB Avanzato
Per utilizzare le funzionalità complete del sistema ABB:
1. Verifica che Node.js sia installato (per JavaScript engine)
2. Il sistema si adatta automaticamente alle capacità disponibili

### Personalizzazioni
Modifica `config/settings.py` per:
- Parametri di default
- Normative di riferimento
- Layout applicazione

## 🚨 RISOLUZIONE PROBLEMI

### Problema: "ModuleNotFoundError"
**Soluzione:**
```bash
pip install streamlit pandas numpy plotly
```

### Problema: "ABB System not available"
**Situazione:** Normale, il software continua in modalità fallback
**Azione:** Nessuna, tutte le funzioni rimangono operative

### Problema: "Earth Switch Designer not found"
**Soluzione:**
1. Verifica che `mt_equipment/earth_switch.py` esista
2. Controlla sintassi del file

### Problema: Errore avvio Streamlit
**Soluzioni:**
1. Verifica porta 8501 libera: `lsof -i :8501`
2. Usa porta alternativa: `streamlit run main.py --server.port=8502`
3. Reset cache: `streamlit cache clear`

### Log e Debug
Attiva debug avanzato:
```bash
STREAMLIT_LOGGER_LEVEL=DEBUG streamlit run main.py
```

## 📊 ESEMPI USO

### Progetto Standard 800 kVA
1. **Step 1:** Inserisci dati distributore (20kV, 16kA, TT)
2. **Step 2:** Aggiungi carichi (motori 400kW, illuminazione 50kW)
3. **Step 3:** Il sistema propone 1x800kVA Hi-T Plus
4. **Step 4:** Configurazione quadro UniSec automatica
5. **Step 5:** ABB seleziona Emax2 E1.2 800A + T7 630A
6. **Risultato:** Progetto completo in 10 minuti

### Progetto Ridondante 1600 kVA
1. **Impostazioni:** Servizio "Essenziale"
2. **Step 3:** Il sistema forza 2x800kVA per ridondanza
3. **Step 5:** ABB ottimizza cascata E2.2 1600A + E1.2 800A
4. **Risultato:** Sistema ridondante con selettività 95%

## 📞 SUPPORTO

### Auto-Diagnostica
```bash
python3 scripts/quick_test.py --verbose
```

### Informazioni Sistema
Dall'interfaccia: Menu → "🔍 Stato Moduli Sistema"

### Troubleshooting Avanzato
1. Controlla log Streamlit nella console
2. Verifica versioni Python/dipendenze
3. Test connettività database ABB

## 📄 LICENZA E CREDITS

**Software Cabina MT/BT Professional v2.0**
- Sviluppato con tecnologie open source
- Database ABB utilizzato per scopi educativi
- Interfaccia basata su Streamlit Framework

**Normative di Riferimento:**
- CEI 0-16 (Connessione MT)
- CEI 11-27 (Sezionatore di Terra)
- CEI 23-51 (Protezioni)
- CEI 14-8 (Trasformatori)
- IEC 60947-2 (Interruttori BT)

## 🚀 VERSIONE E AGGIORNAMENTI

**Versione Attuale:** 2.0
- ✅ Sistema ABB Emax 2 integrato
- ✅ Sezionatore di Terra (Step 3.5)
- ✅ Database prodotti completo
- ✅ Interfaccia migliorata
- ✅ Report automatici

**Prossimi Aggiornamenti:**
- 🔄 Integrazione schemi unifilari
- 🔄 Export CAD/DWG
- 🔄 Database prodotti aggiuntivi
- 🔄 Analisi economica avanzata

---

## 🎯 QUICK START - Esecuzione Immediata

**Comando immediato per esecuzione:**
```bash
cd /projects/Desktop/cabina_mt_bt && python3 -m streamlit run main.py
```

**Verifica funzionamento:**
```bash
python3 scripts/quick_test.py && echo "✅ Sistema pronto!"
```

**URL applicazione:**
🌐 http://localhost:8501

---

*Software Cabina MT/BT Professional v2.0 - Progettazione Professionale Semplificata*
