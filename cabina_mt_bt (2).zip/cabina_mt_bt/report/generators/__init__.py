"""
Report Generators Package
Moduli per generazione report tecnici
Software Cabina MT/BT Professional v2.0
"""

from .relazione_tecnica_completa import genera_relazione_da_main

__all__ = [
    'genera_relazione_da_main'
]

__version__ = "1.0.0"
__author__ = "Software Cabina MT/BT Professional"
