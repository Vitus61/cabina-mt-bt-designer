"""
Report Package - Generazione Report
Moduli per generazione e export report
Software Cabina MT/BT Professional v2.0
"""

try:
    from .generators.relazione_tecnica_completa import genera_relazione_da_main
    from .utils.streamlit_integration import interfaccia_report_sidebar
    REPORT_AVAILABLE = True
except ImportError:
    REPORT_AVAILABLE = False

__all__ = []

if REPORT_AVAILABLE:
    __all__.extend([
        'genera_relazione_da_main',
        'interfaccia_report_sidebar'
    ])

__version__ = "1.0.0"
__author__ = "Software Cabina MT/BT Professional"
