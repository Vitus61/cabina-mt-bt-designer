"""
Report Utils Package
Utilità per integrazione report con interfacce
Software Cabina MT/BT Professional v2.0
"""

from .streamlit_integration import interfaccia_report_sidebar

__all__ = [
    'interfaccia_report_sidebar'
]

__version__ = "1.0.0"
__author__ = "Software Cabina MT/BT Professional"
