# ABB SACE Emax 2 - Sistema Calcolo Selettività

Database completo e algoritmi di calcolo per la selettività delle protezioni degli interruttori ABB SACE Emax 2.

Basato sul documento ufficiale ABB: **1SDH001330R0001 - ECN000086018 - Rev. B**

## 📋 Contenuto del Sistema

### 🗃️ Database Interruttori
- **Modelli**: E1.2, E2.2, E4.2, E6.2
- **Unità di Protezione**: Ekip Dip, Touch, Hi-Touch, Measuring Pro, G-Touch
- **Standard**: IEC e UL
- **Curve**: L-S(t=k/I²), L-S(t=k), G(t=k/I²), G(t=k), IEC 60255

### 🧮 Algoritmi di Calcolo
- Curve tempo-corrente per tutte le funzioni di protezione
- Calcolo I²t per energia passante
- Verifiche di selettività cronometrica, amperometrica ed energetica
- Integrazione con tabelle certificate ABB

### 📊 Tabelle Selettività Certificate
- Combinazioni testate ABB
- Dati I²t ufficiali per ogni modello e taglia
- Limiti di selettività certificata

## 🚀 Utilizzo Rapido

### Installazione
```javascript
// Copia i file nella directory del progetto
const ABBSelectivitySystem = require('./abb_database/abb_selectivity_system.js');
```

### Esempio Base
```javascript
const system = new ABBSelectivitySystem();

// Definisce catena di interruttori (da valle a monte)
const breakerChain = [
    {
        name: "Q1 - Servizi",
        model: "E1.2 800A", 
        rating: "800A",
        In: 800,
        settings: {
            LMultiplier: 1.0,
            SThreshold: 8,
            IThreshold: 12,
            timeDelayL: 0.1
        }
    },
    {
        name: "Q0 - Generale",
        model: "E2.2 2000A",
        rating: "2000A", 
        In: 2000,
        settings: {
            LMultiplier: 1.0,
            SThreshold: 6,
            IThreshold: 10,
            timeDelayL: 0.2
        }
    }
];

// Correnti di guasto da verificare [kA]
const faultCurrents = [1, 5, 15, 25, 40];

// Calcola studio selettività
const study = system.calculateSelectivityStudy(breakerChain, faultCurrents);

console.log("Selettività:", study.summary.selectivityPercentage + "%");
```

## 📁 Struttura File

```
abb_database/
├── abb_emax2_curves.js                    # Database interruttori e curve
├── abb_curve_calculator_improved.js       # Algoritmi calcolo curve (versione ottimizzata)
├── abb_selectivity_tables_expanded.js     # Tabelle certificate e I²t (versione completa)
├── abb_selectivity_system.js              # Sistema integrato
├── test_examples.js.REMOVED               # Esempi e test (deprecato)
├── *.js.REMOVED                           # File legacy rimossi
└── README.md                              # Questa documentazione
```

## 🔧 API Principale

### ABBSelectivitySystem

#### `calculateSelectivityStudy(breakerChain, faultCurrents)`
Calcola studio completo di selettività per una catena di interruttori.

**Parametri:**
- `breakerChain` - Array di interruttori ordinati da valle a monte
- `faultCurrents` - Array di correnti di guasto in kA

**Ritorna:** Oggetto con risultati dettagliati

#### `analyzeSelectivityPair(downstream, upstream, faultCurrents)`
Analizza selettività tra due interruttori specifici.

#### `generateCurve(breaker, currents)`
Genera punti della curva tempo-corrente per visualizzazione.

#### `optimizeSettings(breakerChain, faultCurrents)`
Suggerisce ottimizzazioni delle tarature per migliorare la selettività.

#### `exportToCSV(study)`
Esporta risultati in formato CSV per Excel.

## 📈 Tipi di Curve Supportate

### Protezioni Base
- **L-S(t=k/I²)-I**: Long-Short time con caratteristica inversa
- **L-S(t=k)-I**: Long-Short time con tempo fisso
- **G(t=k/I²)**: Ground fault con caratteristica inversa  
- **G(t=k)**: Ground fault con tempo fisso

### Curve IEC 60255
- **SI**: Standard Inverse
- **VI**: Very Inverse
- **EI**: Extremely Inverse
- **I4**: Long Time Inverse

### Protezioni Measuring Pro
- **UV/OV**: Under/Over Voltage
- **UF/OF**: Under/Over Frequency
- **RP**: Reverse Power
- **VU**: Voltage Unbalance

## 🏭 Esempio Cabina MT/BT

### Configurazione Tipica
```javascript
const cabinaBT = [
    {
        name: "Q1 - UPS",
        model: "E1.2 800A",
        In: 800,
        settings: { SThreshold: 8, timeDelayL: 0.1 }
    },
    {
        name: "Q2 - Quadro Distribuzione", 
        model: "E2.2 2000A",
        In: 2000,
        settings: { SThreshold: 6, timeDelayL: 0.2 }
    },
    {
        name: "Q0 - Generale BT",
        model: "E4.2 4000A", 
        In: 4000,
        settings: { SThreshold: 5, timeDelayL: 0.4 }
    }
];
```

### Correnti di Guasto Tipiche
- **1 kA**: Sovraccarico moderato
- **5 kA**: Guasto a valle
- **15 kA**: Guasto quadro
- **25 kA**: Guasto sbarre BT
- **40 kA**: Guasto massimo trasformatore

## 🔬 Test e Validazione

Esegui il file di test per verificare il funzionamento:

```bash
node test_examples.js
```

Oppure chiama specifiche funzioni:
```javascript
const examples = require('./test_examples.js');

// Configura interruttori
const breakers = examples.esempioConfigurazioneCabina();

// Calcola selettività  
const study = examples.esempioStudioSelettivita();

// Ottimizza tarature
examples.esempioOttimizzazione();
```

## 📊 Output Tipico

```
=== STUDIO DI SELETTIVITÀ ===

RISULTATI SOMMARIO:
- Coppie totali analizzate: 2
- Coppie selettive: 2  
- Percentuale selettività: 100.0%

COPPIA: Q1 - Servizi / Q2 - Quadro Distribuzione
Selettività complessiva: ✓ OK

If(kA) | t_valle(s) | t_monte(s) | Rapporto | Cronometrica | Energetica | Certificata | Risultato
-----------------------------------------------------------------------------------------------
     1 |      7.520 |     30.200 |     4.02 |           SI |         SI |          NO |        OK
     5 |      0.120 |      0.242 |     2.02 |           SI |         SI |          SI |        OK
    15 |      0.053 |      0.107 |     2.02 |           SI |         SI |          SI |        OK
    25 |      0.032 |      0.064 |     2.00 |           SI |         SI |          SI |        OK
```

## 🔧 Personalizzazione

### Aggiungere Nuovi Modelli
```javascript
// In abb_emax2_curves.js
ABBEmax2Database.breakers["NUOVO_MODELLO"] = {
    ratings: ["1000A", "1250A"],
    icuRating: "85kA",
    protectionUnits: ["Ekip Touch"]
};
```

### Aggiungere Curve Personalizzate
```javascript
// In abb_curve_calculator.js  
static calculateCustomCurve(current, In, settings) {
    // Implementa algoritmo personalizzato
    return calculatedTime;
}
```

## 📋 Limitazioni Attuali

1. **Dati I²t**: Valori stimati, necessari dati certificati completi
2. **Tabelle Selettività**: Database parziale, da completare con tutte le combinazioni ABB
3. **Curve Speciali**: Alcune protezioni avanzate non implementate
4. **Standard UL**: Implementazione base, da completare

## 🛠️ Sviluppi Futuri

- [ ] Database completo I²t certificati ABB
- [ ] Integrazione con software ABB DOC
- [ ] Interfaccia grafica per visualizzazione curve
- [ ] Export formato ABB e ETAP
- [ ] Algoritmi ottimizzazione automatica
- [ ] Validazione con casi reali

## 📞 Supporto

Per problemi o richieste:
- Consultare gli esempi in `test_examples.js`  
- Verificare configurazione interruttori
- Controllare unità di misura (A vs kA)
- Validare parametri curve

## 📄 Riferimenti

- **ABB SACE Emax 2**: Documento 1SDH001330R0001
- **IEC 60947-2**: Low-voltage switchgear
- **IEC 60255**: Protective relays
- **Selettività ABB**: Quaderno tecnico QT1

---

*Sistema sviluppato per supporto progettazione cabine MT/BT con interruttori ABB SACE Emax 2*
