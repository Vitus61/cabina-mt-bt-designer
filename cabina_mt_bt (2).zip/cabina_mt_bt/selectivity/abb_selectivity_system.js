/**
 * ABB SACE Emax 2 - Sistema Integrato Calcolo Selettività
 * Integra database, calcoli curve e tabelle certificate
 */

// Importa i moduli (se in ambiente Node.js)
const ABBEmax2Database = (typeof require !== 'undefined') ? 
    require('./abb_emax2_curves.js') : window.ABBEmax2Database;
const ABBEmax2CurveCalculator = (typeof require !== 'undefined') ? 
    require('./abb_curve_calculator_improved.js') : window.ABBEmax2CurveCalculatorImproved;
const ABBEmax2SelectivityTables = (typeof require !== 'undefined') ? 
    require('./abb_selectivity_tables_expanded.js') : window.ABBEmax2SelectivityTablesExpanded;

class ABBSelectivitySystem {
    
    constructor() {
        this.database = ABBEmax2Database;
        this.calculator = ABBEmax2CurveCalculator;
        this.tables = ABBEmax2SelectivityTables;
    }
    
    /**
     * Calcola studio di selettività completo
     * @param {Array} breakerChain - Catena di interruttori [valle -> monte]
     * @param {Array} faultCurrents - Correnti di guasto da verificare [kA]
     * @returns {object} Studio completo selettività
     */
    calculateSelectivityStudy(breakerChain, faultCurrents) {
        const results = {
            timestamp: new Date().toISOString(),
            summary: {
                totalPairs: breakerChain.length - 1,
                selectivePairs: 0,
                criticalFaults: []
            },
            details: []
        };
        
        // Analizza ogni coppia di interruttori adiacenti
        for (let i = 0; i < breakerChain.length - 1; i++) {
            const downstream = breakerChain[i];
            const upstream = breakerChain[i + 1];
            
            const pairResult = this.analyzeSelectivityPair(downstream, upstream, faultCurrents);
            results.details.push(pairResult);
            
            if (pairResult.overallSelective) {
                results.summary.selectivePairs++;
            } else {
                results.summary.criticalFaults.push({
                    pair: `${downstream.name} / ${upstream.name}`,
                    issues: pairResult.issues
                });
            }
        }
        
        results.summary.selectivityPercentage = 
            (results.summary.selectivePairs / results.summary.totalPairs) * 100;
        
        return results;
    }
    
    /**
     * Analizza selettività tra due interruttori
     * @param {object} downstream - Interruttore a valle
     * @param {object} upstream - Interruttore a monte
     * @param {Array} faultCurrents - Correnti di guasto [kA]
     * @returns {object} Risultati analisi coppia
     */
    analyzeSelectivityPair(downstream, upstream, faultCurrents) {
        const result = {
            pair: `${downstream.name} / ${upstream.name}`,
            downstream: downstream,
            upstream: upstream,
            selectivityData: [],
            overallSelective: true,
            issues: []
        };
        
        for (const If of faultCurrents) {
            const IfAmps = If * 1000; // Conversione kA -> A
            
            // Calcola tempi di intervento
            const tDownstream = this.calculator.calculateLSI2Curve(
                IfAmps, 
                downstream.In, 
                downstream.settings
            );
            
            const tUpstream = this.calculator.calculateLSI2Curve(
                IfAmps,
                upstream.In, 
                upstream.settings
            );
            
            // Verifica selettività certificata
            const certifiedCheck = this.tables.checkCertifiedSelectivity(
                upstream.model,
                downstream.model, 
                If
            );
            
            // Calcolo dati I²t
            const i2tDownstream = this.tables.getI2tData(
                downstream.model.split(' ')[0],
                downstream.rating,
                downstream.icuRating
            );
            
            const selectivityCheck = {
                faultCurrent: If,
                tDownstream: tDownstream,
                tUpstream: tUpstream,
                timeRatio: tUpstream && tDownstream ? tUpstream / tDownstream : null,
                chronometricSelective: false,
                energeticSelective: false,
                certifiedSelective: certifiedCheck.certified && certifiedCheck.selective,
                i2tData: i2tDownstream
            };
            
            // Verifica selettività cronometrica
            if (selectivityCheck.timeRatio >= this.tables.selectivityConstants.minTimeRatio) {
                selectivityCheck.chronometricSelective = true;
            }
            
            // Verifica selettività energetica (semplificata)
            if (i2tDownstream && tDownstream) {
                const passingEnergy = Math.pow(IfAmps, 2) * tDownstream;
                selectivityCheck.energeticSelective = 
                    passingEnergy <= i2tDownstream.i2t_total * (1 - this.tables.selectivityConstants.energyMargin);
            }
            
            // Determina selettività complessiva per questa corrente
            selectivityCheck.selective = 
                selectivityCheck.chronometricSelective || 
                selectivityCheck.energeticSelective ||
                selectivityCheck.certifiedSelective;
            
            if (!selectivityCheck.selective) {
                result.overallSelective = false;
                result.issues.push(`Non selettivo a ${If}kA`);
            }
            
            result.selectivityData.push(selectivityCheck);
        }
        
        return result;
    }
    
    /**
     * Genera curve tempo-corrente per visualizzazione
     * @param {object} breaker - Dati interruttore
     * @param {Array} currents - Array di correnti [A]
     * @returns {Array} Punti curva [{I, t}]
     */
    generateCurve(breaker, currents) {
        const curve = [];
        
        for (const current of currents) {
            const time = this.calculator.calculateLSI2Curve(
                current,
                breaker.In,
                breaker.settings
            );
            
            if (time !== null) {
                curve.push({
                    current: current,
                    time: time,
                    currentRatio: current / breaker.In
                });
            }
        }
        
        return curve;
    }
    
    /**
     * Ottimizza tarature per migliorare selettività
     * @param {Array} breakerChain - Catena interruttori
     * @param {Array} faultCurrents - Correnti di guasto
     * @returns {object} Suggerimenti ottimizzazione
     */
    optimizeSettings(breakerChain, faultCurrents) {
        const suggestions = {
            timestamp: new Date().toISOString(),
            improvements: [],
            warnings: []
        };
        
        // Analisi semplificata - da espandere
        for (let i = 0; i < breakerChain.length - 1; i++) {
            const downstream = breakerChain[i];
            const upstream = breakerChain[i + 1];
            
            // Suggerimenti base
            if (downstream.settings.timeDelayL >= upstream.settings.timeDelayL) {
                suggestions.improvements.push({
                    breaker: upstream.name,
                    parameter: "timeDelayL", 
                    currentValue: upstream.settings.timeDelayL,
                    suggestedValue: downstream.settings.timeDelayL * 2,
                    reason: "Migliorare selettività cronometrica"
                });
            }
            
            // Verifica soglie S
            if (downstream.settings.SThreshold >= upstream.settings.SThreshold) {
                suggestions.warnings.push({
                    issue: "Soglia S monte <= valle",
                    breakers: `${downstream.name} / ${upstream.name}`,
                    impact: "Possibile perdita selettività amperometrica"
                });
            }
        }
        
        return suggestions;
    }
    
    /**
     * Esporta risultati in formato tabellare
     * @param {object} study - Studio selettività
     * @returns {string} Formato CSV
     */
    exportToCSV(study) {
        const headers = [
            "Coppia Interruttori",
            "Corrente Guasto (kA)",
            "Tempo Valle (s)",
            "Tempo Monte (s)", 
            "Rapporto Tempi",
            "Selettiva Cronometrica",
            "Selettiva Energetica",
            "Selettiva Certificata",
            "Selettiva Complessiva"
        ];
        
        let csv = headers.join(";") + "\n";
        
        for (const pairResult of study.details) {
            for (const data of pairResult.selectivityData) {
                const row = [
                    pairResult.pair,
                    data.faultCurrent,
                    data.tDownstream ? data.tDownstream.toFixed(3) : "N/A",
                    data.tUpstream ? data.tUpstream.toFixed(3) : "N/A",
                    data.timeRatio ? data.timeRatio.toFixed(2) : "N/A",
                    data.chronometricSelective ? "SI" : "NO",
                    data.energeticSelective ? "SI" : "NO", 
                    data.certifiedSelective ? "SI" : "NO",
                    data.selective ? "SI" : "NO"
                ];
                csv += row.join(";") + "\n";
            }
        }
        
        return csv;
    }
}

// Esporta la classe
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ABBSelectivitySystem;
} else if (typeof window !== 'undefined') {
    window.ABBSelectivitySystem = ABBSelectivitySystem;
}
