"""
ABB Database Package - Sistema Completo Python
Sistema avanzato per interruttori ABB Emax 2 con algoritmi certificati
"""

from .abb_python_interface import (
    ABBEmax2Interface,
    ABBEmax2Database,
    ABBEmax2CurveCalculator,
    ABBBreakerSpecs, 
    ProtectionSettings,
    SelectivityResult,
    ProtectionType,
    CurveType,
    get_breaker_for_current,
    calculate_selectivity,
    get_optimal_cascade,
    test_abb_system,
    abb_system
)

__all__ = [
    'ABBEmax2Interface',
    'ABBEmax2Database', 
    'ABBEmax2CurveCalculator',
    'ABBBreakerSpecs',
    'ProtectionSettings', 
    'SelectivityResult',
    'ProtectionType',
    'CurveType',
    'get_breaker_for_current',
    'calculate_selectivity',
    'get_optimal_cascade',
    'test_abb_system',
    'abb_system'
]

# Test immediato per verificare funzionamento
print("🚀 ABB EMAX 2 ADVANCED SYSTEM - Python Conversion Complete")
print("📚 Database completo con algoritmi JavaScript convertiti")
print("⚡ Sistema certificato per calcoli selettività professionali")
