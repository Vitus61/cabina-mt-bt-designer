/**
 * ABB SACE Emax 2 - Calcolatore Curve Migliorato
 * Versione migliorata con gestione correnti basse e ottimizzazioni
 */

class ABBEmax2CurveCalculatorImproved {
    
    /**
     * Calcola la curva L-S con caratteristica t = k/I² (VERSIONE MIGLIORATA)
     * @param {number} current - Corrente di calcolo [A]
     * @param {number} In - Corrente nominale [A] 
     * @param {object} settings - Parametri della protezione
     * @returns {number|null} Tempo di intervento [s] o null se sotto soglia
     */
    static calculateLSI2CurveImproved(current, In, settings = {}) {
        const {
            LMultiplier = 1,        // Moltiplicatore L (0.4-1)
            SThreshold = 10,        // Soglia S (3-144 x In)
            IThreshold = 3,         // Soglia I (1.5-15 x In)
            timeDelayL = 0.1,       // Ritardo zona L
            timeDelayS = 0.05,      // Ritardo zona S
            kL = 120,               // Costante zona L
            kS = 0.05,              // Costante zona S
            minOperatingCurrent = 0.05  // Soglia minima operativa (5% In)
        } = settings;
        
        const Iratio = current / In;
        
        // MIGLIORAMENTO: Gestione correnti sotto soglia L
        if (Iratio < LMultiplier) {
            if (Iratio >= minOperatingCurrent) {
                // Per correnti basse ma sopra soglia minima: tempo molto elevato
                const extendedTime = kL * Math.pow(LMultiplier / Iratio, 1.2) + timeDelayL;
                return Math.min(extendedTime, 3600); // Max 1 ora
            } else {
                // Correnti troppo basse: non interviene
                return null;
            }
        }
        
        // Zona L (Long time) - t = k/I² + ritardo
        if (Iratio >= LMultiplier && Iratio < SThreshold) {
            const timeL = (kL * LMultiplier) / Math.pow(Iratio, 2) + timeDelayL;
            return Math.max(timeL, 0.1); // Minimo 100ms
        }
        
        // Zona S (Short time) - t = k/I² + ritardo
        if (Iratio >= SThreshold && Iratio < IThreshold) {
            const timeS = kS / Math.pow(Iratio - SThreshold + 1, 2) + timeDelayS;
            return Math.max(timeS, 0.05); // Minimo 50ms
        }
        
        // Zona I (Instantaneous)
        if (Iratio >= IThreshold) {
            return 0.02; // Tempo istantaneo tipico
        }
        
        return null;
    }
    
    /**
     * Ottimizza le tarature per massimizzare selettività
     * @param {Array} breakerChain - Catena di interruttori
     * @param {Array} faultCurrents - Correnti di guasto [kA]
     * @param {number} targetSelectivity - Selettività target [%]
     * @returns {object} Tarature ottimizzate
     */
    static optimizeSelectivitySettings(breakerChain, faultCurrents, targetSelectivity = 90) {
        const optimized = JSON.parse(JSON.stringify(breakerChain)); // Deep copy
        
        // Algoritmo di ottimizzazione semplificato
        for (let i = 0; i < optimized.length - 1; i++) {
            const downstream = optimized[i];
            const upstream = optimized[i + 1];
            
            // Aumenta ritardo monte per migliorare selettività
            const currentRatio = upstream.In / downstream.In;
            if (currentRatio < 2) {
                // Se rapporto correnti basso, aumenta ritardo temporale
                upstream.settings.timeDelayL = Math.max(
                    downstream.settings.timeDelayL * 3,
                    0.3
                );
            } else {
                // Con buon rapporto correnti, ritardo più moderato
                upstream.settings.timeDelayL = Math.max(
                    downstream.settings.timeDelayL * 2,
                    0.2
                );
            }
            
            // Ottimizza soglie per selettività amperometrica
            if (upstream.settings.SThreshold >= downstream.settings.SThreshold) {
                upstream.settings.SThreshold = Math.max(
                    downstream.settings.SThreshold * 0.8,
                    3
                );
            }
            
            if (upstream.settings.IThreshold >= downstream.settings.IThreshold) {
                upstream.settings.IThreshold = Math.max(
                    downstream.settings.IThreshold * 0.9,
                    1.5
                );
            }
        }
        
        return {
            originalChain: breakerChain,
            optimizedChain: optimized,
            improvements: this.calculateImprovements(breakerChain, optimized, faultCurrents)
        };
    }
    
    /**
     * Calcola miglioramenti ottenuti con ottimizzazione
     * @param {Array} original - Configurazione originale
     * @param {Array} optimized - Configurazione ottimizzata
     * @param {Array} faultCurrents - Correnti di guasto
     * @returns {object} Analisi miglioramenti
     */
    static calculateImprovements(original, optimized, faultCurrents) {
        const originalSelectivity = this.calculateOverallSelectivity(original, faultCurrents);
        const optimizedSelectivity = this.calculateOverallSelectivity(optimized, faultCurrents);
        
        return {
            originalSelectivity: originalSelectivity,
            optimizedSelectivity: optimizedSelectivity,
            improvement: optimizedSelectivity - originalSelectivity,
            recommendations: this.generateRecommendations(original, optimized)
        };
    }
    
    /**
     * Calcola selettività complessiva di una configurazione
     * @param {Array} breakerChain - Catena interruttori
     * @param {Array} faultCurrents - Correnti di guasto
     * @returns {number} Percentuale selettività
     */
    static calculateOverallSelectivity(breakerChain, faultCurrents) {
        let totalTests = 0;
        let selectiveTests = 0;
        
        for (let i = 0; i < breakerChain.length - 1; i++) {
            const downstream = breakerChain[i];
            const upstream = breakerChain[i + 1];
            
            faultCurrents.forEach(If => {
                const IfAmps = If * 1000;
                const tDown = this.calculateLSI2CurveImproved(IfAmps, downstream.In, downstream.settings);
                const tUp = this.calculateLSI2CurveImproved(IfAmps, upstream.In, upstream.settings);
                
                totalTests++;
                
                if (tDown && tUp && (tUp / tDown) >= 2.0) {
                    selectiveTests++;
                }
            });
        }
        
        return totalTests > 0 ? (selectiveTests / totalTests) * 100 : 0;
    }
    
    /**
     * Genera raccomandazioni per migliorare selettività
     * @param {Array} original - Configurazione originale
     * @param {Array} optimized - Configurazione ottimizzata
     * @returns {Array} Lista raccomandazioni
     */
    static generateRecommendations(original, optimized) {
        const recommendations = [];
        
        for (let i = 0; i < original.length; i++) {
            const orig = original[i];
            const opt = optimized[i];
            
            if (opt.settings.timeDelayL > orig.settings.timeDelayL) {
                recommendations.push({
                    breaker: orig.name,
                    parameter: "Ritardo L",
                    change: `${orig.settings.timeDelayL}s → ${opt.settings.timeDelayL}s`,
                    reason: "Migliorare selettività cronometrica"
                });
            }
            
            if (opt.settings.SThreshold < orig.settings.SThreshold) {
                recommendations.push({
                    breaker: orig.name,
                    parameter: "Soglia S",
                    change: `${orig.settings.SThreshold} → ${opt.settings.SThreshold}`,
                    reason: "Migliorare selettività amperometrica"
                });
            }
        }
        
        return recommendations;
    }
    
    // Mantieni compatibilità con metodo originale
    static calculateLSI2Curve(current, In, settings = {}) {
        return this.calculateLSI2CurveImproved(current, In, settings);
    }
    
    /**
     * Test completo di una configurazione
     * @param {Array} breakerChain - Catena interruttori
     * @param {Array} faultCurrents - Correnti di guasto
     * @returns {object} Risultati test completi
     */
    static testConfiguration(breakerChain, faultCurrents = [1, 5, 15, 25, 40]) {
        console.log("🧪 TEST CONFIGURAZIONE ABB EMAX 2");
        console.log("==================================");
        
        const results = {
            configuration: breakerChain,
            testResults: [],
            overallSelectivity: 0,
            issues: [],
            recommendations: []
        };
        
        // Test ogni coppia
        for (let i = 0; i < breakerChain.length - 1; i++) {
            const downstream = breakerChain[i];
            const upstream = breakerChain[i + 1];
            
            console.log(`\n📊 Coppia: ${downstream.name} / ${upstream.name}`);
            console.log("If(kA) | t_valle(s) | t_monte(s) | Rapporto | Selettiva");
            console.log("-".repeat(60));
            
            let pairSelectiveCount = 0;
            const pairResults = [];
            
            faultCurrents.forEach(If => {
                const IfAmps = If * 1000;
                const tDown = this.calculateLSI2CurveImproved(IfAmps, downstream.In, downstream.settings);
                const tUp = this.calculateLSI2CurveImproved(IfAmps, upstream.In, upstream.settings);
                
                const ratio = (tUp && tDown) ? tUp / tDown : null;
                const selective = ratio && ratio >= 2.0;
                
                if (selective) pairSelectiveCount++;
                
                const result = {
                    faultCurrent: If,
                    tDownstream: tDown,
                    tUpstream: tUp,
                    ratio: ratio,
                    selective: selective
                };
                
                pairResults.push(result);
                
                console.log(
                    `${If.toString().padStart(6)} | ` +
                    `${tDown ? tDown.toFixed(3).padStart(10) : 'N/A'.padStart(10)} | ` +
                    `${tUp ? tUp.toFixed(3).padStart(10) : 'N/A'.padStart(10)} | ` +
                    `${ratio ? ratio.toFixed(2).padStart(8) : 'N/A'.padStart(8)} | ` +
                    `${selective ? '✅ SI' : '❌ NO'}`
                );
            });
            
            const pairSelectivity = (pairSelectiveCount / faultCurrents.length) * 100;
            console.log(`\nSelettività coppia: ${pairSelectivity}%`);
            
            results.testResults.push({
                pair: `${downstream.name}/${upstream.name}`,
                selectivity: pairSelectivity,
                details: pairResults
            });
        }
        
        // Calcola selettività complessiva
        results.overallSelectivity = this.calculateOverallSelectivity(breakerChain, faultCurrents);
        
        console.log(`\n🎯 SELETTIVITÀ COMPLESSIVA: ${results.overallSelectivity.toFixed(1)}%`);
        
        return results;
    }
}

// Esporta la classe
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ABBEmax2CurveCalculatorImproved;
} else if (typeof window !== 'undefined') {
    window.ABBEmax2CurveCalculatorImproved = ABBEmax2CurveCalculatorImproved;
}
