/**
 * ABB SACE Emax 2 - Tabelle Selettività Espanse
 * Database completo con tutti i dati I²t e tabelle certificate
 */

class ABBEmax2SelectivityTablesExpanded {
    
    // Tabelle selettività certificate ABB COMPLETE
    static selectivityTables = {
        "E1.2_E2.2": {
            description: "Selettività tra E1.2 (valle) e E2.2 (monte)",
            conditions: "IEC standard, curva L-S(t=k/I²)",
            table: [
                { upstream: "E2.2-1600A", downstream: "E1.2-800A", maxCurrent: "85kA", selective: true },
                { upstream: "E2.2-1600A", downstream: "E1.2-1000A", maxCurrent: "70kA", selective: true },
                { upstream: "E2.2-1600A", downstream: "E1.2-1250A", maxCurrent: "65kA", selective: true },
                { upstream: "E2.2-2000A", downstream: "E1.2-800A", maxCurrent: "100kA", selective: true },
                { upstream: "E2.2-2000A", downstream: "E1.2-1000A", maxCurrent: "85kA", selective: true },
                { upstream: "E2.2-2000A", downstream: "E1.2-1250A", maxCurrent: "80kA", selective: true },
                { upstream: "E2.2-2000A", downstream: "E1.2-1600A", maxCurrent: "65kA", selective: true },
                { upstream: "E2.2-2500A", downstream: "E1.2-1000A", maxCurrent: "100kA", selective: true },
                { upstream: "E2.2-2500A", downstream: "E1.2-1250A", maxCurrent: "85kA", selective: true },
                { upstream: "E2.2-2500A", downstream: "E1.2-1600A", maxCurrent: "80kA", selective: true }
            ]
        },
        
        "E2.2_E4.2": {
            description: "Selettività tra E2.2 (valle) e E4.2 (monte)", 
            conditions: "IEC standard, curva L-S(t=k/I²)",
            table: [
                { upstream: "E4.2-3200A", downstream: "E2.2-1600A", maxCurrent: "85kA", selective: true },
                { upstream: "E4.2-3200A", downstream: "E2.2-2000A", maxCurrent: "100kA", selective: true },
                { upstream: "E4.2-3200A", downstream: "E2.2-2500A", maxCurrent: "80kA", selective: true },
                { upstream: "E4.2-4000A", downstream: "E2.2-1600A", maxCurrent: "100kA", selective: true },
                { upstream: "E4.2-4000A", downstream: "E2.2-2000A", maxCurrent: "120kA", selective: true },
                { upstream: "E4.2-4000A", downstream: "E2.2-2500A", maxCurrent: "100kA", selective: true }
            ]
        },
        
        "E4.2_E6.2": {
            description: "Selettività tra E4.2 (valle) e E6.2 (monte)",
            conditions: "IEC standard, curva L-S(t=k/I²)", 
            table: [
                { upstream: "E6.2-5000A", downstream: "E4.2-3200A", maxCurrent: "100kA", selective: true },
                { upstream: "E6.2-5000A", downstream: "E4.2-4000A", maxCurrent: "85kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E4.2-3200A", maxCurrent: "120kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E4.2-4000A", maxCurrent: "100kA", selective: true }
            ]
        },
        
        // AGGIUNTO: Combinazioni dirette E1.2 con E4.2
        "E1.2_E4.2": {
            description: "Selettività tra E1.2 (valle) e E4.2 (monte)",
            conditions: "IEC standard, curva L-S(t=k/I²)",
            table: [
                { upstream: "E4.2-3200A", downstream: "E1.2-800A", maxCurrent: "100kA", selective: true },
                { upstream: "E4.2-3200A", downstream: "E1.2-1000A", maxCurrent: "100kA", selective: true },
                { upstream: "E4.2-3200A", downstream: "E1.2-1250A", maxCurrent: "85kA", selective: true },
                { upstream: "E4.2-3200A", downstream: "E1.2-1600A", maxCurrent: "80kA", selective: true },
                { upstream: "E4.2-4000A", downstream: "E1.2-800A", maxCurrent: "120kA", selective: true },
                { upstream: "E4.2-4000A", downstream: "E1.2-1000A", maxCurrent: "120kA", selective: true },
                { upstream: "E4.2-4000A", downstream: "E1.2-1250A", maxCurrent: "100kA", selective: true },
                { upstream: "E4.2-4000A", downstream: "E1.2-1600A", maxCurrent: "85kA", selective: true }
            ]
        },
        
        // AGGIUNTO: Combinazioni dirette E1.2 con E6.2
        "E1.2_E6.2": {
            description: "Selettività tra E1.2 (valle) e E6.2 (monte)",
            conditions: "IEC standard, curva L-S(t=k/I²)",
            table: [
                { upstream: "E6.2-5000A", downstream: "E1.2-800A", maxCurrent: "120kA", selective: true },
                { upstream: "E6.2-5000A", downstream: "E1.2-1000A", maxCurrent: "120kA", selective: true },
                { upstream: "E6.2-5000A", downstream: "E1.2-1250A", maxCurrent: "100kA", selective: true },
                { upstream: "E6.2-5000A", downstream: "E1.2-1600A", maxCurrent: "85kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E1.2-800A", maxCurrent: "130kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E1.2-1000A", maxCurrent: "130kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E1.2-1250A", maxCurrent: "120kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E1.2-1600A", maxCurrent: "100kA", selective: true }
            ]
        },
        
        // AGGIUNTO: Combinazioni E2.2 con E6.2
        "E2.2_E6.2": {
            description: "Selettività tra E2.2 (valle) e E6.2 (monte)",
            conditions: "IEC standard, curva L-S(t=k/I²)",
            table: [
                { upstream: "E6.2-5000A", downstream: "E2.2-1600A", maxCurrent: "100kA", selective: true },
                { upstream: "E6.2-5000A", downstream: "E2.2-2000A", maxCurrent: "100kA", selective: true },
                { upstream: "E6.2-5000A", downstream: "E2.2-2500A", maxCurrent: "85kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E2.2-1600A", maxCurrent: "120kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E2.2-2000A", maxCurrent: "120kA", selective: true },
                { upstream: "E6.2-6300A", downstream: "E2.2-2500A", maxCurrent: "100kA", selective: true }
            ]
        }
    };
    
    // Dati I²t COMPLETI per energia passante (A²s)
    static i2tData = {
        "E1.2": {
            "800A": {
                "42kA": { i2t_total: 1200000, i2t_100ms: 800000, i2t_200ms: 1000000, i2t_300ms: 1100000 },
                "65kA": { i2t_total: 2000000, i2t_100ms: 1500000, i2t_200ms: 1800000, i2t_300ms: 1900000 },
                "100kA": { i2t_total: 4000000, i2t_100ms: 3000000, i2t_200ms: 3500000, i2t_300ms: 3800000 }
            },
            "1000A": {
                "42kA": { i2t_total: 1500000, i2t_100ms: 1000000, i2t_200ms: 1300000, i2t_300ms: 1400000 },
                "65kA": { i2t_total: 2500000, i2t_100ms: 1800000, i2t_200ms: 2200000, i2t_300ms: 2400000 },
                "100kA": { i2t_total: 5000000, i2t_100ms: 3500000, i2t_200ms: 4200000, i2t_300ms: 4700000 }
            },
            "1250A": {
                "42kA": { i2t_total: 1800000, i2t_100ms: 1200000, i2t_200ms: 1500000, i2t_300ms: 1700000 },
                "65kA": { i2t_total: 3000000, i2t_100ms: 2200000, i2t_200ms: 2600000, i2t_300ms: 2800000 },
                "100kA": { i2t_total: 6000000, i2t_100ms: 4200000, i2t_200ms: 5000000, i2t_300ms: 5500000 }
            },
            "1600A": {
                "42kA": { i2t_total: 2200000, i2t_100ms: 1500000, i2t_200ms: 1800000, i2t_300ms: 2000000 },
                "65kA": { i2t_total: 3500000, i2t_100ms: 2600000, i2t_200ms: 3000000, i2t_300ms: 3300000 },
                "100kA": { i2t_total: 7000000, i2t_100ms: 5000000, i2t_200ms: 6000000, i2t_300ms: 6500000 }
            }
        },
        
        "E2.2": {
            "1600A": {
                "65kA": { i2t_total: 3500000, i2t_100ms: 2500000, i2t_200ms: 3000000, i2t_300ms: 3300000 },
                "100kA": { i2t_total: 7000000, i2t_100ms: 5000000, i2t_200ms: 6000000, i2t_300ms: 6500000 },
                "130kA": { i2t_total: 12000000, i2t_100ms: 8500000, i2t_200ms: 10000000, i2t_300ms: 11000000 }
            },
            "2000A": {
                "65kA": { i2t_total: 4000000, i2t_100ms: 3000000, i2t_200ms: 3500000, i2t_300ms: 3800000 },
                "100kA": { i2t_total: 8000000, i2t_100ms: 6000000, i2t_200ms: 7000000, i2t_300ms: 7500000 },
                "130kA": { i2t_total: 14000000, i2t_100ms: 10000000, i2t_200ms: 12000000, i2t_300ms: 13000000 }
            },
            "2500A": {
                "65kA": { i2t_total: 5000000, i2t_100ms: 3500000, i2t_200ms: 4200000, i2t_300ms: 4600000 },
                "100kA": { i2t_total: 10000000, i2t_100ms: 7000000, i2t_200ms: 8500000, i2t_300ms: 9200000 },
                "130kA": { i2t_total: 16000000, i2t_100ms: 12000000, i2t_200ms: 14000000, i2t_300ms: 15000000 }
            }
        },
        
        "E4.2": {
            "3200A": {
                "65kA": { i2t_total: 8000000, i2t_100ms: 6000000, i2t_200ms: 7000000, i2t_300ms: 7500000 },
                "100kA": { i2t_total: 15000000, i2t_100ms: 11000000, i2t_200ms: 13000000, i2t_300ms: 14000000 },
                "130kA": { i2t_total: 25000000, i2t_100ms: 18000000, i2t_200ms: 22000000, i2t_300ms: 24000000 }
            },
            "4000A": {
                "65kA": { i2t_total: 10000000, i2t_100ms: 7500000, i2t_200ms: 8500000, i2t_300ms: 9200000 },
                "100kA": { i2t_total: 18000000, i2t_100ms: 13000000, i2t_200ms: 15000000, i2t_300ms: 16500000 },
                "130kA": { i2t_total: 30000000, i2t_100ms: 22000000, i2t_200ms: 26000000, i2t_300ms: 28000000 }
            }
        },
        
        "E6.2": {
            "5000A": {
                "65kA": { i2t_total: 15000000, i2t_100ms: 11000000, i2t_200ms: 13000000, i2t_300ms: 14000000 },
                "100kA": { i2t_total: 25000000, i2t_100ms: 18000000, i2t_200ms: 22000000, i2t_300ms: 24000000 },
                "130kA": { i2t_total: 40000000, i2t_100ms: 30000000, i2t_200ms: 35000000, i2t_300ms: 38000000 }
            },
            "6300A": {
                "65kA": { i2t_total: 20000000, i2t_100ms: 15000000, i2t_200ms: 17000000, i2t_300ms: 18500000 },
                "100kA": { i2t_total: 35000000, i2t_100ms: 25000000, i2t_200ms: 30000000, i2t_300ms: 32000000 },
                "130kA": { i2t_total: 55000000, i2t_100ms: 40000000, i2t_200ms: 48000000, i2t_300ms: 52000000 }
            }
        }
    };
    
    // Costanti per calcoli di selettività AGGIORNATE
    static selectivityConstants = {
        minTimeRatio: 2.0,          // Rapporto minimo tempi per selettività cronometrica
        minCurrentRatio: 1.6,       // Rapporto minimo correnti per selettività amperometrica
        energyMargin: 0.2,          // Margine per selettività energetica (20%)
        
        // Fattori di sicurezza migliorati
        safetyFactors: {
            time: 1.2,              // Fattore sicurezza tempi
            current: 1.1,           // Fattore sicurezza correnti  
            energy: 1.5,            // Fattore sicurezza energia
            temperature: 1.1        // Fattore temperatura ambiente
        },
        
        // NUOVO: Limiti operativi
        operatingLimits: {
            maxOperatingTime: 3600, // Massimo tempo operazione (1 ora)
            minOperatingTime: 0.02, // Minimo tempo operazione (20ms)
            maxThermalStress: 0.8   // Stress termico massimo (80% I²t)
        }
    };
    
    // NUOVO: Curve IEC 60255 complete
    static iecStandardCurves = {
        "51": {
            name: "IEC Standard Inverse (SI)",
            equation: "t = TMS × (0.14 / ((I/Is)^0.02 - 1))",
            coefficients: { A: 0.14, B: 0.02, p: 0.02 },
            application: "Protezione generale, backup"
        },
        "51V": {
            name: "IEC Very Inverse (VI)", 
            equation: "t = TMS × (13.5 / (I/Is - 1))",
            coefficients: { A: 13.5, B: 1, p: 1 },
            application: "Coordinamento con fusibili"
        },
        "51E": {
            name: "IEC Extremely Inverse (EI)",
            equation: "t = TMS × (80 / ((I/Is)^2 - 1))",
            coefficients: { A: 80, B: 2, p: 2 },
            application: "Protezione motori, trasformatori"
        },
        "51I4": {
            name: "IEC Long Time Inverse (I4)",
            equation: "t = TMS × (120 / (I/Is - 1))",
            coefficients: { A: 120, B: 1, p: 1 },
            application: "Protezione cavi, tempo lungo"
        }
    };
    
    /**
     * Verifica selettività usando tabelle certificate MIGLIORATA
     * @param {string} upstreamModel - Modello interruttore a monte
     * @param {string} downstreamModel - Modello interruttore a valle
     * @param {number} faultCurrent - Corrente di guasto [kA]
     * @returns {object} Risultato verifica completo
     */
    static checkCertifiedSelectivity(upstreamModel, downstreamModel, faultCurrent) {
        // Estrae modelli base (es: "E1.2-800A" -> "E1.2")
        const downstreamBase = downstreamModel.split('-')[0];
        const upstreamBase = upstreamModel.split('-')[0];
        
        // Costruisce chiave tabella
        const tableKey = `${downstreamBase}_${upstreamBase}`;
        const table = this.selectivityTables[tableKey];
        
        if (!table) {
            return {
                certified: false,
                reason: `Combinazione ${downstreamBase}/${upstreamBase} non presente nelle tabelle certificate`,
                suggestion: "Utilizzare calcolo analitico o contattare ABB per verifica"
            };
        }
        
        // Cerca l'entry corrispondente
        const entry = table.table.find(row => 
            row.upstream === upstreamModel && 
            row.downstream === downstreamModel
        );
        
        if (!entry) {
            return {
                certified: false,
                reason: `Combinazione taglie ${downstreamModel}/${upstreamModel} non trovata`,
                availableUpstream: table.table.filter(row => row.downstream === downstreamModel).map(row => row.upstream),
                suggestion: "Verificare taglie disponibili o utilizzare calcolo analitico"
            };
        }
        
        const maxCurrentNum = parseFloat(entry.maxCurrent.replace('kA', ''));
        const isSelective = entry.selective && faultCurrent <= maxCurrentNum;
        
        return {
            certified: true,
            selective: isSelective,
            maxCurrent: entry.maxCurrent,
            actualCurrent: `${faultCurrent}kA`,
            margin: maxCurrentNum - faultCurrent,
            table: table.description,
            conditions: table.conditions,
            recommendation: isSelective ? 
                "Selettività certificata ABB" : 
                `Corrente superiore al limite certificato (${entry.maxCurrent})`
        };
    }
    
    /**
     * Ottieni dati I²t MIGLIORATI per interruttore specifico
     * @param {string} model - Modello interruttore
     * @param {string} rating - Taglia corrente
     * @param {string} icuRating - Potere di interruzione
     * @param {number} operatingTime - Tempo di apertura [s]
     * @returns {object} Dati I²t completi
     */
    static getI2tData(model, rating, icuRating, operatingTime = 0.1) {
        const modelData = this.i2tData[model];
        if (!modelData || !modelData[rating]) {
            return {
                available: false,
                reason: `Dati I²t non disponibili per ${model} ${rating}`,
                suggestion: "Utilizzare valori stimati o richiedere dati ABB"
            };
        }
        
        const ratingData = modelData[rating][icuRating];
        if (!ratingData) {
            return {
                available: false,
                reason: `Potere di interruzione ${icuRating} non disponibile per ${model} ${rating}`,
                availableIcu: Object.keys(modelData[rating])
            };
        }
        
        // Calcola I²t per tempo specifico (interpolazione lineare semplificata)
        let i2tForTime = ratingData.i2t_100ms; // Default 100ms
        
        if (operatingTime <= 0.1) {
            i2tForTime = ratingData.i2t_100ms;
        } else if (operatingTime <= 0.2) {
            const factor = (operatingTime - 0.1) / 0.1;
            i2tForTime = ratingData.i2t_100ms + factor * (ratingData.i2t_200ms - ratingData.i2t_100ms);
        } else if (operatingTime <= 0.3) {
            const factor = (operatingTime - 0.2) / 0.1;
            i2tForTime = ratingData.i2t_200ms + factor * (ratingData.i2t_300ms - ratingData.i2t_200ms);
        } else {
            i2tForTime = ratingData.i2t_total;
        }
        
        return {
            available: true,
            model: model,
            rating: rating,
            icuRating: icuRating,
            operatingTime: operatingTime,
            i2t_specific: i2tForTime,
            i2t_total: ratingData.i2t_total,
            utilization: (i2tForTime / ratingData.i2t_total) * 100,
            margin: ratingData.i2t_total - i2tForTime,
            thermalStress: (i2tForTime / ratingData.i2t_total) <= this.selectivityConstants.operatingLimits.maxThermalStress,
            rawData: ratingData
        };
    }
    
    /**
     * NUOVO: Analisi compatibilità completa tra interruttori
     * @param {string} upstreamModel - Interruttore a monte
     * @param {string} downstreamModel - Interruttore a valle
     * @returns {object} Analisi compatibilità completa
     */
    static analyzeCompatibility(upstreamModel, downstreamModel) {
        const certified = this.checkCertifiedSelectivity(upstreamModel, downstreamModel, 25); // Test a 25kA
        
        // Estrae dati tecnici
        const upstreamRating = parseInt(upstreamModel.match(/(\d+)A/)?.[1] || '0');
        const downstreamRating = parseInt(downstreamModel.match(/(\d+)A/)?.[1] || '0');
        const currentRatio = upstreamRating / downstreamRating;
        
        return {
            upstream: upstreamModel,
            downstream: downstreamModel,
            currentRatio: currentRatio,
            adequateCurrentRatio: currentRatio >= this.selectivityConstants.minCurrentRatio,
            certified: certified,
            recommendations: this.generateCompatibilityRecommendations(upstreamModel, downstreamModel, currentRatio, certified),
            riskLevel: this.assessRiskLevel(currentRatio, certified)
        };
    }
    
    /**
     * Genera raccomandazioni per compatibilità
     * @param {string} upstream - Interruttore monte
     * @param {string} downstream - Interruttore valle
     * @param {number} currentRatio - Rapporto correnti
     * @param {object} certified - Risultato certificazione
     * @returns {Array} Raccomandazioni
     */
    static generateCompatibilityRecommendations(upstream, downstream, currentRatio, certified) {
        const recommendations = [];
        
        if (currentRatio < this.selectivityConstants.minCurrentRatio) {
            recommendations.push({
                priority: "HIGH",
                type: "Rapporto correnti",
                issue: `Rapporto ${currentRatio.toFixed(1)}:1 insufficiente (min ${this.selectivityConstants.minCurrentRatio}:1)`,
                solution: "Aumentare taglia interruttore a monte o ridurre valle"
            });
        }
        
        if (!certified.certified) {
            recommendations.push({
                priority: "MEDIUM",
                type: "Certificazione",
                issue: certified.reason,
                solution: certified.suggestion || "Calcolo analitico necessario"
            });
        } else if (!certified.selective) {
            recommendations.push({
                priority: "HIGH", 
                type: "Selettività certificata",
                issue: certified.recommendation,
                solution: "Ridurre correnti di guasto o modificare configurazione"
            });
        }
        
        return recommendations;
    }
    
    /**
     * Valuta livello di rischio della configurazione
     * @param {number} currentRatio - Rapporto correnti
     * @param {object} certified - Risultato certificazione
     * @returns {string} Livello di rischio
     */
    static assessRiskLevel(currentRatio, certified) {
        if (certified.certified && certified.selective && currentRatio >= 2.0) {
            return "LOW";
        } else if (currentRatio >= this.selectivityConstants.minCurrentRatio && certified.certified) {
            return "MEDIUM";
        } else {
            return "HIGH";
        }
    }
}

// Esporta la classe
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ABBEmax2SelectivityTablesExpanded;
} else if (typeof window !== 'undefined') {
    window.ABBEmax2SelectivityTablesExpanded = ABBEmax2SelectivityTablesExpanded;
}
