/**
 * ABB SACE Emax 2 - Database Curve di Protezione
 * Basato su documento 1SDH001330R0001 - ECN000086018 - Rev. B
 */

class ABBEmax2Database {
    
    static metadata = {
        document: "ABB SACE Emax 2 - 1SDH001330R0001",
        revision: "Rev. B", 
        year: 2018,
        standards: ["IEC", "UL"],
        source: "Curve di protezione | 2 - Protezioni Dip"
    };

    static breakers = {
        "E1.2": {
            ratings: ["800A", "1000A", "1250A", "1600A"],
            frames: ["III", "IV"],
            types: ["Fixed", "Withdrawable"],
            icuRating: "42-100kA",
            protectionUnits: ["Ekip Dip", "Ekip Touch", "Ekip Hi-Touch"],
            terminals: ["EF", "FC", "ES", "HR-VR"]
        },
        "E2.2": {
            ratings: ["1600A", "2000A", "2500A"],
            frames: ["III", "IV"], 
            types: ["Fixed", "Withdrawable"],
            icuRating: "65-130kA",
            protectionUnits: ["Ekip Touch", "Ekip Hi-Touch", "Ekip G-Touch"],
            terminals: ["HR-VR", "F", "SHR", "SVR", "FL"]
        },
        "E4.2": {
            ratings: ["3200A", "4000A"],
            frames: ["III", "IV"],
            types: ["Fixed", "Withdrawable"], 
            icuRating: "65-130kA",
            protectionUnits: ["Ekip Touch", "Ekip Hi-Touch", "Ekip G-Touch"],
            terminals: ["HR-VR", "F", "SHR", "SVR", "FL"]
        },
        "E6.2": {
            ratings: ["5000A", "6300A"],
            frames: ["III", "IV"],
            types: ["Fixed", "Withdrawable"],
            icuRating: "65-130kA", 
            protectionUnits: ["Ekip Touch", "Ekip Hi-Touch", "Ekip G-Touch"],
            terminals: ["HR", "VR", "F", "FL"]
        }
    };

    static protectionTypes = {
        // Protezioni Dip
        "Dip": {
            functions: ["L", "S", "I", "G"],
            curves: ["L-S(t=k/I²)-I", "L-S(t=k)-I", "G(t=k/I²)", "G(t=k)"],
            settings: {
                L: "0.4-1 x In",
                S: "3-144 x In", 
                I: "1.5-15 x In",
                timeDelay: {
                    IEC: "0.1-0.8s",
                    UL: "0.1-0.4s"
                },
                G: "0.1-1 x In"
            }
        },
        
        // Protezioni Touch
        "Touch": {
            functions: ["L", "S", "I", "G", "IU"],
            curves: ["L-S(t=k/I²)-I", "L-S(t=k)-I", "G(t=k/I²)", "G(t=k)", "L-IEC60255", "IU"],
            settings: {
                L: "0.4-1 x In",
                S: "3-144 x In",
                I: "1.5-15 x In", 
                timeDelay: {
                    IEC: "0.05-0.8s",
                    UL: "0.05-0.4s"
                },
                G: "0.1-1 x In",
                IU: {
                    threshold: "2%-90%",
                    timeDelay: "0.5-60s"
                }
            }
        },

        // Measuring Pro (per Touch)
        "MeasuringPro": {
            functions: ["UV", "OV", "VU", "UF", "OF", "RP"],
            settings: {
                UV: {
                    threshold: "0.5-0.98 x Un", 
                    timeDelay: "0.05-120s"
                },
                OV: {
                    threshold: "1.02-1.5 x Un",
                    timeDelay: "0.05-120s"
                },
                VU: {
                    threshold: "2%-90%",
                    timeDelay: "0.5-60s"
                },
                UF: {
                    threshold: "0.9-0.999 x Fn",
                    timeDelay: "0.15-300s"
                },
                OF: {
                    threshold: "1.001-1.1 x Fn",
                    timeDelay: "0.15-300s"
                },
                RP: {
                    threshold: "-1 to -0.05 x Sn",
                    timeDelay: "0.5-100s"
                }
            }
        },

        // Hi-Touch
        "HiTouch": {
            functions: ["L", "S", "I", "G", "D", "IU"],
            curves: ["L-S(t=k/I²)-I", "L-S(t=k)-I", "G(t=k/I²)", "G(t=k)", "D"],
            settings: {
                D: {
                    threshold: "0.1-0.8 x In",
                    timeDelay: "0.6-10s"
                }
            }
        },

        // G-Touch  
        "GTouch": {
            functions: ["L", "S", "I", "G", "S(V)", "RV", "RQ", "OQ", "OP", "UP"],
            curves: ["S(V)", "RV", "RQ", "OQ", "OP", "UP"],
            settings: {
                "S(V)": {
                    threshold: "0.6-10 x In",
                    timeDelay: "0.05-30s"
                },
                RV: {
                    threshold: "0.05-0.5 x Un", 
                    timeDelay: "0.05-120s"
                }
            }
        }
    };

    // Equazioni per il calcolo delle curve
    static curveEquations = {
        "LSI2": {
            name: "L-S(t=k/I²)-I", 
            formula: "t = k / I²",
            description: "Long-Short time with inverse time delay",
            zones: ["L", "S", "I"]
        },
        
        "LSK": {
            name: "L-S(t=k)-I",
            formula: "t = k", 
            description: "Long-Short time with fixed time delay",
            zones: ["L", "S", "I"]
        },
        
        "GI2": {
            name: "G(t=k/I²)",
            formula: "t = k / I²",
            description: "Ground fault with inverse time delay"
        },
        
        "GK": {
            name: "G(t=k)",
            formula: "t = k",
            description: "Ground fault with fixed time delay"
        },

        "IEC60255": {
            name: "L secondo IEC 60255",
            versions: ["SI", "VI", "EI", "I4"],
            description: "Standard IEC curves for long time protection"
        }
    };

    // Dati I²t per calcolo energia passante
    static i2tData = {
        // Valori tipici per Emax 2 - da completare con dati specifici
        "E1.2": {
            "800A": { i2t_100ms: 50000, i2t_200ms: 100000 },
            "1000A": { i2t_100ms: 80000, i2t_200ms: 160000 },
            "1250A": { i2t_100ms: 125000, i2t_200ms: 250000 },
            "1600A": { i2t_100ms: 200000, i2t_200ms: 400000 }
        }
        // Da espandere per E2.2, E4.2, E6.2
    };
}

// Esporta la classe
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ABBEmax2Database;
} else if (typeof window !== 'undefined') {
    window.ABBEmax2Database = ABBEmax2Database;
}
