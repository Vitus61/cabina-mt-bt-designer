"""
ABB UniSec - Configuratore Quadri MT Modulari COMPLETO
Include tutte le caratteristiche tecniche per verifiche normative
Software Cabina MT/BT Professional v2.0
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum

# ===============================================================================
# ENUMERAZIONI E CLASSIFICAZIONI
# ===============================================================================

class ServiceContinuity(Enum):
    """Classificazione continuità servizio IEC 62271-200"""
    LSC1 = "LSC1 - Manutenzione con quadro in tensione"
    LSC2A = "LSC2A - Manutenzione senza tensione, interruttore rimovibile"
    LSC2B = "LSC2B - Manutenzione senza tensione, interruttore estraibile"

class ArcClassification(Enum):
    """Classificazione tenuta arco interno"""
    IAC_A_FL_16KA = "IAC A FL 16kA 1s"
    IAC_A_FL_25KA = "IAC A FL 25kA 1s"
    IAC_A_FL_31_5KA = "IAC A FL 31.5kA 1s"

class UniSecUnitType(Enum):
    """Tipi unità UniSec standard"""
    DG = "Dispositivo Generale"
    TR = "Partenza Trasformatore" 
    OUT = "Partenza Uscita"
    MEASURING = "Unità Misure"
    COUPLING = "Accoppiamento Sbarre"
    SPARE = "Partenza Riserva"

# ===============================================================================
# DATACLASSES SPECIFICHE TECNICHE
# ===============================================================================

@dataclass
class UniSecElectricalSpecs:
    """Specifiche elettriche complete UniSec - ORDINE CORRETTO"""
    
    # ⚡ PARAMETRI OBBLIGATORI (SENZA DEFAULT)
    rated_current_a: int
    rated_current_busbar_a: int
    icw_rated_short_time_current_ka: float
    ipk_rated_peak_current_ka: float
    ik_making_current_ka: float
    rated_voltage_kv: float
    rated_insulation_voltage_kv: float
    rated_power_frequency_withstand_voltage_kv: float
    rated_lightning_impulse_withstand_voltage_kv: float
    service_continuity: ServiceContinuity
    arc_classification: ArcClassification
    protection_degree_front: str
    protection_degree_rear: str
    height_mm: int
    depth_mm: int
    weight_base_kg: int
    iec_standards: List[str]
    cei_standards: List[str]
    
    # 🌡️ PARAMETRI OPZIONALI (CON DEFAULT)
    ambient_temp_min_c: int = -5
    ambient_temp_max_c: int = 40
    relative_humidity_max: int = 95
    altitude_max_m: int = 1000
    additional_certifications: List[str] = field(default_factory=list)

@dataclass
class UniSecTechnicalData:
    """Dati tecnici completi per ogni configurazione UniSec"""
    
    configuration_name: str
    electrical_specs: UniSecElectricalSpecs
    
    def verify_short_circuit_compatibility(self, network_icp_ka: float) -> Dict:
        """Verifica critica: Icp (rete) < Icw (quadro)"""
        icw_quadro = self.electrical_specs.icw_rated_short_time_current_ka
        
        is_compatible = network_icp_ka <= icw_quadro
        safety_margin = (icw_quadro - network_icp_ka) / icw_quadro * 100 if icw_quadro > 0 else 0
        
        return {
            "compatible": is_compatible,
            "network_icp_ka": network_icp_ka,
            "switchgear_icw_ka": icw_quadro,
            "safety_margin_percent": safety_margin,
            "verification_result": "✅ CONFORME" if is_compatible else "❌ NON CONFORME",
            "recommendation": self._get_compatibility_recommendation(is_compatible, safety_margin)
        }
    
    def _get_compatibility_recommendation(self, is_compatible: bool, margin: float) -> str:
        """Raccomandazioni basate su verifica"""
        if not is_compatible:
            return "🚨 CRITICO: Aumentare Icw quadro o verificare Icp rete"
        elif margin < 10:
            return "⚠️ MARGINE BASSO: Verificare accuratamente Icp rete"
        elif margin > 50:
            return "💰 SOVRADIMENSIONATO: Possibile ottimizzazione costi"
        else:
            return "✅ OTTIMALE: Margine di sicurezza adeguato"

@dataclass
class UniSecUnit:
    """Singola unità modulare UniSec"""
    unit_type: UniSecUnitType
    width_mm: int
    description: str
    max_current: int = 1250
    includes: List[str] = field(default_factory=list)
    cost_base: int = 8500

@dataclass  
class UniSecPackage:
    """Pacchetto UniSec completo predefinito"""
    name: str
    description: str
    suitable_for: str
    power_range: Tuple[int, int]  # kVA min, max
    units: List[UniSecUnit]
    total_width: int
    included_features: List[str]
    base_price: int
    typical_total_price: int
    
    def get_total_width(self) -> int:
        """Calcola larghezza totale"""
        return sum(unit.width_mm for unit in self.units)

# ===============================================================================
# CONFIGURAZIONI TECNICHE STANDARD
# ===============================================================================

class UniSecStandardConfigurations:
    """Configurazioni tecniche standard ABB UniSec"""
    
    def __init__(self):
        self.configurations = self._load_standard_configurations()
    
    def _load_standard_configurations(self) -> Dict[str, UniSecTechnicalData]:
        """Carica configurazioni tecniche standard"""
        
        return {
            "unisec_24kv_1250a_25ka": UniSecTechnicalData(
                configuration_name="UniSec 24kV 1250A 25kA Standard",
                electrical_specs=UniSecElectricalSpecs(
                    # Parametri obbligatori
                    rated_current_a=1250,
                    rated_current_busbar_a=1250,
                    icw_rated_short_time_current_ka=25.0,
                    ipk_rated_peak_current_ka=63.0,
                    ik_making_current_ka=63.0,
                    rated_voltage_kv=24.0,
                    rated_insulation_voltage_kv=25.2,
                    rated_power_frequency_withstand_voltage_kv=50.0,
                    rated_lightning_impulse_withstand_voltage_kv=125.0,
                    service_continuity=ServiceContinuity.LSC2A,
                    arc_classification=ArcClassification.IAC_A_FL_25KA,
                    protection_degree_front="IP3X",
                    protection_degree_rear="IP2X",
                    height_mm=2000,
                    depth_mm=1000,
                    weight_base_kg=1200,
                    iec_standards=["IEC 62271-200", "IEC 62271-1", "IEC 62271-102"],
                    cei_standards=["CEI 17-6", "CEI 0-16"],
                    # Parametri opzionali (usano default)
                    additional_certifications=["Marcatura CE", "KEMA Type Test"]
                )
            ),
            
            "unisec_20kv_1250a_16ka": UniSecTechnicalData(
                configuration_name="UniSec 20kV 1250A 16kA Economic",
                electrical_specs=UniSecElectricalSpecs(
                    rated_current_a=1250,
                    rated_current_busbar_a=1250,
                    icw_rated_short_time_current_ka=16.0,
                    ipk_rated_peak_current_ka=40.0,
                    ik_making_current_ka=40.0,
                    rated_voltage_kv=20.0,
                    rated_insulation_voltage_kv=21.0,
                    rated_power_frequency_withstand_voltage_kv=42.0,
                    rated_lightning_impulse_withstand_voltage_kv=105.0,
                    service_continuity=ServiceContinuity.LSC2A,
                    arc_classification=ArcClassification.IAC_A_FL_16KA,
                    protection_degree_front="IP3X",
                    protection_degree_rear="IP2X",
                    height_mm=2000,
                    depth_mm=1000,
                    weight_base_kg=1100,
                    iec_standards=["IEC 62271-200", "IEC 62271-1"],
                    cei_standards=["CEI 17-6", "CEI 0-16"],
                    additional_certifications=["Marcatura CE"]
                )
            ),
            
            "unisec_36kv_1600a_31_5ka": UniSecTechnicalData(
                configuration_name="UniSec 36kV 1600A 31.5kA Premium",
                electrical_specs=UniSecElectricalSpecs(
                    rated_current_a=1600,
                    rated_current_busbar_a=2000,
                    icw_rated_short_time_current_ka=31.5,
                    ipk_rated_peak_current_ka=80.0,
                    ik_making_current_ka=80.0,
                    rated_voltage_kv=36.0,
                    rated_insulation_voltage_kv=38.5,
                    rated_power_frequency_withstand_voltage_kv=70.0,
                    rated_lightning_impulse_withstand_voltage_kv=170.0,
                    service_continuity=ServiceContinuity.LSC2B,
                    arc_classification=ArcClassification.IAC_A_FL_31_5KA,
                    protection_degree_front="IP4X",
                    protection_degree_rear="IP3X",
                    height_mm=2200,
                    depth_mm=1200,
                    weight_base_kg=1500,
                    iec_standards=["IEC 62271-200", "IEC 62271-1", "IEC 62271-102"],
                    cei_standards=["CEI 17-6", "CEI 0-16", "CEI 11-1"],
                    additional_certifications=["Marcatura CE", "KEMA Type Test", "Marine Approved"]
                )
            ),
            
            "unisec_15kv_630a_16ka": UniSecTechnicalData(
                configuration_name="UniSec 15kV 630A 16kA Compact",
                electrical_specs=UniSecElectricalSpecs(
                    rated_current_a=630,
                    rated_current_busbar_a=630,
                    icw_rated_short_time_current_ka=16.0,
                    ipk_rated_peak_current_ka=40.0,
                    ik_making_current_ka=40.0,
                    rated_voltage_kv=15.0,
                    rated_insulation_voltage_kv=15.5,
                    rated_power_frequency_withstand_voltage_kv=35.0,
                    rated_lightning_impulse_withstand_voltage_kv=95.0,
                    service_continuity=ServiceContinuity.LSC2A,
                    arc_classification=ArcClassification.IAC_A_FL_16KA,
                    protection_degree_front="IP3X",
                    protection_degree_rear="IP2X",
                    height_mm=2000,
                    depth_mm=1000,
                    weight_base_kg=900,
                    iec_standards=["IEC 62271-200", "IEC 62271-1"],
                    cei_standards=["CEI 17-6", "CEI 0-16"],
                    additional_certifications=["Marcatura CE"]
                )
            )
        }
    
    def select_configuration_by_requirements(self, 
                                           network_voltage_kv: float,
                                           network_icp_ka: float,
                                           required_current_a: int,
                                           service_level: str = "standard") -> Tuple[Optional[str], Dict]:
        """Selezione automatica configurazione basata su requisiti rete"""
        
        compatible_configs = []
        
        for config_id, config_data in self.configurations.items():
            specs = config_data.electrical_specs
            
            # Verifica tensione
            if specs.rated_voltage_kv < network_voltage_kv:
                continue
            
            # Verifica corrente
            if specs.rated_current_a < required_current_a:
                continue
                
            # Verifica critica: Icw > Icp
            cc_verification = config_data.verify_short_circuit_compatibility(network_icp_ka)
            if not cc_verification["compatible"]:
                continue
            
            compatible_configs.append((config_id, config_data, cc_verification))
        
        if not compatible_configs:
            return None, {"error": "Nessuna configurazione UniSec compatibile"}
        
        # Ordina per economicità (Icw crescente)
        compatible_configs.sort(key=lambda x: x[1].electrical_specs.icw_rated_short_time_current_ka)
        
        # Seleziona configurazione
        if service_level == "premium" and len(compatible_configs) > 1:
            selected = compatible_configs[-1]  # Più prestante
        else:
            selected = compatible_configs[0]   # Più economica
        
        config_id, config_data, verification = selected
        
        return config_id, {
            "selected_configuration": config_data,
            "short_circuit_verification": verification,
            "alternatives": len(compatible_configs),
            "selection_reason": f"Configurazione {service_level} compatibile",
            "all_compatible": compatible_configs
        }

# ===============================================================================
# PACCHETTI UNISEC STANDARD
# ===============================================================================

class UniSecPackageConfigurator:
    """Configuratore pacchetti UniSec standard"""
    
    def __init__(self):
        self.packages = self._load_standard_packages()
    
    def _load_standard_packages(self) -> Dict[str, UniSecPackage]:
        """Carica pacchetti standard ABB"""
        return {
            "basic_400": UniSecPackage(
                name="UniSec Basic (200-500kVA)",
                description="DG + 1 Partenza Trasformatore",
                suitable_for="Piccole industrie, terziario, uffici",
                power_range=(200, 500),
                units=[
                    UniSecUnit(
                        unit_type=UniSecUnitType.DG,
                        width_mm=500,
                        description="Dispositivo Generale con protezioni CEI 0-16",
                        includes=[
                            "Interruttore MT VD4-P in vuoto 630A",
                            "Sezionatori linea/terra integrati",
                            "Relè protezione REF601 con IEC 61850",
                            "TA/TV per misure e protezioni",
                            "Indicatori presenza tensione LED"
                        ]
                    ),
                    UniSecUnit(
                        unit_type=UniSecUnitType.TR,
                        width_mm=500,
                        description="Partenza Trasformatore",
                        includes=[
                            "Interruttore MT VD4-P dedicato 400A",
                            "Sezionatori con interblocchi meccanici",
                            "Relè protezione REF615 trasformatore",
                            "TA protezione termica trasformatore"
                        ]
                    )
                ],
                total_width=1000,
                included_features=[
                    "✅ Struttura UniSec IP3X certificata ABB",
                    "✅ Sezionatori linea/terra con interblocchi meccanici CEI",
                    "✅ Indicatori presenza tensione LED trifase",
                    "✅ Protezione arco interno IAC 25kA 1s",
                    "✅ Predisposizione comunicazione IEC 61850",
                    "✅ Cablaggio MT base e ausiliari 24V",
                    "✅ Morsettiere e connessioni standardizzate",
                    "✅ Manualistica e certificazioni CE"
                ],
                base_price=28500,
                typical_total_price=45000
            ),
            
            "standard_800": UniSecPackage(
                name="UniSec Standard (500-1000kVA)", 
                description="DG + Trasformatore + Partenza Riserva",
                suitable_for="Medie industrie, centri commerciali, ospedali",
                power_range=(500, 1000),
                units=[
                    UniSecUnit(
                        unit_type=UniSecUnitType.DG,
                        width_mm=500,
                        description="Dispositivo Generale potenziato",
                        includes=[
                            "Interruttore MT VD4-P 800A",
                            "Protezione REF601 con data logger",
                            "Comunicazione IEC 61850 completa",
                            "Supervisione carichi via SCADA"
                        ]
                    ),
                    UniSecUnit(
                        unit_type=UniSecUnitType.TR,
                        width_mm=500,
                        description="Partenza Trasformatore principale",
                        includes=[
                            "Interruttore MT ottimizzato per trasformatore",
                            "Protezioni termiche avanzate",
                            "Monitoraggio temperatura e carichi"
                        ]
                    ),
                    UniSecUnit(
                        unit_type=UniSecUnitType.SPARE,
                        width_mm=500,
                        description="Partenza Riserva/Ampliamento futuro",
                        includes=[
                            "Predisposizione completa per secondo trasformatore",
                            "Sezionatori e protezioni standard",
                            "Cablaggio e ausiliari pronti"
                        ]
                    )
                ],
                total_width=1500,
                included_features=[
                    "✅ Tutto del Basic +",
                    "✅ Unità partenza riserva per ampliamenti futuri",
                    "✅ Comunicazione IEC 61850 standard su DG",
                    "✅ Data logger integrato protezione DG",
                    "✅ Predisposizione telecontrollo SCADA",
                    "✅ Monitoraggio energia e diagnostica",
                    "✅ Manutenzione predittiva abilitata"
                ],
                base_price=42000,
                typical_total_price=68000
            ),
            
            "premium_1200": UniSecPackage(
                name="UniSec Premium (1000-1600kVA)",
                description="DG + 2 Trasformatori + Misure + Accoppiamento",
                suitable_for="Grandi industrie, data center, ospedali critici",
                power_range=(1000, 1600),
                units=[
                    UniSecUnit(
                        unit_type=UniSecUnitType.DG,
                        width_mm=600,
                        description="DG con protezioni avanzate",
                        includes=[
                            "Interruttore MT 1250A con comando motorizzato",
                            "Protezione REF630 distanza/direzionale",
                            "Ridondanza comunicazione IEC 61850"
                        ]
                    ),
                    UniSecUnit(
                        unit_type=UniSecUnitType.TR,
                        width_mm=500,
                        description="Trasformatore 1 - Principale"
                    ),
                    UniSecUnit(
                        unit_type=UniSecUnitType.TR,
                        width_mm=500,
                        description="Trasformatore 2 - Ridondanza"
                    ),
                    UniSecUnit(
                        unit_type=UniSecUnitType.MEASURING,
                        width_mm=375,
                        description="Unità Misure fiscali",
                        includes=[
                            "TA/TV classe 0.2s per fatturazione",
                            "Contatori fiscali certificati MID",
                            "Sistema acquisizione dati energetici"
                        ]
                    ),
                    UniSecUnit(
                        unit_type=UniSecUnitType.COUPLING,
                        width_mm=750,
                        description="Accoppiamento Sbarre",
                        includes=[
                            "Interruttore accoppiamento sbarre",
                            "Sezionatori per manutenzione separata",
                            "Logiche automatiche di trasferimento"
                        ]
                    )
                ],
                total_width=2725,
                included_features=[
                    "✅ Tutto dello Standard +",
                    "✅ Doppia sbarra sezionata per continuità N-1",
                    "✅ Unità misure fiscali dedicata MID",
                    "✅ Telecontrollo completo IEC 61850 con ridondanza",
                    "✅ Logiche automatiche di trasferimento carichi",
                    "✅ Protezioni selettive avanzate direzionali",
                    "✅ Monitoraggio Power Quality completo",
                    "✅ Interfaccia SCADA e Building Management"
                ],
                base_price=78000,
                typical_total_price=125000
            ),
            
            "compact_250": UniSecPackage(
                name="UniSec Compact (100-300kVA)",
                description="DG + Trasformatore - Soluzione compatta",
                suitable_for="Piccoli edifici, negozi, studi professionali",
                power_range=(100, 300),
                units=[
                    UniSecUnit(
                        unit_type=UniSecUnitType.DG,
                        width_mm=375,
                        description="DG compatto 630A",
                        includes=[
                            "Interruttore MT VD4-P 630A",
                            "Protezione REF601 base",
                            "Sezionatori integrati"
                        ]
                    ),
                    UniSecUnit(
                        unit_type=UniSecUnitType.TR,
                        width_mm=375,
                        description="Partenza Trasformatore compatta",
                        includes=[
                            "Interruttore MT 200A",
                            "Protezione integrata"
                        ]
                    )
                ],
                total_width=750,
                included_features=[
                    "✅ Soluzione più compatta disponibile",
                    "✅ Struttura UniSec IP3X",
                    "✅ Protezioni base CEI 0-16",
                    "✅ Cablaggio essenziale",
                    "✅ Certificazione CE"
                ],
                base_price=18500,
                typical_total_price=32000
            )
        }
    
    def find_compatible_packages(self, power_kva: float) -> List[str]:
        """Trova pacchetti compatibili con potenza"""
        compatible = []
        for pkg_id, pkg in self.packages.items():
            min_power, max_power = pkg.power_range
            if min_power <= power_kva <= max_power:
                compatible.append(pkg_id)
        return compatible
    
    def get_package_recommendation(self, power_kva: float, service_type: str, redundancy: bool = False) -> Optional[str]:
        """Raccomandazione intelligente pacchetto"""
        compatible = self.find_compatible_packages(power_kva)
        
        if not compatible:
            return None
            
        # Logica raccomandazione basata su criteri
        if service_type == "essenziale" or redundancy:
            # Per servizio essenziale o con ridondanza, prendi il più completo
            if "premium_1200" in compatible:
                return "premium_1200"
            elif "standard_800" in compatible:
                return "standard_800"
            else:
                return compatible[-1] if compatible else None
                
        elif service_type == "privilegiata":
            # Per servizio privilegiato
            if power_kva > 600:
                return "standard_800" if "standard_800" in compatible else compatible[0]
            else:
                return "basic_400" if "basic_400" in compatible else compatible[0]
        else:
            # Servizio normale - soluzione più economica adeguata
            if power_kva < 300:
                return "compact_250" if "compact_250" in compatible else compatible[0]
            else:
                return compatible[0]  # Il più economico tra i compatibili

# ===============================================================================
# FUNZIONI PUBBLICHE
# ===============================================================================

def verify_switchgear_compatibility(network_data: Dict, selected_config: str) -> Dict:
    """Funzione pubblica per verifica compatibilità quadro-rete"""
    
    configs = UniSecStandardConfigurations()
    
    if selected_config not in configs.configurations:
        return {"error": f"Configurazione {selected_config} non trovata"}
    
    config_data = configs.configurations[selected_config]
    
    # Verifica cortocircuito
    icp_rete = network_data.get('icc_3phase_ka', 0)
    cc_verification = config_data.verify_short_circuit_compatibility(icp_rete)
    
    # Verifica tensione
    voltage_verification = {
        "network_voltage": network_data.get('voltage_kv', 0),
        "switchgear_voltage": config_data.electrical_specs.rated_voltage_kv,
        "compatible": network_data.get('voltage_kv', 0) <= config_data.electrical_specs.rated_voltage_kv
    }
    
    return {
        "short_circuit_verification": cc_verification,
        "voltage_verification": voltage_verification,
        "overall_compatible": cc_verification["compatible"] and voltage_verification["compatible"],
        "configuration_specs": config_data.electrical_specs
    }

def get_unisec_summary() -> Dict:
    """Ottieni riepilogo capacità UniSec"""
    configs = UniSecStandardConfigurations()
    packages = UniSecPackageConfigurator()
    
    return {
        "technical_configurations": len(configs.configurations),
        "standard_packages": len(packages.packages),
        "voltage_range": "15-36 kV",
        "current_range": "630-1600 A",
        "short_circuit_range": "16-31.5 kA",
        "package_power_range": "100-1600 kVA",
        "width_range": "750-2725 mm"
    }

# ===============================================================================
# ISTANZE GLOBALI
# ===============================================================================

# Istanze globali per uso nel software
unisec_technical_data = UniSecStandardConfigurations()
unisec_packages = UniSecPackageConfigurator()

# Export delle classi principali
__all__ = [
    'UniSecStandardConfigurations',
    'UniSecPackageConfigurator', 
    'UniSecElectricalSpecs',
    'UniSecTechnicalData',
    'UniSecPackage',
    'UniSecUnit',
    'ServiceContinuity',
    'ArcClassification',
    'UniSecUnitType',
    'verify_switchgear_compatibility',
    'get_unisec_summary',
    'unisec_technical_data',
    'unisec_packages'
]
