"""
Display Utils - Utility per visualizzazione e presentazione dati
Software Cabina MT/BT (not) Professional v3.5 - OTTIMIZZATO
"""

import streamlit as st
import pandas as pd
from typing import Dict, List, Any, Optional, Union
import json

# ===============================================================================
# FORMATTAZIONE E PRESENTAZIONE DATI
# ===============================================================================

def format_engineering_value(value: float, unit: str = "", decimals: int = 1) -> str:
    """
    Formatta valori ingegneristici con prefissi SI
    
    Args:
        value: Valore numerico
        unit: Unità di misura
        decimals: Decimali da mostrare
    
    Returns:
        Stringa formattata (es: "1.2k", "150M")
    """
    if abs(value) >= 1e6:
        return f"{value/1e6:.{decimals}f}M{unit}"
    elif abs(value) >= 1e3:
        return f"{value/1e3:.{decimals}f}k{unit}"
    elif abs(value) >= 1:
        return f"{value:.{decimals}f}{unit}"
    elif abs(value) >= 1e-3:
        return f"{value*1e3:.{decimals}f}m{unit}"
    elif abs(value) >= 1e-6:
        return f"{value*1e6:.{decimals}f}µ{unit}"
    else:
        return f"{value:.{decimals}e}{unit}"

def format_currency(amount: float, currency: str = "€", decimals: int = 0) -> str:
    """Formatta valuta con separatori di migliaia"""
    if decimals == 0:
        return f"{currency}{amount:,.0f}"
    else:
        return f"{currency}{amount:,.{decimals}f}"

def format_percentage(value: float, decimals: int = 1, show_sign: bool = True) -> str:
    """Formatta percentuale"""
    sign = "+" if value > 0 and show_sign else ""
    return f"{sign}{value:.{decimals}f}%"

def format_electrical_specs(specs: Dict[str, Any]) -> Dict[str, str]:
    """
    Formatta specifiche elettriche per visualizzazione
    
    Args:
        specs: Dict con specifiche elettriche grezze
    
    Returns:
        Dict con valori formattati
    """
    formatted = {}
    
    # Mapping unità e formattazione
    formatters = {
        'voltage': lambda v: format_engineering_value(v, 'V'),
        'current': lambda c: format_engineering_value(c, 'A'),
        'power': lambda p: format_engineering_value(p, 'W'),
        'resistance': lambda r: format_engineering_value(r, 'Ω'),
        'frequency': lambda f: format_engineering_value(f, 'Hz'),
        'energy': lambda e: format_engineering_value(e, 'Wh'),
        'cost': lambda c: format_currency(c),
        'percentage': lambda p: format_percentage(p),
        'efficiency': lambda e: format_percentage(e * 100, 2)
    }
    
    for key, value in specs.items():
        if isinstance(value, (int, float)):
            # Determina il tipo di formato in base al nome della chiave
            format_type = None
            for fmt_key, formatter in formatters.items():
                if fmt_key in key.lower():
                    format_type = formatter
                    break
            
            if format_type:
                formatted[key] = format_type(value)
            else:
                formatted[key] = str(value)
        else:
            formatted[key] = str(value)
    
    return formatted

# ===============================================================================
# TABELLE E SCHEDE TECNICHE
# ===============================================================================

def technical_datasheet(title: str, 
                       specifications: Dict[str, Any],
                       category_groups: Optional[Dict[str, List[str]]] = None) -> None:
    """
    Crea una scheda tecnica organizzata
    
    Args:
        title: Titolo della scheda
        specifications: Dict con specifiche tecniche
        category_groups: Raggruppamento opzionale per categorie
    """
    st.subheader(f"📋 {title}")
    
    formatted_specs = format_electrical_specs(specifications)
    
    if category_groups:
        # Layout organizzato per categorie
        tabs = st.tabs(list(category_groups.keys()))
        
        for tab, category in zip(tabs, category_groups.keys()):
            with tab:
                category_specs = {k: formatted_specs[k] for k in category_groups[category] if k in formatted_specs}
                _display_specs_table(category_specs)
    else:
        # Layout semplice
        _display_specs_table(formatted_specs)

def _display_specs_table(specs: Dict[str, str]) -> None:
    """Helper per visualizzare tabella specifiche"""
    if not specs:
        st.info("Nessuna specifica disponibile")
        return
    
    # Crea DataFrame per visualizzazione tabellare
    specs_data = [{'Parametro': k, 'Valore': v} for k, v in specs.items()]
    specs_df = pd.DataFrame(specs_data)
    
    st.dataframe(specs_df, use_container_width=True, hide_index=True)

def comparison_table(items: Dict[str, Dict[str, Any]], 
                    title: str = "Confronto Opzioni") -> None:
    """
    Tabella di confronto tra opzioni
    
    Args:
        items: Dict nome_opzione: specifiche
        title: Titolo della tabella
    """
    st.subheader(title)
    
    if not items:
        st.warning("⚠️ Nessun elemento da confrontare")
        return
    
    # Prepara dati per confronto
    comparison_data = []
    all_keys = set()
    
    # Raccogli tutte le chiavi possibili
    for item_specs in items.values():
        all_keys.update(item_specs.keys())
    
    # Crea righe per ogni parametro
    for key in sorted(all_keys):
        row = {'Parametro': key}
        for item_name, item_specs in items.items():
            value = item_specs.get(key, 'N/A')
            if isinstance(value, (int, float)):
                formatted_specs = format_electrical_specs({key: value})
                row[item_name] = formatted_specs.get(key, str(value))
            else:
                row[item_name] = str(value)
        comparison_data.append(row)
    
    comparison_df = pd.DataFrame(comparison_data)
    
    # Evidenzia la colonna migliore per metriche numeriche
    st.dataframe(comparison_df, use_container_width=True, hide_index=True)

# ===============================================================================
# DASHBOARD E SUMMARY
# ===============================================================================

def project_summary_dashboard(project_data: Dict[str, Any]) -> None:
    """
    Dashboard riassuntiva del progetto
    
    Args:
        project_data: Tutti i dati del progetto
    """
    st.header("📊 Dashboard Progetto")
    
    # KPI principali
    col1, col2, col3, col4 = st.columns(4)
    
    kpis = extract_project_kpis(project_data)
    
    with col1:
        st.metric(
            "Potenza Totale", 
            format_engineering_value(kpis.get('total_power', 0), 'VA'),
            delta=f"Utilizzo: {format_percentage(kpis.get('utilization', 0))}"
        )
    
    with col2:
        st.metric(
            "Costo Totale", 
            format_currency(kpis.get('total_cost', 0)),
            delta=f"{format_currency(kpis.get('cost_per_kva', 0))}/kVA"
        )
    
    with col3:
        st.metric(
            "Conformità", 
            format_percentage(kpis.get('compliance_score', 0)),
            delta="Normative" if kpis.get('compliance_score', 0) >= 90 else "Da migliorare"
        )
    
    with col4:
        st.metric(
            "Progresso", 
            f"{kpis.get('completed_steps', 0)}/{kpis.get('total_steps', 9)}",
            delta=format_percentage(kpis.get('completion_percentage', 0))
        )
    
    # Grafici di stato
    st.markdown("---")
    _display_status_charts(project_data)

def extract_project_kpis(project_data: Dict[str, Any]) -> Dict[str, float]:
    """Estrae KPI dal progetto"""
    kpis = {}
    
    # Potenza
    calc_results = project_data.get('calculation_results', {})
    kpis['total_power'] = calc_results.get('total_power_kva', 0) * 1000  # Converti in VA
    
    # Costi (somma componenti principali)
    transformer_cost = project_data.get('transformer_config', {}).get('total_cost', 0)
    bt_cost = project_data.get('bt_switchgear_config', {}).get('total_cost', 0)
    earthing_cost = project_data.get('earthing_system_final', {}).get('materials_cost', 0)
    kpis['total_cost'] = transformer_cost + bt_cost + earthing_cost
    
    # Costo per kVA
    if kpis['total_power'] > 0:
        kpis['cost_per_kva'] = kpis['total_cost'] / (kpis['total_power'] / 1000)
    else:
        kpis['cost_per_kva'] = 0
    
    # Utilizzo trasformatore
    transformer_config = project_data.get('transformer_config', {})
    transformer_power = transformer_config.get('total_power', 1)
    load_power = calc_results.get('total_power_kva', 0)
    kpis['utilization'] = (load_power / transformer_power * 100) if transformer_power > 0 else 0
    
    # Conformità (media delle verifiche)
    kpis['compliance_score'] = 85.0  # Placeholder
    
    # Progresso
    completed_steps = len(project_data.get('completed_steps', set()))
    total_steps = 9
    kpis['completed_steps'] = completed_steps
    kpis['total_steps'] = total_steps
    kpis['completion_percentage'] = (completed_steps / total_steps * 100) if total_steps > 0 else 0
    
    return kpis

def _display_status_charts(project_data: Dict[str, Any]) -> None:
    """Visualizza grafici di stato del progetto"""
    col1, col2 = st.columns(2)
    
    with col1:
        # Grafico progresso step
        completed_steps = len(project_data.get('completed_steps', set()))
        remaining_steps = 9 - completed_steps
        
        progress_data = pd.DataFrame({
            'Stato': ['Completati', 'Rimanenti'],
            'Count': [completed_steps, remaining_steps]
        })
        
        st.subheader("📈 Progresso Step")
        st.bar_chart(progress_data.set_index('Stato'))
    
    with col2:
        # Distribuzione costi
        costs = {
            'Trasformatori': project_data.get('transformer_config', {}).get('total_cost', 0),
            'Quadro BT': project_data.get('bt_switchgear_config', {}).get('total_cost', 0),
            'Impianto Terra': project_data.get('earthing_system_final', {}).get('materials_cost', 0)
        }
        
        # Filtra costi non nulli
        costs = {k: v for k, v in costs.items() if v > 0}
        
        if costs:
            st.subheader("💰 Distribuzione Costi")
            cost_df = pd.DataFrame(list(costs.items()), columns=['Componente', 'Costo'])
            st.bar_chart(cost_df.set_index('Componente'))
        else:
            st.info("Dati costi non disponibili")

# ===============================================================================
# EXPORT E REPORTING
# ===============================================================================

def generate_technical_report(project_data: Dict[str, Any]) -> str:
    """
    Genera report tecnico in formato markdown
    
    Args:
        project_data: Dati completi del progetto
    
    Returns:
        Report in formato markdown
    """
    report_lines = [
        "# RELAZIONE TECNICA - PROGETTO CABINA MT/BT",
        "",
        f"**Data generazione:** {pd.Timestamp.now().strftime('%d/%m/%Y %H:%M')}",
        "",
        "## 📊 DATI GENERALI",
        ""
    ]
    
    # Dati distributore
    distributor_data = project_data.get('distributor_data', {})
    if distributor_data:
        report_lines.extend([
            "### Dati Distributore",
            f"- **Tensione nominale:** {distributor_data.get('voltage_kv', 'N/A')} kV",
            f"- **Corrente di cortocircuito:** {distributor_data.get('icc_3phase_ka', 'N/A')} kA",
            f"- **Stato del neutro:** {distributor_data.get('neutral_state', 'N/A')}",
            f"- **Corrente guasto terra:** {distributor_data.get('earth_fault_current_a', 'N/A')} A",
            ""
        ])
    
    # Carichi
    calc_results = project_data.get('calculation_results', {})
    if calc_results:
        report_lines.extend([
            "### Carichi Elettrici",
            f"- **Potenza attiva totale:** {calc_results.get('total_power_kw', 'N/A')} kW",
            f"- **Potenza apparente totale:** {calc_results.get('total_power_kva', 'N/A')} kVA", 
            f"- **Fattore di potenza medio:** {calc_results.get('average_cos_phi', 'N/A')}",
            ""
        ])
    
    # Trasformatori
    transformer_config = project_data.get('transformer_config', {})
    if transformer_config:
        report_lines.extend([
            "### Trasformatori",
            f"- **Configurazione:** {transformer_config.get('num_transformers', 'N/A')} x {transformer_config.get('power_kva', 'N/A')} kVA",
            f"- **Serie:** {transformer_config.get('series', 'N/A')}",
            f"- **Costo totale:** {format_currency(transformer_config.get('total_cost', 0))}",
            ""
        ])
    
    # Quadro BT
    bt_config = project_data.get('bt_switchgear_config', {})
    if bt_config:
        main_breaker = bt_config.get('main_breaker', {})
        report_lines.extend([
            "### Quadro BT",
            f"- **Interruttore generale:** {main_breaker.get('name', 'N/A')}",
            f"- **Numero partenze:** {bt_config.get('num_feeders', 'N/A')}",
            f"- **Costo totale:** {format_currency(bt_config.get('total_cost', 0))}",
            ""
        ])
    
    # Impianto di terra
    earthing_config = project_data.get('earthing_system_final', {})
    if earthing_config:
        report_lines.extend([
            "### Impianto di Terra",
            f"- **Resistenza di terra:** {earthing_config.get('earth_resistance', 'N/A')} Ω",
            f"- **Numero elettrodi:** {earthing_config.get('num_electrodes', 'N/A')}",
            f"- **Conforme CEI 11-1:** {'✅' if earthing_config.get('cei_11_1_compliant') else '❌'}",
            ""
        ])
    
    # Conformità normative
    report_lines.extend([
        "## 📋 CONFORMITÀ NORMATIVE",
        ""
    ])
    
    return "\n".join(report_lines)

def export_project_data(project_data: Dict[str, Any], format_type: str = "json") -> None:
    """
    Esporta i dati del progetto in vari formati
    
    Args:
        project_data: Dati del progetto
        format_type: Formato di export ('json', 'markdown', 'csv')
    """
    project_name = project_data.get('project_name', 'progetto_cabina')
    timestamp = pd.Timestamp.now().strftime('%Y%m%d_%H%M')
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # Export JSON
        json_data = json.dumps(project_data, indent=2, default=str, ensure_ascii=False)
        st.download_button(
            label="📥 Export JSON",
            data=json_data,
            file_name=f"{project_name}_{timestamp}.json",
            mime="application/json"
        )
    
    with col2:
        # Export Markdown Report
        markdown_report = generate_technical_report(project_data)
        st.download_button(
            label="📄 Report Markdown",
            data=markdown_report,
            file_name=f"relazione_{project_name}_{timestamp}.md",
            mime="text/markdown"
        )
    
    with col3:
        # Export CSV summary
        kpis = extract_project_kpis(project_data)
        csv_data = pd.DataFrame([kpis]).to_csv(index=False)
        st.download_button(
            label="📊 Riassunto CSV",
            data=csv_data,
            file_name=f"riassunto_{project_name}_{timestamp}.csv",
            mime="text/csv"
        )

# ===============================================================================
# UTILITY VISUALIZZAZIONE SPECIALI
# ===============================================================================

def electrical_diagram_placeholder(title: str, components: List[str]) -> None:
    """
    Placeholder per diagrammi elettrici (da sostituire con vera implementazione)
    
    Args:
        title: Titolo del diagramma
        components: Lista componenti da mostrare
    """
    st.subheader(f"⚡ {title}")
    
    # Diagramma testuale semplificato
    diagram_text = f"""
    {title}
    {'='*len(title)}
    
    Componenti principali:
    """
    
    for i, component in enumerate(components, 1):
        diagram_text += f"\n{i:2d}. {component}"
    
    st.code(diagram_text, language=None)
    
    st.info("💡 **Nota:** Diagramma semplificato. Per diagrammi CAD dettagliati, esportare i dati e usare software specializzato.")

def system_status_indicator(system_name: str, 
                           status: str,
                           details: Optional[Dict[str, Any]] = None) -> None:
    """
    Indicatore di stato per sistemi/componenti
    
    Args:
        system_name: Nome del sistema
        status: 'ok', 'warning', 'error', 'unknown'
        details: Dettagli opzionali sullo stato
    """
    status_configs = {
        'ok': {'color': 'green', 'icon': '✅', 'label': 'OPERATIVO'},
        'warning': {'color': 'orange', 'icon': '⚠️', 'label': 'ATTENZIONE'},
        'error': {'color': 'red', 'icon': '❌', 'label': 'ERRORE'},
        'unknown': {'color': 'gray', 'icon': '❓', 'label': 'SCONOSCIUTO'}
    }
    
    config = status_configs.get(status, status_configs['unknown'])
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown(f"**{system_name}**")
        if details:
            for key, value in details.items():
                st.caption(f"{key}: {value}")
    
    with col2:
        if status == 'ok':
            st.success(f"{config['icon']} {config['label']}")
        elif status == 'warning':
            st.warning(f"{config['icon']} {config['label']}")
        elif status == 'error':
            st.error(f"{config['icon']} {config['label']}")
        else:
            st.info(f"{config['icon']} {config['label']}")

# ===============================================================================
# UTILITY FINALI
# ===============================================================================

def safe_display(content_func: callable, 
                error_message: str = "Errore nel caricamento contenuto") -> None:
    """
    Wrapper sicuro per funzioni di display
    
    Args:
        content_func: Funzione che genera il contenuto
        error_message: Messaggio da mostrare in caso di errore
    """
    try:
        content_func()
    except Exception as e:
        st.error(f"{error_message}: {str(e)}")
        
        # Mostra traceback in modalità debug
        if st.session_state.get('debug_mode', False):
            st.exception(e)

class ProgressTracker:
    """
    Classe per tracciare il progresso di operazioni lunghe
    """
    
    def __init__(self, total_steps: int, description: str = "Elaborazione"):
        self.total_steps = total_steps
        self.current_step = 0
        self.description = description
        self.progress_bar = st.progress(0)
        self.status_text = st.empty()
    
    def update(self, step_description: str = ""):
        """Aggiorna il progresso"""
        self.current_step += 1
        progress = self.current_step / self.total_steps
        
        self.progress_bar.progress(progress)
        
        status_msg = f"{self.description}: {self.current_step}/{self.total_steps}"
        if step_description:
            status_msg += f" - {step_description}"
        
        self.status_text.text(status_msg)
    
    def complete(self, final_message: str = "Completato!"):
        """Completa il progresso"""
        self.progress_bar.progress(1.0)
        self.status_text.success(f"✅ {final_message}")
