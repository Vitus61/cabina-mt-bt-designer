"""
UI Step Components - Componenti UI riutilizzabili per tutti gli step
Software Cabina MT/BT Professional v2.0 - OTTIMIZZATO
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from typing import Dict, List, Any, Optional, Union

# ===============================================================================
# COMPONENTI METRICHE E PANNELLI
# ===============================================================================

def metrics_panel(metrics: Dict[str, str], title: Optional[str] = None):
    """
    Crea un pannello di metriche organizzato
    
    Args:
        metrics: Dict con nome_metrica: valore
        title: Titolo opzionale del pannello
    """
    if title:
        st.subheader(title)
    
    cols = st.columns(len(metrics))
    for i, (label, value) in enumerate(metrics.items()):
        with cols[i]:
            # Estrae delta se presente nel valore
            if isinstance(value, dict) and 'value' in value:
                st.metric(label, value['value'], delta=value.get('delta'))
            else:
                st.metric(label, value)

def info_panel(content: Union[str, Dict[str, Any]], panel_type: str = "info"):
    """
    Crea un pannello informativo stilizzato
    
    Args:
        content: Contenuto del pannello (str o dict con structured content)
        panel_type: 'info', 'success', 'warning', 'error'
    """
    panel_functions = {
        'info': st.info,
        'success': st.success,
        'warning': st.warning,
        'error': st.error
    }
    
    panel_func = panel_functions.get(panel_type, st.info)
    
    if isinstance(content, dict):
        formatted_content = format_structured_content(content)
        panel_func(formatted_content)
    else:
        panel_func(content)

def format_structured_content(content: Dict[str, Any]) -> str:
    """Formatta contenuto strutturato per i pannelli"""
    lines = []
    
    if 'title' in content:
        lines.append(f"**{content['title']}**\n")
    
    if 'items' in content:
        for item in content['items']:
            lines.append(f"• {item}")
    
    if 'footer' in content:
        lines.append(f"\n{content['footer']}")
    
    return '\n'.join(lines)

# ===============================================================================
# TABELLE E DATAFRAME UTILITY
# ===============================================================================

def enhanced_dataframe(data: Union[pd.DataFrame, List[Dict]], 
                      title: Optional[str] = None,
                      height: int = 250,
                      enable_download: bool = False) -> None:
    """
    Mostra dataframe ottimizzato con funzionalità extra
    
    Args:
        data: DataFrame o lista di dizionari
        title: Titolo della tabella
        height: Altezza in pixel
        enable_download: Abilita download CSV
    """
    if title:
        st.subheader(title)
    
    # Converte a DataFrame se necessario
    if isinstance(data, list):
        df = pd.DataFrame(data)
    else:
        df = data
    
    # Mostra la tabella
    st.dataframe(df, use_container_width=True, height=height)
    
    # Opzione download
    if enable_download and not df.empty:
        csv = df.to_csv(index=False)
        st.download_button(
            label="📥 Scarica CSV",
            data=csv,
            file_name=f"dati_{title.replace(' ', '_').lower() if title else 'tabella'}.csv",
            mime="text/csv"
        )

def editable_load_table(loads: List[Any], on_change_callback: callable = None) -> List[Any]:
    """
    Tabella carichi editabile con azioni integrate
    
    Args:
        loads: Lista di oggetti carico
        on_change_callback: Funzione chiamata su modifica
    
    Returns:
        Lista carichi modificata
    """
    if not loads:
        st.warning("⚠️ Nessun carico inserito.")
        return loads
    
    # Converte carichi in formato tabella
    loads_data = []
    for i, load in enumerate(loads):
        loads_data.append({
            "ID": i,
            "Nome": load.name,
            "Tipo": load.type_str,
            "Potenza (kW)": load.power_kw,
            "Quantità": load.quantity,
            "Ku": load.ku_factor,
            "Cos φ": load.cos_phi
        })
    
    df = pd.DataFrame(loads_data)
    
    # Editor integrato
    with st.expander("✏️ Modifica Carichi", expanded=False):
        selected_idx = st.selectbox(
            "Seleziona carico da modificare:",
            options=range(len(loads)),
            format_func=lambda x: f"{x}: {loads[x].name}"
        )
        
        if selected_idx is not None:
            modified_load = edit_single_load(loads[selected_idx], selected_idx)
            
            col1, col2, col3 = st.columns([1, 1, 1])
            
            with col1:
                if st.button("💾 Salva", key=f"save_{selected_idx}"):
                    loads[selected_idx] = modified_load
                    if on_change_callback:
                        on_change_callback()
                    st.success("✅ Salvato!")
                    st.rerun()
            
            with col2:
                if st.button("🗑️ Elimina", key=f"del_{selected_idx}"):
                    loads.pop(selected_idx)
                    if on_change_callback:
                        on_change_callback()
                    st.success("✅ Eliminato!")
                    st.rerun()
            
            with col3:
                if st.button("📋 Duplica", key=f"dup_{selected_idx}"):
                    new_load = duplicate_load(loads[selected_idx])
                    loads.append(new_load)
                    if on_change_callback:
                        on_change_callback()
                    st.success("✅ Duplicato!")
                    st.rerun()
    
    # Mostra tabella finale
    enhanced_dataframe(df, "📊 Carichi Configurati")
    
    return loads

def edit_single_load(load: Any, index: int) -> Any:
    """Editor per singolo carico"""
    from calculations.loads import SimpleLoad  # Import locale
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        name = st.text_input("Nome:", value=load.name, key=f"name_{index}")
        power = st.number_input("Potenza (kW):", value=float(load.power_kw), min_value=0.1, key=f"power_{index}")
    
    with col2:
        load_type = st.selectbox(
            "Tipo:",
            ["motori", "illuminazione", "prese", "riscaldamento", "condizionamento"],
            index=0 if load.type_str not in ["motori", "illuminazione", "prese", "riscaldamento", "condizionamento"] 
                  else ["motori", "illuminazione", "prese", "riscaldamento", "condizionamento"].index(load.type_str),
            key=f"type_{index}"
        )
        quantity = st.number_input("Quantità:", value=int(load.quantity), min_value=1, key=f"qty_{index}")
    
    with col3:
        ku = st.number_input("Ku:", value=float(load.ku_factor), min_value=0.1, max_value=1.0, key=f"ku_{index}")
        cos_phi = st.number_input("Cos φ:", value=float(load.cos_phi), min_value=0.1, max_value=1.0, key=f"cos_{index}")
    
    return SimpleLoad(name, load_type, power, quantity, ku, cos_phi)

def duplicate_load(original_load: Any) -> Any:
    """Duplica un carico"""
    from calculations.loads import SimpleLoad  # Import locale
    
    return SimpleLoad(
        f"{original_load.name}_copia",
        original_load.type_str,
        original_load.power_kw,
        original_load.quantity,
        original_load.ku_factor,
        original_load.cos_phi
    )

# ===============================================================================
# GRAFICI E VISUALIZZAZIONI
# ===============================================================================

def power_distribution_chart(load_distribution: Dict[str, float], 
                           title: str = "Distribuzione Carichi",
                           chart_type: str = "pie",
                           show_stats: bool = True) -> None:
    """
    Crea grafico distribuzione potenze
    
    Args:
        load_distribution: Dict tipo_carico: potenza
        title: Titolo grafico
        chart_type: 'pie', 'bar', 'donut'
        show_stats: Se True mostra le statistiche a lato (default: True)
    """
    if not load_distribution:
        st.warning("⚠️ Nessun dato per il grafico")
        return
    
    # Colori personalizzati per tipologie
    colors = {
        'motori': '#FF6B6B',
        'illuminazione': '#4ECDC4', 
        'prese': '#45B7D1',
        'riscaldamento': '#FFA07A',
        'condizionamento': '#98D8C8',
        'forni': '#F7DC6F',
        'saldatrici': '#BB8FCE',
        'generale': '#85C1E9'
    }
    
    labels = list(load_distribution.keys())
    values = list(load_distribution.values())
    chart_colors = [colors.get(label.lower(), '#BDC3C7') for label in labels]
    
    if chart_type == "pie":
        fig = go.Figure(data=[go.Pie(
            labels=labels,
            values=values,
            textinfo='label+percent',
            textposition='auto',
            hovertemplate='<b>%{label}</b><br>Potenza: %{value:.1f} kW<br>Percentuale: %{percent}<br><extra></extra>',
            marker=dict(colors=chart_colors, line=dict(color='#FFFFFF', width=1))
        )])
        
        fig.update_layout(
            title={'text': title, 'x': 0.5, 'xanchor': 'center'},
            showlegend=True,
            height=400
        )
    
    elif chart_type == "bar":
        fig = go.Figure(data=[go.Bar(
            x=labels,
            y=values,
            marker_color=chart_colors,
            text=[f"{v:.1f} kW" for v in values],
            textposition='auto'
        )])
        
        fig.update_layout(
            title=title,
            xaxis_title="Tipologia",
            yaxis_title="Potenza (kW)",
            height=400
        )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Stats compatte a lato (opzionali)
    if show_stats:
        col1, col2 = st.columns([3, 1])
        with col2:
            total_power = sum(values)
            dominant_type = max(load_distribution, key=load_distribution.get)
            dominant_percent = (load_distribution[dominant_type] / total_power * 100) if total_power > 0 else 0
            
            st.metric("Totale", f"{total_power:.0f} kW")
            st.metric("Dominante", f"{dominant_type.title()}")
            st.metric("Percentuale", f"{dominant_percent:.1f}%")

# ===============================================================================
# FORM E INPUT COMPONENTI
# ===============================================================================

def configuration_form(config_fields: Dict[str, Dict], 
                      current_values: Dict = None,
                      form_key: str = "config_form") -> Dict[str, Any]:
    """
    Form di configurazione generico e riutilizzabile
    
    Args:
        config_fields: Dict con campo: {type, options, default, help}
        current_values: Valori attuali (per editing)
        form_key: Chiave univoca del form
    
    Returns:
        Dict con valori inseriti
    """
    if current_values is None:
        current_values = {}
    
    results = {}
    
    with st.form(form_key):
        cols = st.columns(min(3, len(config_fields)))  # Max 3 colonne
        
        for i, (field_name, field_config) in enumerate(config_fields.items()):
            col_idx = i % len(cols)
            
            with cols[col_idx]:
                field_type = field_config['type']
                current_value = current_values.get(field_name, field_config.get('default'))
                help_text = field_config.get('help')
                
                if field_type == 'number':
                    results[field_name] = st.number_input(
                        field_name,
                        value=current_value,
                        min_value=field_config.get('min_value', 0.0),
                        max_value=field_config.get('max_value', 1000.0),
                        step=field_config.get('step', 0.1),
                        help=help_text
                    )
                
                elif field_type == 'selectbox':
                    index = field_config['options'].index(current_value) if current_value in field_config['options'] else 0
                    results[field_name] = st.selectbox(
                        field_name,
                        options=field_config['options'],
                        index=index,
                        help=help_text
                    )
                
                elif field_type == 'text':
                    results[field_name] = st.text_input(
                        field_name,
                        value=current_value,
                        help=help_text
                    )
                
                elif field_type == 'slider':
                    results[field_name] = st.slider(
                        field_name,
                        min_value=field_config.get('min_value', 0.0),
                        max_value=field_config.get('max_value', 1.0),
                        value=current_value,
                        step=field_config.get('step', 0.1),
                        help=help_text
                    )
        
        submitted = st.form_submit_button("💾 Applica Configurazione")
        
        if submitted:
            return results
        
        return {}

def confirmation_dialog(message: str, 
                       confirm_text: str = "✅ Conferma",
                       cancel_text: str = "❌ Annulla",
                       dialog_type: str = "info") -> bool:
    """
    Dialog di conferma stilizzato
    
    Args:
        message: Messaggio del dialog
        confirm_text: Testo bottone conferma
        cancel_text: Testo bottone annulla
        dialog_type: Tipo di dialog (info, warning, error)
    
    Returns:
        True se confermato
    """
    info_panel(message, dialog_type)
    
    col1, col2, col3 = st.columns([1, 1, 2])
    
    with col1:
        if st.button(confirm_text, type="primary"):
            return True
    
    with col2:
        if st.button(cancel_text):
            return False
    
    return False

# ===============================================================================
# PROGRESS E STATUS COMPONENTS
# ===============================================================================

def step_progress_indicator(current_step: int, 
                          completed_steps: set,
                          total_steps: int = 9) -> None:
    """
    Indicatore di progresso degli step
    
    Args:
        current_step: Step corrente
        completed_steps: Set di step completati
        total_steps: Numero totale di step
    """
    progress = len(completed_steps) / total_steps
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.progress(progress)
        st.caption(f"Progresso: {len(completed_steps)}/{total_steps} step completati")
    
    with col2:
        st.metric("Step Corrente", f"{current_step}/{total_steps}")

def status_badge(status: str, message: str = "") -> None:
    """
    Badge di status colorato
    
    Args:
        status: 'success', 'warning', 'error', 'info'
        message: Messaggio associato
    """
    status_configs = {
        'success': {'color': 'green', 'icon': '✅', 'func': st.success},
        'warning': {'color': 'orange', 'icon': '⚠️', 'func': st.warning},
        'error': {'color': 'red', 'icon': '❌', 'func': st.error},
        'info': {'color': 'blue', 'icon': 'ℹ️', 'func': st.info}
    }
    
    config = status_configs.get(status, status_configs['info'])
    
    if message:
        config['func'](f"{config['icon']} {message}")
    else:
        st.write(f"{config['icon']} {status.title()}")

# ===============================================================================
# UTILITY FUNCTIONS
# ===============================================================================

def format_currency(amount: float, currency: str = "€") -> str:
    """Formatta valuta con separatori"""
    return f"{currency}{amount:,.0f}"

def format_percentage(value: float, decimals: int = 1) -> str:
    """Formatta percentuale"""
    return f"{value:.{decimals}f}%"

def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Divisione sicura con valore di default"""
    return numerator / denominator if denominator != 0 else default

def validate_form_data(data: Dict[str, Any], validators: Dict[str, callable]) -> List[str]:
    """
    Valida dati form con validatori personalizzati
    
    Args:
        data: Dati da validare
        validators: Dict campo: funzione_validazione
    
    Returns:
        Lista di errori (vuota se tutto ok)
    """
    errors = []
    
    for field, validator in validators.items():
        if field in data:
            try:
                if not validator(data[field]):
                    errors.append(f"Campo {field} non valido")
            except Exception as e:
                errors.append(f"Errore validazione {field}: {str(e)}")
    
    return errors

# ===============================================================================
# LAYOUT E CONTAINERS
# ===============================================================================

def create_step_container(title: str, 
                         description: str = "",
                         show_progress: bool = True) -> None:
    """
    Container standard per gli step
    
    Args:
        title: Titolo dello step
        description: Descrizione opzionale
        show_progress: Mostra barra progresso
    """
    st.header(title)
    
    if description:
        st.info(description)
    
    if show_progress:
        step_progress_indicator(
            st.session_state.get('current_step', 1),
            st.session_state.get('completed_steps', set())
        )
    
    st.markdown("---")

def collapsible_section(title: str, content: callable, expanded: bool = False) -> None:
    """
    Sezione collassabile riutilizzabile
    
    Args:
        title: Titolo sezione
        content: Funzione che genera il contenuto
        expanded: Espanso di default
    """
    with st.expander(title, expanded=expanded):
        content()

def side_by_side_comparison(left_title: str, left_content: callable,
                          right_title: str, right_content: callable) -> None:
    """
    Layout di confronto affiancato
    
    Args:
        left_title: Titolo colonna sinistra
        left_content: Funzione contenuto sinistra
        right_title: Titolo colonna destra  
        right_content: Funzione contenuto destra
    """
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"**{left_title}**")
        left_content()
    
    with col2:
        st.markdown(f"**{right_title}**")
        right_content()
