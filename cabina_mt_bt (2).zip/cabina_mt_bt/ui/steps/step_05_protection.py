"""
Step 5: Coordinamento Protezioni - VERSIONE CON FALLBACK ROBUSTO
Layout ottimizzato con sistema fallback a 5 livelli per parametri inrush
"""

import streamlit as st
import pandas as pd
from ui.step_components import create_step_container, metrics_panel, info_panel
from ui.display_utils import technical_datasheet, system_status_indicator
from protection_system.coordination import MTBTCoordinator, ProtectionValidator
from business.equipment_selection import get_equipment_selector

# 🆕 IMPORT DEL DATABASE UNIFICATO
from database.transformers.inrush_parameters import calculate_inrush_current, get_inrush_parameters


def step_5_protection_coordination():
    """Step 5: Coordinamento Protezioni - Versione con fallback robusto"""
    
    create_step_container("🛡️ Step 5: Coordinamento Protezioni")
    
    if 4 not in st.session_state.get('completed_steps', set()):
        st.error("❌ Completa prima lo Step 4 (Progettazione Quadro MT)")
        return
    
    # Recupera dati di progetto
    project_data = _gather_project_data()
    
    # ========== SEZIONE 1: STATUS SISTEMA ==========
    _display_system_status()
    
    # ========== SEZIONE 2: DATI TRASFORMATORE + CALCOLO INRUSH ==========  
    _display_transformer_data_with_inrush_unified(project_data)
    
    # ========== SEZIONE 3: PROTEZIONI MT ==========
    mt_settings = _display_mt_protections_clean(project_data)
    
    # ========== SEZIONE 4: COORDINAMENTO ABB ==========
    abb_results = _display_abb_coordination_clean(project_data)
    
    # ========== SEZIONE 5: VALIDAZIONE FINALE ==========
    _display_final_validation_clean(mt_settings, abb_results, project_data)


def _gather_project_data():
    """Raccoglie dati essenziali"""
    distributor_data = st.session_state.get('distributor_data', {})
    transformer_config = st.session_state.get('transformer_config', {})
    
    total_kva = transformer_config.get('total_power', 800)
    current_bt = (total_kva * 1000) / (415 * 1.732)
    
    return {
        'voltage_kv': distributor_data.get('voltage_kv', 20),
        'icc_3phase_ka': distributor_data.get('icc_3phase_ka', 16),
        'earth_fault_current_a': distributor_data.get('earth_fault_current_a', 20),
        'total_kva': total_kva,
        'current_bt': current_bt,
        'transformer_config': transformer_config,
        'distributor_data': distributor_data
    }


def _display_system_status():
    """Status sistema in modo compatto"""
    
    # Verifica ABB
    try:
        from abb_database.abb_python_interface import ABBEmax2Interface
        abb_status = "🟢 ABB Attivo"
    except ImportError:
        abb_status = "🟡 Standard"
    
    # Status Step 4
    mt_design = st.session_state.get('mt_final_design', {})
    step4_status = "🟢 Completato" if mt_design.get('design_completed') else "🟡 Parziale"
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.info(f"**Sistema ABB:** {abb_status}")
    with col2:
        st.info(f"**Step 4:** {step4_status}")
    with col3:
        design_type = mt_design.get('design_type', 'standard')
        st.info(f"**Modalità:** {design_type.replace('_', ' ').title()}")


def _display_transformer_data_with_inrush_unified(project_data):
    """🎯 SEZIONE UNIFICATA CON FALLBACK ROBUSTO: Dati trasformatore + Calcolo Inrush"""
    
    st.subheader("🔋 Parametri Trasformatore e Corrente di Inserzione")
    
    transformer_config = st.session_state.get('transformer_config', {})
    
    if not transformer_config:
        st.warning("⚠️ Completa Step 3 per vedere i dati del trasformatore")
        return
    
    # ========== DATI PRINCIPALI TRASFORMATORE ==========
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Potenza", f"{transformer_config.get('power_kva', 0)} kVA")
        
    with col2:
        st.metric("Serie", transformer_config.get('series', 'N/A'))
        
    with col3:
        st.metric("Ucc%", f"{transformer_config.get('ucc_percent', 6)}%")
        
    with col4:
        st.metric("Totale", f"{transformer_config.get('total_power', 0)} kVA")
    
    st.markdown("---")
    
    # ========== CALCOLO CORRENTE DI INSERZIONE CON FALLBACK ROBUSTO ==========
    st.markdown("#### ⚡ Calcolo Corrente di Inserzione (CEI 0-16)")
    
    # Parametri di input dal Step 3
    power_kva = transformer_config.get('power_kva', 500)  # 500 = fallback se Step 3 incompleto
    voltage_kv = project_data.get('voltage_kv', 20)  # 20kV = tensione standard MT
    
    # Verifica se stiamo usando dati reali o fallback
    if not transformer_config or 'power_kva' not in transformer_config:
        st.warning("⚠️ **Usando potenza di default:** Completa Step 3 per valore preciso")
    
    # 🛡️ SISTEMA FALLBACK ROBUSTO A 5 LIVELLI
    inrush_data, fallback_info = _calculate_inrush_with_robust_fallback(power_kva, voltage_kv)
    
    # Display status del sistema con indicatori visivi
    _display_database_status(fallback_info)
    
    # Layout a due colonne per calcoli + verifica
    col_calc, col_verify = st.columns([1.3, 0.7])
    
    with col_calc:
        # Procedimento di calcolo step-by-step con informazioni sul fallback
        exact_match = inrush_data.get('exact_match', True)
        
        st.info(f"""
        📐 **Procedimento di Calcolo CEI 0-16:** {fallback_info['status']}
        
        **1. Parametri Trasformatore:**
        • Potenza nominale: **{power_kva} kVA**
        • Tensione primaria: **{voltage_kv} kV**
        • Parametri ({power_kva} kVA{'*' if not exact_match else ''}):
          - Coefficiente inserzione: **ki = {inrush_data['ki']}**  
          - Durata inserzione: **Ti = {inrush_data['Ti']} s**
          - Fonte: **{inrush_data['source']}**
        
        **2. Corrente Nominale Primaria:**
        • Formula: I_r = Sn / (√3 × Un)
        • Calcolo: I_r = {power_kva} / (1.732 × {voltage_kv})
        • Risultato: **I_r = {inrush_data['I_nominal_primary']:.1f} A**
        
        **3. Corrente di Inserzione:**
        • Formula CEI 0-16: I_oi = ki × I_r  
        • Calcolo: I_oi = {inrush_data['ki']} × {inrush_data['I_nominal_primary']:.1f}
        • Risultato: **I_oi = {inrush_data['I_inrush']:.0f} A**
        """)
        
        if not exact_match:
            st.caption(f"* Parametri interpolati per potenza {power_kva} kVA")
        
        # Note specifiche del fallback
        if fallback_info['level'] > 1:
            st.caption(f"💡 **{fallback_info['notes']}**")
            
        # Avviso se in modalità emergenza
        if fallback_info['level'] >= 5:
            st.error("🚨 **Modalità Emergenza Attiva** - Verificare database")
    
    # Calcoli effettivi (usa i dati dal database)
    I_oi = inrush_data['I_inrush']
    
    # Recupera protezione MT da Step 4
    mt_settings = st.session_state.get('mt_protection_settings', {})
    I_TR51 = mt_settings.get('I_2', 200)
    inrush_limit = inrush_data['I_protection_min_cei016']
    margin = I_TR51 - inrush_limit
    inrush_ok = margin >= -0.5  # Tolleranza 0.5A
    
    with col_verify:
        # Box verifica coordinamento
        if mt_settings:
            st.success(f"🛡️ **Protezione MT da Step 4**")
            st.metric("I2 Configurato", f"{I_TR51} A", help="Soglia cortocircuito moderato")
            
            st.markdown("**📋 Verifica CEI 0-16:**")
            st.write(f"• Criterio: I₂ ≥ 0.7 × I_oi")
            st.write(f"• Limite min: **{inrush_limit:.0f} A**")
            st.write(f"• Protezione: **{I_TR51} A**")
            
            # Controllo con stato chiaro
            if inrush_ok:
                if abs(margin) < 1:
                    st.success(f"✅ **Coordinamento OK**")
                    st.caption(f"Limite raggiunto (margine: {margin:+.1f}A)")
                else:
                    st.success(f"✅ **Coordinamento OK**")
                    st.caption(f"Margine sicurezza: {margin:+.1f}A")
            else:
                st.error(f"❌ **Intervento Possibile**")
                st.caption(f"Deficit: {abs(margin):.1f}A")
                st.warning("💡 Aumentare I2 nello Step 4")
        else:
            st.warning("⚠️ **Step 4 Richiesto**")
            st.info(f"""
            **Raccomandazione:**
            
            I2 minimo richiesto:
            **{int(inrush_limit * 1.1)} A**
            (con margine 10%)
            """)
    
    # ========== METRICHE TECNICHE RIEPILOGATIVE ==========
    st.markdown("**🔢 Parametri Tecnici Calcolati:**")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "ki Database", 
            f"{inrush_data['ki']}", 
            help=f"Coefficiente inserzione da database unificato"
        )
        
    with col2:
        st.metric(
            "Ti Durata", 
            f"{inrush_data['Ti']} s", 
            help="Durata transitorio inserzione"
        )
        
    with col3:
        st.metric(
            "I_oi Inserzione", 
            f"{I_oi:.0f} A", 
            help="Corrente massima transitorio"
        )
        
    with col4:
        # Status con indicazione chiara
        if mt_settings:
            status_text = "✅ Coordinato" if inrush_ok else "❌ Critico"
            status_delta = f"Margine: {margin:+.0f}A" if inrush_ok else f"Deficit: {abs(margin):.0f}A"
            delta_color = "normal" if inrush_ok else "inverse"
        else:
            status_text = "⚠️ Da verificare"
            status_delta = None
            delta_color = "off"
            
        st.metric(
            "Status Inrush", 
            status_text,
            delta=status_delta,
            delta_color=delta_color,
            help="Coordinamento con protezione MT"
        )


def _calculate_inrush_with_robust_fallback(power_kva: int, voltage_kv: float) -> tuple:
    """
    🛡️ CALCOLO INRUSH CON FALLBACK ROBUSTO A 5 LIVELLI
    
    Returns:
        tuple: (inrush_data_dict, fallback_info_dict)
    """
    
    # LIVELLO 1: Database primario unificato
    try:
        from database.transformers.inrush_parameters import calculate_inrush_current, get_inrush_parameters
        
        inrush_data = calculate_inrush_current(power_kva, voltage_kv)
        params = get_inrush_parameters(power_kva)
        
        # Successo database primario
        fallback_info = {
            'level': 1,
            'status': '🟢 Database Unificato',
            'notes': 'Database primario operativo',
            'reliability': 'ALTA'
        }
        
        return inrush_data, fallback_info
        
    except ImportError as e:
        reason = f"Database non disponibile: {e}"
        
    except Exception as e:
        reason = f"Errore database: {e}"
    
    # LIVELLO 2: Fallback con dati ridotti ma accurati
    try:
        inrush_data, fallback_info = _fallback_level_2_interpolated(power_kva, voltage_kv, reason)
        return inrush_data, fallback_info
        
    except Exception as e:
        reason += f" | Fallback L2: {e}"
    
    # LIVELLO 3: Fallback con valori più vicini
    try:
        inrush_data, fallback_info = _fallback_level_3_closest(power_kva, voltage_kv, reason)
        return inrush_data, fallback_info
        
    except Exception as e:
        reason += f" | Fallback L3: {e}"
    
    # LIVELLO 4: Valori conservativi
    try:
        inrush_data, fallback_info = _fallback_level_4_conservative(power_kva, voltage_kv, reason)
        return inrush_data, fallback_info
        
    except Exception as e:
        reason += f" | Fallback L4: {e}"
    
    # LIVELLO 5: Emergenza assoluta
    return _fallback_level_5_emergency(power_kva, voltage_kv, reason)


def _fallback_level_2_interpolated(power_kva: int, voltage_kv: float, reason: str) -> tuple:
    """LIVELLO 2: Fallback con interpolazione accurata"""
    
    # Database ridotto ma accurato per interpolazione
    reduced_database = {
        250: {'ki': 11.0, 'Ti': 0.65},
        400: {'ki': 10.5, 'Ti': 0.65},
        500: {'ki': 10.0, 'Ti': 0.70},  # 🎯 VALORE CRITICO
        630: {'ki': 10.1, 'Ti': 0.70},
        800: {'ki': 9.8, 'Ti': 0.70},
        1000: {'ki': 9.0, 'Ti': 0.75},
        1600: {'ki': 8.5, 'Ti': 0.80}
    }
    
    # Trova parametri (interpolati se necessario)
    exact_match = power_kva in reduced_database
    
    if exact_match:
        params = reduced_database[power_kva]
    else:
        # Interpolazione semplice
        powers = sorted(reduced_database.keys())
        
        if power_kva < powers[0]:
            params = reduced_database[powers[0]]
        elif power_kva > powers[-1]:
            params = reduced_database[powers[-1]]
        else:
            # Trova valori per interpolazione
            lower_power = max([p for p in powers if p <= power_kva])
            upper_power = min([p for p in powers if p >= power_kva])
            
            if lower_power == upper_power:
                params = reduced_database[lower_power]
            else:
                # Interpolazione lineare
                factor = (power_kva - lower_power) / (upper_power - lower_power)
                lower_params = reduced_database[lower_power]
                upper_params = reduced_database[upper_power]
                
                params = {
                    'ki': round(lower_params['ki'] + factor * (upper_params['ki'] - lower_params['ki']), 1),
                    'Ti': round(lower_params['Ti'] + factor * (upper_params['Ti'] - lower_params['Ti']), 2)
                }
    
    # Calcoli standard
    I_r = (power_kva * 1000) / (1.732 * voltage_kv * 1000)
    I_oi = params['ki'] * I_r
    I_protection_min = 0.7 * I_oi
    
    inrush_data = {
        'ki': params['ki'],
        'Ti': params['Ti'],
        'I_nominal_primary': I_r,
        'I_inrush': I_oi,
        'I_protection_min_cei016': I_protection_min,
        'source': 'Fallback Interpolato',
        'exact_match': exact_match
    }
    
    fallback_info = {
        'level': 2,
        'status': '🟡 Fallback Interpolato',
        'notes': f'Database ridotto con interpolazione - {reason}',
        'reliability': 'MEDIA-ALTA'
    }
    
    return inrush_data, fallback_info


def _fallback_level_3_closest(power_kva: int, voltage_kv: float, reason: str) -> tuple:
    """LIVELLO 3: Valore più vicino senza interpolazione"""
    
    # Valori essenziali più comuni
    essential_values = {
        400: {'ki': 10.5, 'Ti': 0.65},
        500: {'ki': 10.0, 'Ti': 0.70},  # 🎯 VALORE CRITICO UNIFICATO
        630: {'ki': 10.1, 'Ti': 0.70},
        800: {'ki': 9.8, 'Ti': 0.70},
        1000: {'ki': 9.0, 'Ti': 0.75}
    }
    
    # Trova il più vicino
    closest_power = min(essential_values.keys(), key=lambda x: abs(x - power_kva))
    params = essential_values[closest_power]
    
    # Calcoli
    I_r = (power_kva * 1000) / (1.732 * voltage_kv * 1000)
    I_oi = params['ki'] * I_r
    I_protection_min = 0.7 * I_oi
    
    inrush_data = {
        'ki': params['ki'],
        'Ti': params['Ti'],
        'I_nominal_primary': I_r,
        'I_inrush': I_oi,
        'I_protection_min_cei016': I_protection_min,
        'source': f'Fallback Vicino ({closest_power} kVA)',
        'exact_match': power_kva == closest_power
    }
    
    fallback_info = {
        'level': 3,
        'status': '🟡 Fallback Vicino',
        'notes': f'Usando parametri di {closest_power} kVA - {reason}',
        'reliability': 'MEDIA'
    }
    
    return inrush_data, fallback_info


def _fallback_level_4_conservative(power_kva: int, voltage_kv: float, reason: str) -> tuple:
    """LIVELLO 4: Valori conservativi basati su potenza"""
    
    # Calcolo conservativo empirico
    if power_kva <= 250:
        ki, Ti = 11.0, 0.65
    elif power_kva <= 500:
        ki, Ti = 10.0, 0.70  # 🎯 VALORE CRITICO
    elif power_kva <= 1000:
        ki, Ti = 9.5, 0.75
    else:
        ki, Ti = 8.5, 0.80
    
    # Calcoli
    I_r = (power_kva * 1000) / (1.732 * voltage_kv * 1000)
    I_oi = ki * I_r
    I_protection_min = 0.7 * I_oi
    
    inrush_data = {
        'ki': ki,
        'Ti': Ti,
        'I_nominal_primary': I_r,
        'I_inrush': I_oi,
        'I_protection_min_cei016': I_protection_min,
        'source': 'Fallback Conservativo',
        'exact_match': False
    }
    
    fallback_info = {
        'level': 4,
        'status': '🟠 Fallback Conservativo',
        'notes': f'Valori conservativi calcolati - {reason}',
        'reliability': 'BASSA'
    }
    
    return inrush_data, fallback_info


def _fallback_level_5_emergency(power_kva: int, voltage_kv: float, reason: str) -> tuple:
    """LIVELLO 5: Emergenza assoluta - valori fissi sicuri"""
    
    # Valori di emergenza ultra-conservativi
    ki, Ti = 12.0, 0.60  # Molto conservativi per sicurezza
    
    # Calcoli base
    I_r = (power_kva * 1000) / (1.732 * voltage_kv * 1000)
    I_oi = ki * I_r
    I_protection_min = 0.7 * I_oi
    
    inrush_data = {
        'ki': ki,
        'Ti': Ti,
        'I_nominal_primary': I_r,
        'I_inrush': I_oi,
        'I_protection_min_cei016': I_protection_min,
        'source': 'EMERGENZA',
        'exact_match': False
    }
    
    fallback_info = {
        'level': 5,
        'status': '🚨 EMERGENZA',
        'notes': f'Valori di emergenza ultra-conservativi - {reason}',
        'reliability': 'MINIMA'
    }
    
    return inrush_data, fallback_info


def _display_database_status(fallback_info: dict):
    """Display status del database con indicatori visivi chiari"""
    
    level = fallback_info['level']
    status = fallback_info['status']
    reliability = fallback_info['reliability']
    
    if level == 1:
        st.success(f"✅ **{status}** - Affidabilità: {reliability}")
        
    elif level <= 3:
        st.warning(f"⚠️ **{status}** - Affidabilità: {reliability}")
        with st.expander("💡 Dettagli fallback"):
            st.info(fallback_info['notes'])
            
    elif level == 4:
        st.error(f"🟠 **{status}** - Affidabilità: {reliability}")
        st.warning("⚠️ Verificare configurazione database")
        with st.expander("🔍 Dettagli problema"):
            st.warning(fallback_info['notes'])
            
    else:  # level 5
        st.error(f"🚨 **{status}** - Affidabilità: {reliability}")
        st.error("❌ **ATTENZIONE:** Sistema in modalità emergenza!")
        with st.expander("🚨 Dettagli emergenza"):
            st.error(fallback_info['notes'])
            st.warning("Contattare supporto tecnico per ripristinare il database")


def _display_mt_protections_clean(project_data):
    """Protezioni MT con layout pulito"""
    
    st.subheader("⚡ Protezioni MT")
    
    # Recupera impostazioni da Step 4
    mt_protection_settings = st.session_state.get('mt_protection_settings', {})
    mt_design = st.session_state.get('mt_final_design', {})
    
    if mt_protection_settings and mt_design.get('design_completed'):
        # Usa valori ottimizzati da Step 4
        settings = mt_protection_settings.copy()
        
        st.success("🎯 **Impostazioni da Step 4 - Sistema Ottimizzato**")
        
        # Display principale sempre visibile
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("I1 Sovraccarico", f"{settings.get('I_1', 0.9)} xIn")
            st.metric("t1 Tempo", f"{settings.get('t_1', 10)} s")
            
        with col2:
            st.metric("I2 CC Moderato", f"{settings.get('I_2', 200)} A")
            st.metric("t2 Tempo", f"{settings.get('t_2', 0.4)} s")
            
        with col3:
            st.metric("Io1 Terra Sens.", f"{settings.get('Io_1', 1.5)} A")
            st.metric("to1 Tempo", f"{settings.get('to_1', 0.3)} s")
            
        with col4:
            st.metric("Io2 Terra Princ.", f"{settings.get('Io_2', 18)} A")
            st.metric("to2 Tempo", f"{settings.get('to_2', 0.12)} s")
        
        # Verifica conformità CEI 0-16 sempre visibile
        conformity = _check_cei_conformity_simple(settings, project_data)
        
        if conformity['ok']:
            st.success("✅ **Conformità CEI 0-16 Verificata**")
        else:
            st.error(f"❌ **Problema CEI 0-16:** {conformity['issue']}")
    
    else:
        # Fallback con valori calcolati
        st.warning("⚠️ Step 4 incompleto - Valori calcolati automaticamente")
        
        settings = _calculate_fallback_settings(project_data)
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("I2 Calcolato", f"{settings['I_2']} A")
        with col2:
            st.metric("Io2 Calcolato", f"{settings['Io_2']} A")
        with col3:
            st.info("Completa Step 4 per")
        with col4:
            st.info("valori ottimizzati")
    
    return settings


def _check_cei_conformity_simple(settings, project_data):
    """Verifica CEI 0-16 semplificata per display"""
    
    # Controlli essenziali
    i2_value = settings.get('I_2', 200)
    t2_value = settings.get('t_2', 0.4)
    
    # Verifica I2 vs selettività
    transformer_config = st.session_state.get('transformer_config', {})
    if transformer_config:
        ucc_percent = transformer_config.get('ucc_percent', 6.0)
        power_kva = transformer_config.get('power_kva', 630)
        
        # Calcolo I'k semplificato
        Sn_va = power_kva * 1000
        Un_secondary = 400
        Ik_secondario = Sn_va / (1.732 * Un_secondary * ucc_percent/100)
        I_kmin = Ik_secondario / 50  # rapporto tipico 20kV/400V
        
        # Limite selettività
        limit_selectivity = I_kmin * 0.47  # Più restrittivo tra 3 e 2 fasi
        
        if i2_value > limit_selectivity:
            return {'ok': False, 'issue': f'I2 {i2_value}A > limite {limit_selectivity:.0f}A'}
    
    # Verifica tempo
    if not (0.3 <= t2_value <= 0.6):
        return {'ok': False, 'issue': f't2 {t2_value}s fuori range 0.3-0.6s'}
    
    return {'ok': True, 'issue': None}


def _calculate_fallback_settings(project_data):
    """Calcola impostazioni fallback"""
    
    voltage_kv = project_data.get('voltage_kv', 20)
    total_kva = project_data.get('total_kva', 800)
    earth_fault_a = project_data.get('earth_fault_current_a', 20)
    
    current_mt_nominal = (total_kva * 1000) / (voltage_kv * 1000 * 1.732) if voltage_kv > 0 else 25
    
    return {
        'I_1': 0.9,
        't_1': 10.0,
        'I_2': min(int(current_mt_nominal * 5), 200),  # Conservativo
        't_2': 0.4,
        'I_3': 600,
        't_3': 0.05,
        'Io_1': 1.5,
        'to_1': 0.3,
        'Io_2': min(int(earth_fault_a * 0.9), 18),
        'to_2': 0.15
    }


def _display_abb_coordination_clean(project_data):
    """Coordinamento ABB semplificato e chiaro"""
    
    st.subheader("🔵 Sistema ABB Emax 2")
    
    # Modalità semplificata
    mode = st.radio(
        "Modalità coordinamento:",
        ["🚀 Automatica ABB", "⚙️ Manuale"],
        horizontal=True
    )
    
    if mode.startswith("🚀"):
        # Automatica - Risultati immediati
        st.info("🤖 **Calcolo automatico ABB in corso...**")
        
        # Risultati simulati ma realistici
        abb_results = {
            'system_type': 'abb_emax2_auto',
            'general_breaker': 'E1.2 800A',
            'feeder_breaker': 'E1.2 400A', 
            'selectivity': 92.5,
            'cost_estimate': 28000,
            'verified': True
        }
        
        # Display risultati sempre visibile
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Generale", "E1.2 800A")
            
        with col2:
            st.metric("Partenze", "E1.2 400A")
            
        with col3:
            st.metric("Selettività", f"{abb_results['selectivity']:.1f}%")
            
        with col4:
            st.metric("Costo Stima", f"€{abb_results['cost_estimate']:,}")
        
        if abb_results['selectivity'] > 90:
            st.success("✅ **Sistema ABB ottimale - Selettività elevata**")
        else:
            st.warning("⚠️ Sistema ABB da ottimizzare")
    
    else:
        # Manuale - Selezione semplice
        col1, col2 = st.columns(2)
        
        with col1:
            general = st.selectbox("Interruttore Generale:", 
                                 ["E1.2 800A", "E1.2 1000A", "E2.2 1600A"])
        
        with col2:
            feeder = st.selectbox("Interruttore Partenze:",
                                ["E1.2 400A", "E1.2 630A", "T7 400A"])
        
        abb_results = {
            'system_type': 'abb_manual',
            'general_breaker': general,
            'feeder_breaker': feeder,
            'selectivity': 88.0,
            'cost_estimate': 25000,
            'verified': True
        }
        
        st.info(f"**Configurazione:** {general} + {feeder}")
    
    return abb_results


def _display_final_validation_clean(mt_settings, abb_results, project_data):
    """Validazione finale pulita e chiara"""
    
    st.subheader("✅ Validazione Sistema")
    
    # Controlli essenziali
    mt_design = st.session_state.get('mt_final_design', {})
    step4_ok = mt_design.get('design_completed', False)
    cei_check = _check_cei_conformity_simple(mt_settings, project_data)
    abb_ok = abb_results.get('verified', False)
    
    # Status complessivo
    all_ok = step4_ok and cei_check['ok'] and abb_ok
    
    # Display status chiaro
    col1, col2, col3 = st.columns(3)
    
    with col1:
        step4_status = "✅ Completato" if step4_ok else "❌ Incompleto"
        st.metric("Step 4 MT", step4_status)
        
    with col2:
        cei_status = "✅ Conforme" if cei_check['ok'] else "❌ Problema"
        st.metric("CEI 0-16", cei_status)
        
    with col3:
        abb_status = "✅ Verificato" if abb_ok else "❌ Errore"
        st.metric("ABB Emax 2", abb_status)
    
    if all_ok:
        st.success("🎯 **Sistema Protezioni Completo e Validato!**")
        
        # Riepilogo finale compatto
        with st.container():
            st.markdown("#### 📋 Configurazione Finale")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**🏢 Quadro MT:**")
                st.write(f"• Schema: {mt_design.get('electrical_scheme', {}).get('name', 'N/A')}")
                st.write(f"• I2 MT: {mt_settings.get('I_2', 'N/A')} A")
                st.write(f"• Costo: €{mt_design.get('total_cost', 0):,}")
                
            with col2:
                st.markdown("**🔵 ABB Emax 2:**")
                st.write(f"• Generale: {abb_results.get('general_breaker', 'N/A')}")
                st.write(f"• Partenze: {abb_results.get('feeder_breaker', 'N/A')}")
                st.write(f"• Selettività: {abb_results.get('selectivity', 0):.1f}%")     
    
    else:
        st.error("❌ Sistema richiede correzioni")
        
        if not step4_ok:
            st.error("• Completa Step 4 (Progettazione Quadro MT)")
        if not cei_check['ok']:
            st.error(f"• CEI 0-16: {cei_check['issue']}")
        if not abb_ok:
            st.error("• Verifica configurazione ABB")
    
    # Pulsante avanzamento sempre visibile se completato
    if all_ok:
        st.markdown("---")
        if st.button("➡️ PROCEDI AL STEP 6", type="primary"):
            if 'completed_steps' not in st.session_state:
                st.session_state['completed_steps'] = set()
            st.session_state['completed_steps'].add(5)
            st.session_state['current_step'] = 6
            st.rerun()