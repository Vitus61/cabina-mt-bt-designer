"""
Step 6: Configurazione Quadro BT - VERSIONE INTELLIGENTE
Sistema che calcola automaticamente le soluzioni ottimali basandosi sui dati di progetto
"""

import streamlit as st
import pandas as pd
from ui.step_components import create_step_container, metrics_panel, info_panel
from ui.display_utils import technical_datasheet, system_status_indicator


def step_6_bt_switchgear_design(db=None):
    """Step 6: Configurazione Quadro BT - Calcoli automatici intelligenti"""
    
    create_step_container("⚡ Step 6: Configurazione Quadro BT")
    
    # Verifica prerequisiti
    if 5 not in st.session_state.get('completed_steps', set()):
        st.error("❌ Completa prima lo Step 5 (Coordinamento Protezioni)")
        return
    
    # Recupera dati di progetto
    project_data = _gather_bt_project_data()
    if not project_data:
        st.error("❌ Dati di progetto incompleti - verifica step precedenti")
        return
    
    # ========== CALCOLI AUTOMATICI ==========
    calculated_specs = _calculate_optimal_configuration(project_data)
    
    # ========== DISPLAY CALCOLI ==========
    _display_automatic_calculations(project_data, calculated_specs)
    
    # ========== CONFIGURAZIONE GUIDATA ==========
    quadro_config = _guided_configuration(project_data, calculated_specs)
    
    # ========== DISPOSITIVI OTTIMALI ==========
    device_selection = _optimal_device_selection(project_data, quadro_config, calculated_specs)
    
    # ========== VALIDAZIONE E CONFERMA ==========
    _final_validation_and_confirmation(project_data, quadro_config, device_selection)


def _gather_bt_project_data():
    """Raccoglie dati essenziali per i calcoli"""
    
    distributor_data = st.session_state.get('distributor_data', {})
    transformer_config = st.session_state.get('transformer_config', {})
    mt_design = st.session_state.get('mt_final_design', {})
    
    # 🆕 RECUPERA DATI STEP 2 - CARICHI DETTAGLIATI
    # 🆕 RECUPERA DATI STEP 2 - CARICHI DETTAGLIATI  
    calculation_results = st.session_state.get('calculation_results', {})
    loads = calculation_results.get('load_breakdown', [])  # ← CORREZIONE QUI
    total_power_kva_step2 = calculation_results.get('total_power_kva', 0)
    
    # ✅ VERIFICA DATI RICEVUTI
    if loads:
        st.success(f"✅ **Dati Step 2 integrati:** {len(loads)} carichi, Potenza: {total_power_kva_step2} kVA")
        
        # 🎨 LAYOUT A 3 COLONNE
        cols = st.columns(3)
        
        for i, load in enumerate(loads):
            col_index = i % 3  # Distribuisce: 0,1,2,0,1,2...
            with cols[col_index]:
                st.info(f"**{load.get('name', 'N/A')}**\n"
                    f"{load.get('power_used_kw', 0)} kW → {load.get('current_a', 0):.1f} A")
    else:
        st.warning("⚠️ **Dati Step 2 mancanti!** Usando calcolo generico.")


    # ✅ VALIDAZIONE RIGOROSA: Non accettare fallback, richiedere dati reali
    if not transformer_config:
        st.error("❌ Configurazione trasformatore mancante - Completa Step 3")
        return None
        
    if 'total_power' not in transformer_config:
        st.error("❌ Potenza trasformatore non configurata - Verifica Step 3")
        return None
    
    # ⚠️ CONTROLLO COERENZA TRA STEP 3 E 3.5
    step3_power = transformer_config.get('power_kva')  # Valore originale Step 3
    step35_power = transformer_config.get('total_power')  # Potrebbe essere modificato da Step 3.5
    
    if step3_power and step35_power and step3_power != step35_power:
        st.error(f"❌ **INCOERENZA RILEVATA TRA STEP:**\n"
                f"• Step 3 (Selezione): {step3_power} kVA\n"
                f"• Step 3.5 (Calcolato): {step35_power} kVA\n"
                f"• **PROBLEMA:** Step 3.5 ha sovrascritto Step 3!")
        
        st.warning("🔧 **QUALE VALORE USARE?**")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button(f"📋 USA STEP 3: {step3_power} kVA", type="primary"):
                # Ripristina valore originale Step 3
                st.session_state['transformer_config']['total_power'] = step3_power
                st.rerun()
        
        with col2:
            if st.button(f"🧮 USA STEP 3.5: {step35_power} kVA"):
                # Mantieni valore calcolato Step 3.5  
                pass
        
        st.info("💡 **Raccomandazione:** Usa il valore configurato nello Step 3 se soddisfa i carichi")
        return None
    
    # Parametri base - USA VALORE CONCORDATO
    total_kva = transformer_config['total_power']  # Valore finale concordato
    voltage_bt = 400  # Standard
    
    # Calcolo corrente nominale BT
    current_bt_nominal = (total_kva * 1000) / (voltage_bt * 1.732)
    
    # Calcolo Icc BT (basato su impedenza trasformatore)
    # Calcolo Icc BT (formula corretta CEI)
    ucc_percent = transformer_config.get('ucc_percent', 6.0)  # Da Step 3
    voltage_bt = 400  # V

    # Formula corretta: Icc = Sn / (√3 × Un × Ucc%)
    icc_bt_ka = (total_kva * 1000) / (1.732 * voltage_bt * (ucc_percent/100)) / 1000
    icc_bt = icc_bt_ka * 1000  # Conversione in Ampere per compatibilità

    # ✅ VALIDAZIONE CRITICA - Verifica valori sensati
    if icc_bt_ka < 5 or icc_bt_ka > 50:
        st.error(f"🚨 **ERRORE CALCOLO ICC BT:** {icc_bt_ka:.1f} kA anomala!")
        st.error(f"• Potenza: {total_kva} kVA")  
        st.error(f"• Ucc: {ucc_percent}%")
        st.error(f"• **ICC ATTESA:** 15-25 kA per trasformatori MT/BT")
        st.stop()  # Blocca esecuzione per sicurezza

    # ✅ INFO TECNICA per verifica
    st.info(f"📐 **Calcolo Icc BT Verificato:**\n"
            f"• Formula: Sn / (√3 × Un × Ucc%)\n"
            f"• Calcolo: {total_kva}kVA / (1.732 × 400V × {ucc_percent}%)\n"
            f"• **Risultato: {icc_bt_ka:.1f} kA** ✅")
    
    # Validazione valori sensati
    if total_kva < 100 or total_kva > 5000:
        st.warning(f"⚠️ Potenza trasformatore insolita: {total_kva} kVA - Verifica Step 3")
    
    if current_bt_nominal < 100 or current_bt_nominal > 10000:
        st.warning(f"⚠️ Corrente BT calcolata insolita: {current_bt_nominal:.0f} A")
    
    # Validazione valori sensati
    if total_kva < 100 or total_kva > 5000:
        st.warning(f"⚠️ Potenza trasformatore insolita: {total_kva} kVA - Verifica Step 3")
    
    if current_bt_nominal < 100 or current_bt_nominal > 10000:
        st.warning(f"⚠️ Corrente BT calcolata insolita: {current_bt_nominal:.0f} A")
    
    # Info configurazione per conferma
    st.success(f"✅ **Trasformatore configurato:**\n"
               f"• Potenza: {total_kva} kVA ({transformer_config.get('series', 'N/A')})\n"
               f"• Ucc: {ucc_percent}%\n"
               f"• Corrente BT: {current_bt_nominal:.0f} A\n"
               f"• Icc BT: {icc_bt:.0f} A")
    
    return {
        'total_kva': total_kva,  # VALORE REALE
        'voltage_bt': voltage_bt,
        'current_bt_nominal': current_bt_nominal,
        'icc_bt': icc_bt,
        'ucc_percent': ucc_percent,
        'num_transformers': transformer_config.get('num_transformers', 1),
        'transformer_power': transformer_config.get('power_kva', total_kva),
        'installation_type': distributor_data.get('installation_type', 'indoor'),
        'service_continuity': st.session_state.get('project_params', {}).get('service_continuity', 'normale'),
        # 🆕 AGGIUNGI QUESTI DATI DA STEP 2:
        'loads': loads,
        'load_details': calculation_results.get('load_details', []),
        'step2_power_kva': total_power_kva_step2,
        'calculation_results': calculation_results
    }


def _calculate_optimal_configuration(project_data):
    """🧮 CALCOLI AUTOMATICI per configurazione ottimale"""
    
    # 1. INTERRUTTORE GENERALE - Calcolo automatico
    current_nominal = project_data['current_bt_nominal']
    
    # Margine sicurezza 25% + margine futuro 10% = 35%
    required_current = current_nominal * 1.35
    
    # Standard commerciali ABB
    standard_currents = [630, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000]
    optimal_current = min([c for c in standard_currents if c >= required_current])
    
    # 2. POTERE DI INTERRUZIONE - Calcolo automatico
    icc_bt_ka = project_data['icc_bt'] / 1000
    
    # Margine sicurezza 25%
    required_breaking = icc_bt_ka * 1.25
    
    # Standard commerciali
    standard_breaking = [25, 35, 50, 65, 85, 100]
    optimal_breaking = min([b for b in standard_breaking if b >= required_breaking])
    
    
    # 3. NUMERO PARTENZE - Calcolo basato su carichi reali
    
    loads = project_data.get('loads', [])
    total_kva = project_data['total_kva']  # ← AGGIUNGI QUESTA RIGA

    if loads:
        # Calcolo intelligente basato sui carichi reali
        active_feeders = len(loads)  # Una partenza per carico
        service_feeders = 2  # Servizi ausiliari + UPS
        reserve_feeders = max(2, int(active_feeders * 0.5))  # 50% riserva
        recommended_feeders = active_feeders + service_feeders + reserve_feeders
        
        st.info(f"📊 **Calcolo Intelligente Partenze:**\n"
                f"• Carichi attivi: {active_feeders}\n" 
                f"• Servizi: {service_feeders}\n"
                f"• Riserve: {reserve_feeders}\n"
                f"• **Totale: {recommended_feeders}**")
    else:
        # Fallback generico se non ci sono carichi
        if total_kva <= 400:
            recommended_feeders = 8
        elif total_kva <= 800:
            recommended_feeders = 12
        else:
            recommended_feeders = 16
    
    # 4. TIPO QUADRO - Raccomandazione basata su criteri
    service_continuity = project_data.get('service_continuity', 'normale')
    
    if service_continuity == 'essenziale':
        recommended_type = 'withdrawable'  # Estraibile per manutenzione
    elif total_kva > 1000:
        recommended_type = 'compartmented'  # Compartimentato per sicurezza
    else:
        recommended_type = 'fixed'  # Fisso economico
    
    # 5. CLASSE LIMITAZIONE - Calcolo basato su Icc
    if icc_bt_ka > 50:
        limitation_class = 3  # Massima limitazione
    elif icc_bt_ka > 25:
        limitation_class = 2  # Limitazione media
    else:
        limitation_class = 1  # Limitazione base
    
    return {
        'optimal_current': optimal_current,
        'current_calculation': {
            'nominal': current_nominal,
            'with_margin': required_current,
            'margin_percent': 35
        },
        'optimal_breaking': optimal_breaking,
        'breaking_calculation': {
            'icc_bt_ka': icc_bt_ka,
            'with_margin': required_breaking,
            'margin_percent': 25
        },
        'recommended_feeders': recommended_feeders,
        'recommended_type': recommended_type,
        'limitation_class': limitation_class,
        'reasoning': {
            'current': f"Basato su {current_nominal:.0f}A nominali + 35% sicurezza/futuro",
            'breaking': f"Basato su Icc {icc_bt_ka:.1f}kA + 25% sicurezza",
            'feeders': f"Raccomandato per {total_kva}kVA con riserve",
            'type': f"Ottimale per continuità '{service_continuity}'"
        }
    }


def _display_automatic_calculations(project_data, calculated_specs):
    """📊 Mostra i calcoli automatici in modo chiaro"""
    
    st.subheader("🧮 Calcoli Automatici Sistema")
    
    # Dati di partenza
    st.markdown("#### 📋 Dati di Progetto")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Potenza Totale", f"{project_data['total_kva']} kVA")
        
    with col2:
        st.metric("Corrente Nominale BT", f"{project_data['current_bt_nominal']:.0f} A")
        
    with col3:
        st.metric("Icc BT Calcolata", f"{project_data['icc_bt']:.0f} A")
        
    with col4:
        st.metric("Ucc Trasformatore", f"{project_data['ucc_percent']}%")
    
    # Risultati calcoli
    st.markdown("#### ✅ Soluzioni Calcolate")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.success("**🔧 Interruttore Generale Ottimale**")
        st.metric(
            "Corrente Raccomandata", 
            f"{calculated_specs['optimal_current']} A",
            help=calculated_specs['reasoning']['current']
        )
        
        # Mostra il calcolo
        with st.expander("📊 Dettagli Calcolo Corrente"):
            st.write(f"• Corrente nominale: {calculated_specs['current_calculation']['nominal']:.0f} A")
            st.write(f"• Margine sicurezza: {calculated_specs['current_calculation']['margin_percent']}%")
            st.write(f"• Corrente richiesta: {calculated_specs['current_calculation']['with_margin']:.0f} A")
            st.write(f"• **Standard commerciale:** {calculated_specs['optimal_current']} A")
        
        st.success("**🛡️ Potere di Interruzione**")
        st.metric(
            "Breaking Capacity", 
            f"{calculated_specs['optimal_breaking']} kA",
            help=calculated_specs['reasoning']['breaking']
        )
        
        # Mostra il calcolo
        with st.expander("📊 Dettagli Calcolo Breaking"):
            st.write(f"• Icc BT: {calculated_specs['breaking_calculation']['icc_bt_ka']:.1f} kA")
            st.write(f"• Margine sicurezza: {calculated_specs['breaking_calculation']['margin_percent']}%")
            st.write(f"• Potere richiesto: {calculated_specs['breaking_calculation']['with_margin']:.1f} kA")
            st.write(f"• **Standard commerciale:** {calculated_specs['optimal_breaking']} kA")
    
    with col2:
        st.success("**🔌 Configurazione Quadro**")
        st.metric(
            "Partenze Raccomandate", 
            f"{calculated_specs['recommended_feeders']}",
            help=calculated_specs['reasoning']['feeders']
        )
        
        st.metric(
            "Tipo Quadro Ottimale", 
            calculated_specs['recommended_type'].replace('_', ' ').title(),
            help=calculated_specs['reasoning']['type']
        )
        
        st.success("**⚡ Caratteristiche Tecniche**")
        st.metric("Classe Limitazione", f"Classe {calculated_specs['limitation_class']}")
        
        # Grado protezione basato su installazione
        installation = project_data.get('installation_type', 'indoor')
        recommended_ip = 'IP41' if installation == 'indoor' else 'IP54'
        st.metric("Grado Protezione", recommended_ip)


def _guided_configuration(project_data, calculated_specs):
    """🎯 Configurazione guidata con possibilità di override"""
    
    st.subheader("🎯 Configurazione Guidata")
    
    st.info("💡 **I valori sono pre-calcolati automaticamente. Puoi modificarli solo se necessario.**")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 🔧 Configurazione Base")
        
        # Tipo quadro con raccomandazione
        quadro_types = {
            'fixed': 'Fisso (Economico)',
            'withdrawable': 'Estraibile (Manutenibile)',
            'compartmented': 'Compartimentato (Sicuro)',
            'modular': 'Modulare (Espandibile)'
        }
        
        recommended_type = calculated_specs['recommended_type']
        type_options = list(quadro_types.keys())
        default_index = type_options.index(recommended_type)
        
        quadro_type = st.selectbox(
            "Tipo Quadro:",
            options=type_options,
            format_func=lambda x: f"{'⭐ ' if x == recommended_type else ''}{quadro_types[x]}",
            index=default_index,
            help=f"Raccomandato: {quadro_types[recommended_type]} - {calculated_specs['reasoning']['type']}"
        )
        
        # Numero partenze con raccomandazione
        feeder_options = [8, 12, 16, 20, 24, 32]
        recommended_feeders = calculated_specs['recommended_feeders']
        
        # Trova l'indice più vicino
        default_feeder_index = min(range(len(feeder_options)), 
                                 key=lambda i: abs(feeder_options[i] - recommended_feeders))
        
        num_feeders = st.selectbox(
            "Numero Partenze:",
            options=feeder_options,
            index=default_feeder_index,
            format_func=lambda x: f"{'⭐ ' if x == recommended_feeders else ''}{x} partenze",
            help=f"Raccomandato: {recommended_feeders} - {calculated_specs['reasoning']['feeders']}"
        )
    
    with col2:
        st.markdown("#### ⚡ Caratteristiche Elettriche")
        
        # Corrente interruttore generale (pre-calcolata)
        current_options = [630, 800, 1000, 1250, 1600, 2000, 2500, 3200]
        optimal_current = calculated_specs['optimal_current']
        current_index = current_options.index(optimal_current)
        
        general_breaker_current = st.selectbox(
            "Interruttore Generale:",
            options=current_options,
            index=current_index,
            format_func=lambda x: f"{'⭐ ' if x == optimal_current else ''}{x}A",
            help=f"Pre-calcolato: {optimal_current}A - {calculated_specs['reasoning']['current']}"
        )
        
        # Potere di interruzione (pre-calcolato)
        breaking_options = [25, 35, 50, 65, 85, 100]
        optimal_breaking = calculated_specs['optimal_breaking']
        breaking_index = breaking_options.index(optimal_breaking)
        
        breaking_capacity = st.selectbox(
            "Potere di Interruzione:",
            options=breaking_options,
            index=breaking_index,
            format_func=lambda x: f"{'⭐ ' if x == optimal_breaking else ''}{x} kA",
            help=f"Pre-calcolato: {optimal_breaking}kA - {calculated_specs['reasoning']['breaking']}"
        )
        
        # Classe limitazione (pre-calcolata)
        limitation_class = st.selectbox(
            "Classe Limitazione:",
            options=[1, 2, 3],
            index=calculated_specs['limitation_class'] - 1,
            format_func=lambda x: f"{'⭐ ' if x == calculated_specs['limitation_class'] else ''}Classe {x}",
            help="Pre-calcolata basandosi su Icc BT"
        )
    
    # Caratteristiche aggiuntive
    col1, col2 = st.columns(2)
    
    with col1:
        # Grado protezione
        installation = project_data.get('installation_type', 'indoor')
        ip_options = ["IP31", "IP41", "IP54", "IP65"]
        recommended_ip = 'IP41' if installation == 'indoor' else 'IP54'
        ip_index = ip_options.index(recommended_ip)
        
        ip_rating = st.selectbox(
            "Grado Protezione:",
            options=ip_options,
            index=ip_index,
            format_func=lambda x: f"{'⭐ ' if x == recommended_ip else ''}{x}",
            help=f"Raccomandato {recommended_ip} per installazione {installation}"
        )
    
    with col2:
        # Selettività
        selectivity_options = ["Cronometrica", "Energetica", "Logica", "Zonale"]
        selectivity_type = st.selectbox(
            "Tipo Selettività:",
            options=selectivity_options,
            index=2,  # Default: Logica
            help="Logica raccomandata per comunicazione tra interruttori"
        )
    
    return {
        'quadro_type': quadro_type,
        'num_feeders': num_feeders,
        'general_breaker_current': general_breaker_current,
        'breaking_capacity': breaking_capacity,
        'limitation_class': limitation_class,
        'selectivity_type': selectivity_type,
        'ip_rating': ip_rating,
        'calculated_optimally': {
            'current_optimal': general_breaker_current == optimal_current,
            'breaking_optimal': breaking_capacity == optimal_breaking,
            'type_optimal': quadro_type == recommended_type
        }
    }


def _optimal_device_selection(project_data, quadro_config, calculated_specs):
    """🎯 Selezione automatica dispositivi ottimali"""
    
    st.subheader("🎯 Dispositivi Ottimali ABB")
    
    # ========== INTERRUTTORE GENERALE ==========
    st.markdown("#### ⚡ Interruttore Generale - Selezione Automatica")
    
    # Logica di selezione automatica ABB
    current = quadro_config['general_breaker_current']
    breaking = quadro_config['breaking_capacity']
    
    # Selezione famiglia ABB basata su parametri
    if current >= 1600 or breaking >= 65:
        recommended_family = 'emax2'
        family_reason = "Emax 2 per prestazioni elevate"
    elif current >= 800 or breaking >= 35:
        recommended_family = 'tmax_xt'
        family_reason = "Tmax XT per applicazioni professionali"
    else:
        recommended_family = 'tmax_t'
        family_reason = "Tmax T per applicazioni standard"
    
    # Modello specifico
    family_models = {
        'emax2': f"E2.2 {current}A - {breaking}kA",
        'tmax_xt': f"XT{current//100} {current}A - {breaking}kA", 
        'tmax_t': f"T{current//100} {current}A - {breaking}kA"
    }
    
    optimal_model = family_models[recommended_family]
    
    # Protezione ottimale
    if recommended_family == 'emax2':
        optimal_protection = 'PR332/P - Digitale Premium'
        protection_reason = "Funzioni avanzate e comunicazione"
    else:
        optimal_protection = 'PR331/P - Digitale Standard'
        protection_reason = "Protezione affidabile con comunicazione"
    
    # Display selezione automatica
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.success("**🔧 Famiglia Ottimale**")
        st.metric("ABB", recommended_family.replace('_', ' ').upper())
        st.info(family_reason)
        
    with col2:
        st.success("**⚡ Modello Selezionato**")
        st.write(f"**{optimal_model}**")
        st.metric("Corrente", f"{current}A")
        st.metric("Breaking", f"{breaking}kA")
        
    with col3:
        st.success("**🛡️ Protezione**")
        st.write(f"**{optimal_protection}**")
        st.info(protection_reason)
    
    # Costo automatico
    base_costs = {
        'emax2': 8000,
        'tmax_xt': 5000,
        'tmax_t': 3000
    }
    
    base_cost = base_costs[recommended_family]
    accessories_cost = 1500  # Standard: motorizzazione + ausiliari
    total_general_cost = base_cost + accessories_cost
    
    st.metric("💰 Costo Totale Generale", f"€{total_general_cost:,}")
    
    # ========== INTERRUTTORI PARTENZE ==========
    st.markdown("#### 🔌 Interruttori Partenze - Distribuzione Ottimale")
    
    # Calcolo distribuzione automatica basata su potenza
    total_kva = project_data['total_kva']
    num_feeders = quadro_config['num_feeders']
    
    # Distribuzione intelligente
    if total_kva <= 400:
        high_power = max(1, num_feeders // 6)      # 400A
        medium_power = max(2, num_feeders // 3)    # 250A  
        low_power = max(1, num_feeders // 4)       # 160A
    elif total_kva <= 800:
        high_power = max(2, num_feeders // 4)      # 400A
        medium_power = max(3, num_feeders // 3)    # 250A
        low_power = max(2, num_feeders // 5)       # 160A
    else:
        high_power = max(3, num_feeders // 3)      # 400A
        medium_power = max(4, num_feeders // 3)    # 250A
        low_power = max(2, num_feeders // 6)       # 160A
    
    # Calcola riserve
    used_feeders = high_power + medium_power + low_power
    reserve_feeders = max(0, num_feeders - used_feeders)
    
    # Famiglia partenze ottimale
    if total_kva > 1000:
        feeder_family = 'tmax_xt'
        feeder_reason = "Tmax XT per carichi elevati"
    else:
        feeder_family = 'tmax_t'
        feeder_reason = "Tmax T ottimale per questo carico"
    
    # Display distribuzione aggregata
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Partenze 400A", f"{high_power}")
        st.info("Motori grandi")
        
    with col2:
        st.metric("Partenze 250A", f"{medium_power}")
        st.info("Motori medi")
        
    with col3:
        st.metric("Partenze 160A", f"{low_power}")
        st.info("Illuminazione/Servizi")
        
    with col4:
        st.metric("Riserve", f"{reserve_feeders}")
        st.info("Future espansioni")
    
    # 🆕 AGGIUNTA: Dettaglio partenze singole
    _display_individual_feeders(project_data, high_power, medium_power, low_power, reserve_feeders, feeder_family)
    
    # Costo partenze
    feeder_costs = {
        'tmax_xt': {'400A': 3500, '250A': 2800, '160A': 2200},
        'tmax_t': {'400A': 2500, '250A': 2000, '160A': 1500}
    }
    
    total_feeder_cost = (
        high_power * feeder_costs[feeder_family]['400A'] +
        medium_power * feeder_costs[feeder_family]['250A'] +
        low_power * feeder_costs[feeder_family]['160A']
    )
    
    st.success(f"**👥 Famiglia Partenze:** {feeder_family.replace('_', ' ').upper()} - {feeder_reason}")
    st.metric("💰 Costo Totale Partenze", f"€{total_feeder_cost:,}")
    
    return {
        'general_breaker': {
            'family': recommended_family,
            'model': optimal_model,
            'current': current,
            'breaking_capacity': breaking,
            'protection': optimal_protection,
            'cost': total_general_cost,
            'automatically_selected': True
        },
        'feeders': {
            'family': feeder_family,
            'distribution': {
                'high_power': high_power,    # 400A
                'medium_power': medium_power, # 250A
                'low_power': low_power,      # 160A
                'reserve': reserve_feeders
            },
            'total_cost': total_feeder_cost,
            'automatically_calculated': True
        }
    }


def _display_individual_feeders(project_data, high_power, medium_power, low_power, reserve_feeders, feeder_family):
    """🔌 Mostra le singole partenze dettagliate basate sui carichi reali"""
    
    st.markdown("#### 🔍 Dettaglio Partenze Singole")
    
    # Recupera carichi reali dallo Step 2
    loads = project_data.get('loads', [])
    
    if not loads:
        st.warning("⚠️ Carichi dettagliati non disponibili - Usa distribuzione generica")
        return
    
    # Crea liste partenze basate sui carichi reali
    feeders_list = []
    
    # 1. Aggiungi carichi reali
    for i, load in enumerate(loads, 1):
        load_power_kw = load.get('power_used_kw', 0)
        load_current = load.get('current_a', 0)
        load_name = load.get('name', f'Carico {i}')
        
        
        # Determina interruttore necessario basato su corrente
        if load_current > 320:        # Sicurezza 80% di 400A
            breaker_size = 400
            breaker_type = "T6N400"
            protection = "PR221DS/P"
        elif load_current > 160:      # ← CORREZIONE: 200 → 160
            breaker_size = 250
            breaker_type = "T5N250"
            protection = "PR221DS/P"
        elif load_current > 100:      # Sicurezza 63% di 160A
            breaker_size = 160
            breaker_type = "T4N160"
            protection = "PR221DS/P"
        else:
            breaker_size = 160  # Minimo sicurezza
            breaker_type = "T4N160"
            protection = "PR221DS/P"
        
        feeders_list.append({
            'numero': i,
            'nome': load_name,
            'tipo': 'Carico',
            'potenza_kw': load_power_kw,
            'corrente_a': load_current,
            'interruttore': f"Tmax {breaker_type}",
            'corrente_int': breaker_size,
            'protezione': 'PR221DS/P'
        })
    
    # 2. Aggiungi partenze servizi
    next_num = len(feeders_list) + 1
    
    # Servizi tipici
    service_feeders = [
        {'nome': 'UPS / Servizi Ausiliari', 'potenza_kw': 10, 'corrente_a': 25},
        {'nome': 'Illuminazione Emergenza', 'potenza_kw': 5, 'corrente_a': 12},
        {'nome': 'Prese Servizio', 'potenza_kw': 15, 'corrente_a': 35}
    ]
    
    for service in service_feeders:
        feeders_list.append({
            'numero': next_num,
            'nome': service['nome'],
            'tipo': 'Servizio',
            'potenza_kw': service['potenza_kw'],
            'corrente_a': service['corrente_a'],
            'interruttore': 'Tmax T4N160',
            'corrente_int': 160,
            'protezione': 'PR221DS/P'
        })
        next_num += 1
    
    # 3. Aggiungi riserve
    for i in range(reserve_feeders):
        feeders_list.append({
            'numero': next_num + i,
            'nome': f'Riserva {i+1}',
            'tipo': 'Riserva',
            'potenza_kw': 0,
            'corrente_a': 0,
            'interruttore': 'Tmax T4N160',
            'corrente_int': 160,
            'protezione': 'PR221DS/P'
        })
    
    # Display in tabella interattiva
    df_feeders = pd.DataFrame(feeders_list)
    
    # Configurazione colonne
    column_config = {
        'numero': st.column_config.NumberColumn('N°', width='small'),
        'nome': st.column_config.TextColumn('Nome Partenza', width='large'),
        'tipo': st.column_config.SelectboxColumn(
            'Tipo',
            options=['Carico', 'Servizio', 'Riserva'],
            width='small'
        ),
        'potenza_kw': st.column_config.NumberColumn(
            'Potenza (kW)',
            format='%.1f',
            width='small'
        ),
        'corrente_a': st.column_config.NumberColumn(
            'Corrente (A)',
            format='%.0f',
            width='small'
        ),
        'interruttore': st.column_config.TextColumn('Modello ABB', width='medium'),
        'corrente_int': st.column_config.NumberColumn(
            'In (A)',
            format='%d',
            width='small'
        ),
        'protezione': st.column_config.TextColumn('Protezione', width='medium')
    }
    
    # Mostra tabella editabile
    st.markdown("**📋 Configurazione Dettagliata Partenze:**")
    
    edited_df = st.data_editor(
        df_feeders,
        column_config=column_config,
        use_container_width=True,
        num_rows="dynamic",
        key="feeders_detail"
    )
    
    # Statistiche automatiche
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        carichi_attivi = len(edited_df[edited_df['tipo'] == 'Carico'])
        st.metric("🔧 Carichi Attivi", carichi_attivi)
    
    with col2:
        servizi = len(edited_df[edited_df['tipo'] == 'Servizio'])
        st.metric("⚙️ Servizi", servizi)
    
    with col3:
        riserve = len(edited_df[edited_df['tipo'] == 'Riserva'])
        st.metric("🔄 Riserve", riserve)
    
    with col4:
        totale_partenze = len(edited_df)
        st.metric("📊 Totale", totale_partenze)
    
    # Analisi distribuzione correnti
    st.markdown("**📊 Analisi Distribuzione Correnti:**")
    
    # Conta interruttori per taglia
    int_400 = len(edited_df[edited_df['corrente_int'] == 400])
    int_250 = len(edited_df[edited_df['corrente_int'] == 250])
    int_160 = len(edited_df[edited_df['corrente_int'] == 160])
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.info(f"**400A:** {int_400} interruttori\n💪 Carichi pesanti")
    
    with col2:
        st.info(f"**250A:** {int_250} interruttori\n🔧 Carichi medi")
    
    with col3:
        st.info(f"**160A:** {int_160} interruttori\n💡 Carichi leggeri")
    
    # Verifica coerenza con distribuzione calcolata
    calculated_400 = high_power
    calculated_250 = medium_power
    calculated_160 = low_power
    
    if (int_400 != calculated_400 or int_250 != calculated_250 or int_160 != calculated_160):
        st.warning(f"⚠️ **Differenza rilevata:**\n"
                  f"• Calcolato: {calculated_400}×400A, {calculated_250}×250A, {calculated_160}×160A\n"
                  f"• Dettagliato: {int_400}×400A, {int_250}×250A, {int_160}×160A")
        
        st.info("💡 **La distribuzione dettagliata prevale** - È basata sui carichi reali")
    else:
        st.success("✅ **Distribuzione coerente** - Calcolo automatico confermato dai carichi reali")
    
    # Salva configurazione dettagliata nella sessione
    st.session_state['bt_feeders_detail'] = edited_df.to_dict('records')


def _final_validation_and_confirmation(project_data, quadro_config, device_selection):
    """✅ Validazione finale con riepilogo completo"""
    
    st.subheader("✅ Validazione Sistema")
    
    # Verifica conformità automatica
    validation_score = 100
    issues = []
    warnings = []
    
    # Controlla se le scelte sono ottimali
    if not quadro_config['calculated_optimally']['current_optimal']:
        warnings.append("Corrente interruttore generale diversa da quella calcolata")
        validation_score -= 5
        
    if not quadro_config['calculated_optimally']['breaking_optimal']:
        warnings.append("Potere di interruzione diverso da quello calcolato")
        validation_score -= 5
    
    # Calcolo costi totali
    total_cost = (device_selection['general_breaker']['cost'] + 
                 device_selection['feeders']['total_cost'] + 
                 15000)  # Costo base quadro
    
    cost_per_kva = total_cost / project_data['total_kva']
    
    # Status finale
    if validation_score >= 95:
        status = 'ok'
        status_msg = "Configurazione Ottimale"
    elif validation_score >= 85:
        status = 'warning'  
        status_msg = "Configurazione Buona"
    else:
        status = 'error'
        status_msg = "Configurazione da Rivedere"
    
    system_status_indicator("Quadro BT", status, {
        'Configurazione': status_msg,
        'Score': f"{validation_score}/100",
        'Costo/kVA': f"€{cost_per_kva:.0f}",
        'Conformità': '✅ CEI 23-51'
    })
    
    # Riepilogo finale compatto
    st.markdown("#### 📋 Configurazione Finale")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**🔧 Quadro BT:**")
        st.write(f"• Tipo: {quadro_config['quadro_type'].replace('_', ' ').title()}")
        st.write(f"• Partenze: {quadro_config['num_feeders']}")
        st.write(f"• Generale: {device_selection['general_breaker']['model']}")
        st.write(f"• Protezione: {device_selection['general_breaker']['protection']}")
        
    with col2:
        st.markdown("**💰 Analisi Economica:**")
        st.write(f"• Generale: €{device_selection['general_breaker']['cost']:,}")
        st.write(f"• Partenze: €{device_selection['feeders']['total_cost']:,}")
        st.write(f"• **Totale: €{total_cost:,}**")
        st.write(f"• Costo/kVA: €{cost_per_kva:.0f}")
    
    # Avvisi se presenti
    if warnings:
        st.warning("⚠️ **Avvisi di Configurazione:**")
        for warning in warnings:
            st.warning(f"• {warning}")
    
    # Conferma finale
    if validation_score >= 85:
        if st.button("✅ CONFERMA CONFIGURAZIONE QUADRO BT", type="primary", use_container_width=True):
            
            # Salva configurazione
            bt_config = {
                'quadro_config': quadro_config,
                'device_selection': device_selection,
                'total_cost': total_cost,
                'cost_per_kva': cost_per_kva,
                'validation_score': validation_score,
                'automatically_optimized': True,
                'design_completed': True,
                'timestamp': pd.Timestamp.now().isoformat()
            }
            
            st.session_state['bt_switchgear_config'] = bt_config
            
            # Completa step
            if 'completed_steps' not in st.session_state:
                st.session_state['completed_steps'] = set()
            st.session_state['completed_steps'].add(6)
            st.session_state['current_step'] = 8
            
            st.success("✅ Configurazione Quadro BT completata!")
            st.balloons()
            st.rerun()
    
    else:
        st.error("❌ Rivedere la configurazione prima di procedere")
        st.info("💡 Utilizzare i valori pre-calcolati per una configurazione ottimale")
    
    # Pulsante avanzamento se già configurato
    if st.session_state.get('bt_switchgear_config', {}).get('design_completed'):
        st.markdown("---")
        if st.button("➡️ PROCEDI AL STEP 8", type="primary"):
            if 'completed_steps' not in st.session_state:
                st.session_state['completed_steps'] = set()
            st.session_state['completed_steps'].add(6)
            st.session_state['current_step'] = 8
            st.rerun()