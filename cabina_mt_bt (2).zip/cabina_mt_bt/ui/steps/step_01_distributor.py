"""
Step 1: Dati Distributore
Modulo refactored che utilizza i componenti esistenti
"""

import streamlit as st
from ui.step_components import create_step_container, metrics_panel, info_panel
from ui.display_utils import format_engineering_value
from calculations.validation import validate_distributor_data


def step_1_distributor_data():
    """Step 1: Inserimento dati distributore - Versione 3.4"""
    
    create_step_container(
        "📄 Step 1: Dati del Distributore",
        "I dati del Distributore sono fondamentali per il progetto della cabina. "
        "Questi dati vengono forniti nella 'Lettera di Informazioni' del Distributore locale.\n\n"
        "I parametri sono modificabili nella sidebar a sinistra."
        " Quelli indicati sono parametri tipici"
    )
    
    # Recupera dati correnti
    data = st.session_state['distributor_data']
    
    # Pannello metriche utilizzando componente esistente
    electrical_metrics = {
        "Tensione nominale": f"{data['voltage_kv']} kV",
        "Icc trifase": f"{data['icc_3phase_ka']} kA", 
        "Stato neutro": data['neutral_state']
    }
    
    protection_metrics = {
        "Corrente guasto terra": f"{data['earth_fault_current_a']} A",
        "Tempo eliminazione": f"{data['earth_fault_time_s']} s",
        "Doppio guasto": f"{data['double_earth_fault_time_s']} s"
    }
    
    col1, col2 = st.columns(2)
    
    with col1:
        metrics_panel(electrical_metrics, "📋 Dati Elettrici")
    
    with col2:
        metrics_panel(protection_metrics, "🛡️ Protezione Terra")
    
    # Esempio lettera distributore
    _display_distributor_letter_example(data)
    
    # Validazione e avanzamento
    is_valid, message = validate_distributor_data()
    
    if is_valid:
        st.success("✅ Dati distributore validi e completi")
        
        if st.button("➡️ PROCEDI AL STEP 2", type="primary"):
            st.session_state['completed_steps'].add(1)
            st.session_state['current_step'] = 2
            st.rerun()
    else:
        st.error(f"❌ {message}")
        st.warning("⚠️ Completa i dati nella sidebar per procedere")


def _display_distributor_letter_example(data):
    """Mostra esempio lettera distributore"""
    with st.expander("📄 Esempio Lettera Distributore", expanded=False):
        letter_content = f"""
Oggetto: Informazioni riguardanti la rete di alimentazione del Distributore

Con riferimento alla vostra richiesta rendiamo noto che:

1) il vostro impianto di terra è {data['neutral_state']}
2) la cabina è alimentata dalla linea MT in partenza dalla Cabina Primaria;
3) presenta le seguenti caratteristiche:

- Tensione nominale: {data['voltage_kv']} kV ± 10%
- Frequenza nominale: 50 Hz ± 1% (95% dell'anno)  
- Corrente di cortocircuito trifase: {data['icc_3phase_ka']} kA
- Stato del neutro: {data['neutral_state']}
- Corrente di guasto monofase a terra: {data['earth_fault_current_a']} A
- Tempo di eliminazione del guasto monofase a terra: {data['earth_fault_time_s']} s
- Tempo di eliminazione del doppio guasto a terra: < {data['double_earth_fault_time_s']} s
- Caratteristiche dell'alimentazione MT: Conformi alla Norma CEI EN 50160
        """
        
        st.code(letter_content, language=None)
