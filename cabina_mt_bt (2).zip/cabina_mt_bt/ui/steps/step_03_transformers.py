"""
Step 3: Dimensionamento Trasformatori  
Modulo refactored che utilizza business/transformer_sizing.py
Versione migliorata con informazioni dettagliate sui tipi di trasformatori
"""

import streamlit as st
import pandas as pd
import os
from pathlib import Path
from ui.step_components import create_step_container, metrics_panel, info_panel
from ui.display_utils import technical_datasheet, format_currency
from business.transformer_sizing import get_transformer_sizer
from database.products import ProductDatabase


def step_3_transformer_sizing(db):
    """Step 3: Dimensionamento trasformatori - Versione con info tipo trasformatore"""
    
    create_step_container("🔌 Step 3: Dimensionamento Trasformatori")
    
    if 2 not in st.session_state['completed_steps']:
        st.error("❌ Completa prima lo Step 2 (Calcolo Carichi)")
        return
    
    if not st.session_state['calculation_results']:
        st.error("❌ Risultati calcolo carichi non disponibili")
        return
    
    # Utilizza il modulo business per dimensionamento
    transformer_sizer = get_transformer_sizer()
    
    # Recupera dati di progetto
    results = st.session_state['calculation_results']
    total_kva = results['total_power_kva']
    voltage_primary = st.session_state['distributor_data']['voltage_kv']
    service_continuity = st.session_state['project_params']['service_continuity']
    user_redundancy = st.session_state['project_params']['transformer_redundancy']
    installation_type = st.session_state['project_params']['installation_type']
    
    # Pannello dati utilizzando componente esistente
    project_metrics = {
        "Potenza Totale": f"{total_kva} kVA",
        "Tensione": f"{voltage_primary} kV",
        "Servizio": service_continuity.title(),
        "Installazione TR": installation_type.title()
    }
    
    info_panel({
        'title': '📊 **Riepilogo Dati Progetto**',
        'items': [f"{k}: {v}" for k, v in project_metrics.items()]
    }, "info")
    
    # Calcolo configurazioni utilizzando business logic
    _calculate_transformer_configurations(transformer_sizer, total_kva, service_continuity, user_redundancy)
    
    # Selezione serie trasformatore
    selected_series = _handle_series_selection(installation_type, service_continuity)
    
    # 🆕 NUOVA SEZIONE: Info dettagliate tipo trasformatore
    _display_transformer_type_info(selected_series, installation_type, service_continuity)
    
    # Risultati finali
    _display_transformer_results(db, transformer_sizer, total_kva, user_redundancy, selected_series)
    
    # ✅ PULSANTE AVANZAMENTO - Sempre visibile se trasformatori configurati
    if st.session_state.get('transformer_config'):
        st.markdown("---")
        if st.button("➡️ PROCEDI AL STEP 3.5", type="primary"):
            st.session_state['completed_steps'].add(3)
            st.session_state['current_step'] = 3.5
            st.rerun()


def _calculate_transformer_configurations(transformer_sizer, total_kva, service_continuity, user_redundancy):
    """Calcola configurazioni utilizzando business logic"""
    
    # Utilizza il modulo business per valutazione
    evaluation = transformer_sizer.evaluate_single_vs_double_configuration(total_kva, service_continuity)
    
    #st.markdown("---")
    st.markdown("""
    <div style="text-align: center; padding: 25px; margin: 20px 0;">
        <h1 style="
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 2.5em;
            margin: 0;
        ">
             SCELTA TRASFORMATORE
        </h1>
        <hr style="width: 50%; margin: 20px auto; border: 2px solid #667eea;">
        <p style="color: #666; font-style: italic; margin: 0;">
            ✅ Validazione completata • Pronto per selezione ABB intelligente
        </p>
    </div>
    """, unsafe_allow_html=True)

   
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**🤖 Raccomandazione Algoritmo**")
        recommended = evaluation['recommendation']['configuration'] == 'double'
        config_text = "2 Trasformatori" if recommended else "1 Trasformatore"
        st.success(f"**{config_text}**")
        st.caption(evaluation['recommendation']['reason'])
    
    with col2:
        st.markdown("**👤 Scelta Utente**")
        user_config_text = "2 Trasformatori" if user_redundancy else "1 Trasformatore"
        st.info(f"**{user_config_text}**")
        concordant = user_redundancy == recommended
        status = "✅ Concordante" if concordant else "⚠️ Override utente"
        st.caption(status)


def _handle_series_selection(installation_type, service_continuity):
    """Gestisce selezione serie trasformatore"""
    
    # Raccomandazione automatica serie
    if installation_type == "indoor" and service_continuity in ["essenziale", "privilegiata"]:
        default_series = "onan"  # Involucro proprio
        recommendation = "🏢 Indoor + servizio critico → Involucro metallico proprio"
    elif installation_type == "outdoor" and service_continuity == "essenziale":
        default_series = "onan"
        recommendation = "🌤️ Outdoor + servizio essenziale → Massima affidabilità"
    else:
        default_series = "hi_t_plus" 
        recommendation = "💰 Installazione standard → Soluzione economica"
    
    # Selezione utente
    with st.expander("🔧 Selezione Serie Trasformatore", expanded=False):
        st.info(f"**💡 Raccomandazione:** {recommendation}")
        
        selected_series = st.selectbox(
            "Serie ABB:",
            options=["hi_t_plus", "resibloc", "onan"],
            format_func=lambda x: {
                "hi_t_plus": "Hi-T Plus (Economico)",
                "resibloc": "RESIBLOC (Standard)", 
                "onan": "ONAN (Premium)"
            }[x],
            index=["hi_t_plus", "resibloc", "onan"].index(default_series)
        )
    
    return selected_series


def _display_transformer_type_info(selected_series, installation_type, service_continuity):
    """🆕 VISUALIZZA CHIARAMENTE IL TIPO DI TRASFORMATORE SCELTO"""
    
    # Definizione caratteristiche per ogni serie
    transformer_types = {
        "hi_t_plus": {
            "name": "Hi-T Plus",
            "type": "A SECCO",
            "isolation": "Resina Epossidica",
            "cooling": "Aria Naturale (AN)",
            "class": "Economico",
            "icon": "💰",
            "description": "Trasformatore a secco con isolamento in resina, ideale per installazioni standard",
            "fire_risk": "Molto Basso",
            "maintenance": "Minima",
            "environment": "Eco-compatibile"
        },
        "resibloc": {
            "name": "RESIBLOC", 
            "type": "A SECCO",
            "isolation": "Resina Cast + Fibra di Vetro",
            "cooling": "Aria Naturale/Forzata (AN/AF)",
            "class": "Standard",
            "icon": "🏭",
            "description": "Trasformatore a secco rinforzato, resistente agli ambienti industriali",
            "fire_risk": "Molto Basso",
            "maintenance": "Ridotta",
            "environment": "Eco-compatibile"
        },
        "onan": {
            "name": "ONAN",
            "type": "IN OLIO",
            "isolation": "Olio Minerale",
            "cooling": "Olio Naturale/Aria Naturale (ONAN)",
            "class": "Premium",
            "icon": "⚡",
            "description": "Trasformatore in bagno d'olio, massima potenza e affidabilità",
            "fire_risk": "Controllato",
            "maintenance": "Periodica",
            "environment": "Controllo richiesto"
        }
    }
    
    selected_info = transformer_types[selected_series]
    
    st.markdown("### 🔋 Tipologia Trasformatore Selezionata")
    
    # Box principale con info tipo trasformatore
    st.success(f"""
    {selected_info['icon']} **{selected_info['name']} - {selected_info['type']}**
    
    Caratteristiche Tecniche:
    • Isolamento: {selected_info['isolation']}
    • Raffreddamento: {selected_info['cooling']}
    • Categoria: {selected_info['class']}
    • Rischio Incendio: {selected_info['fire_risk']}
    • Manutenzione: {selected_info['maintenance']}
    
    Descrizione: {selected_info['description']}
    """)
    
    # Motivazione della scelta in box separato
    #_display_selection_rationale(selected_series, installation_type, service_continuity, selected_info)
    
    # Caratteristiche aggiuntive in expander
    with st.expander("🔍 Confronto Serie Trasformatori ABB", expanded=True):
        _display_transformer_comparison_table()
        
    # 🆕 AGGIUNGI QUI LA DOCUMENTAZIONE
    _display_technical_documentation()


def _display_selection_rationale(selected_series, installation_type, service_continuity, selected_info):
    """Spiega perché è stato scelto questo tipo"""
    
    # Logica di motivazione
    if selected_series == "onan":
        if installation_type == "indoor" and service_continuity in ["essenziale", "privilegiata"]:
            reason = f"🏢 Installazione Indoor + Servizio {service_continuity.title()}\n\n" \
                    f"→ Scelta ONAN per **massima affidabilità** in ambienti critici"
        elif installation_type == "outdoor":
            reason = f"🌤️ Installazione Outdoor + Servizio {service_continuity.title()}\n\n" \
                    f"→ Scelta ONAN per **resistenza ambientale** e potenze elevate"
        else:
            reason = f"⚡ Servizio {service_continuity.title()}\n\n" \
                    f"→ Scelta ONAN per **continuità di servizio** garantita"
                    
    elif selected_series == "resibloc":
        reason = f"🏭 Ambiente Industriale\n\n" \
                f"→ Scelta RESIBLOC per **resistenza meccanica** e ambienti gravosi"
                
    else:  # hi_t_plus
        reason = f"💰 Installazione Standard\n\n" \
                f"→ Scelta Hi-T Plus per **rapporto qualità/prezzo** ottimale"
    
    # Vantaggi specifici per tipo
    if 'SECCO' in selected_info['type']:
        advantages = [
            "✅ Sicurezza antincendio massima",
            "✅ Manutenzione ridotta/assente", 
            "✅ Eco-compatibile (nessun liquido)",
            "✅ Installazione semplificata"
        ]
    else:  # IN OLIO
        advantages = [
            "✅ Massima potenza specifica",
            "✅ Migliore dissipazione termica",
            "✅ Durata vita elevata (40+ anni)",
            "✅ Costi contenuti per grandi potenze"
        ]
    
    st.info(f"""
    **🧠 Motivazione della Scelta:**
    
    {reason}
    
    Vantaggi per il tuo progetto: {' • '.join([adv.replace('✅ ', '') for adv in advantages[:2]])}
    """)


def _display_transformer_comparison_table():
    """Tabella comparativa dettagliata dei tipi di trasformatori"""
    
    st.markdown("#### 📊 Confronto Completo Tipologie Trasformatori ABB")
    
    # Dati comparativi
    comparison_data = {
        "Caratteristica": [
            "Tipo Isolamento",
            "Rischio Incendio", 
            "Manutenzione",
            "Impatto Ambientale",
            "Costo Iniziale",
            "Potenza Max Tipica",
            "Efficienza",
            "Durata Vita",
            "Installazione TR Indoor",
            "Resistenza Umidità",
            "Rumorosità",
            "Spazio Richiesto"
        ],
        "Hi-T Plus (A Secco)": [
            "Resina Epossidica",
            "Molto Basso ✅",
            "Minima ✅", 
            "Eco-compatibile ✅",
            "Basso ✅",
            "2500 kVA",
            "Alta (98%)",
            "25-30 anni",
            "Ideale ✅",
            "Buona",
            "Bassa ✅",
            "Compatto ✅"
        ],
        "RESIBLOC (A Secco)": [
            "Resina + Fibra Vetro",
            "Molto Basso ✅",
            "Ridotta ✅",
            "Eco-compatibile ✅", 
            "Medio",
            "5000 kVA",
            "Molto Alta (98.5%) ✅",
            "30-35 anni ✅",
            "Ideale ✅",
            "Eccellente ✅",
            "Bassa ✅",
            "Medio"
        ],
        "ONAN (In Olio)": [
            "Olio Minerale",
            "Controllato ⚠️",
            "Periodica ⚠️",
            "Controllo richiesto ⚠️",
            "Alto per grandi potenze",
            "Illimitata ✅",
            "Eccellente (99%) ✅", 
            "40+ anni ✅",
            "Limitazioni normative ⚠️",
            "Eccellente ✅",
            "Media",
            "Maggiore ⚠️"
        ]
    }
    
    df = pd.DataFrame(comparison_data)
    st.dataframe(df, use_container_width=True, hide_index=True)
    
    # Spiegazione dettagliata
    st.markdown("""
    🔍 Legenda e Note Tecniche:
    
    **➡️ Trasformatori A SECCO:**
    - **Isolamento:** Utilizzano resina epossidica o resina cast con fibra di vetro
    - **Sicurezza:** Nessun rischio di fuoriuscita liquidi infiammabili
    - **Manutenzione:** Non richiedono controllo liquidi isolanti
    - **Ambiente:** Ideali per installazioni indoor (ospedali, scuole, uffici)
    
    **➡️ Trasformatori IN OLIO:**
    - **Isolamento:** Olio minerale ad alto potere isolante
    - **Potenza:** Migliore dissipazione termica = potenze più elevate
    - **Durata:** L'olio protegge gli avvolgimenti = vita più lunga
    - **Costi:** Più economici per potenze > 1000 kVA
    
    **➡️ Simboli:**
    • ✅ = Vantaggio significativo  
    • ⚠️ = Richiede attenzione/valutazione
    """)


def _display_transformer_results(db, transformer_sizer, total_kva, user_redundancy, selected_series):
    """Visualizza risultati finali con fattore di carico target del 70%"""
    
    st.subheader("🎯 Configurazione Selezionata")
    
    # 🆕 CALCOLO CONFIGURAZIONE CON FATTORE DI CARICO TARGET 70%
    TARGET_LOAD_FACTOR = 0.70  # 70% di utilizzo target

    if user_redundancy:
        # Per configurazione doppia: ogni trasformatore deve gestire metà carico
        required_power_per_transformer = total_kva / 2
        # Dimensiona per lavorare al 70%
        target_transformer_size = required_power_per_transformer / TARGET_LOAD_FACTOR
        transformer_kva = db.get_transformer_by_power(target_transformer_size, selected_series, margin=1.0).power_kva
        num_transformers = 2
        # Calcola il fattore di carico effettivo
        load_factor = required_power_per_transformer / transformer_kva
        config_description = f"2 x {transformer_kva} kVA"
        
        st.info(f"""
        📐 **Logica di Dimensionamento (Configurazione Doppia con Margine 30%):**
        - Potenza totale richiesta: **{total_kva} kVA**
        - Potenza per trasformatore: **{required_power_per_transformer} kVA** (totale ÷ 2)
        - Target fattore di carico: **70%** (margine 30%)
        - Potenza trasformatore calcolata: **{target_transformer_size:.0f} kVA**
        - Taglia standard ABB selezionata: **{transformer_kva} kVA**
        - **Fattore di carico effettivo: {load_factor*100:.1f}%**
        """)
        
    else:
        # Per configurazione singola
        target_transformer_size = total_kva / TARGET_LOAD_FACTOR
        transformer_kva = db.get_transformer_by_power(target_transformer_size, selected_series, margin=1.0).power_kva
        num_transformers = 1
        load_factor = total_kva / transformer_kva
        config_description = f"1 x {transformer_kva} kVA"
        
        st.info(f"""
        📐 **Logica di Dimensionamento (con Margine 30%):**
        - Potenza richiesta: **{total_kva} kVA**
        - Target fattore di carico: **70%** (margine 30%)
        - Potenza trasformatore calcolata: **{target_transformer_size:.0f} kVA**
        - Taglia standard ABB selezionata: **{transformer_kva} kVA**
        - **Fattore di carico effettivo: {load_factor*100:.1f}%**
        """)
    
    # Recupera le specifiche complete del trasformatore
    base_transformer = db.get_transformer_by_power(target_transformer_size, selected_series, margin=1.0)
    
    # Metriche principali con evidenza del dimensionamento reale
    main_metrics = {
        "Trasformatori": config_description,
        "Utilizzo Effettivo": f"{load_factor*100:.1f}%",
        "Serie": base_transformer.series,
        "Costo Totale": format_currency(base_transformer.cost_estimate * num_transformers)
    }
    
    metrics_panel(main_metrics)
    
    # ✨ Analisi Dettagliata Utilizzo
    st.markdown("### 📊 Analisi Dettagliata Utilizzo")

    # Calcolo margine effettivo
    margin_percent = (1 - load_factor) * 100

    # Valutazione del margine
    if margin_percent >= 25:
        margin_status = "🟢 OTTIMALE"
        margin_color = "success"
    elif margin_percent >= 15:
        margin_status = "🟡 ACCETTABILE"
        margin_color = "warning"
    else:
        margin_status = "🔴 INSUFFICIENTE"
        margin_color = "error"

    # Metriche utilizzo in colonne
    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric(
            label="Utilizzo Effettivo", 
            value=f"{load_factor*100:.1f}%",
            help="Utilizzo in condizioni di esercizio normali"
        )

    with col2:
        st.metric(
            label="Margine di Sicurezza", 
            value=f"{margin_percent:.1f}%",
            help="Margine disponibile per espansioni future"
        )

    with col3:
        st.metric(
            label="Valutazione",
            value=margin_status,
            help="Valutazione della configurazione scelta"
        )

    # Box di valutazione
    if margin_color == "success":
        st.success(f"✅ **Configurazione ottimale:** Il trasformatore lavorerà al {load_factor*100:.1f}% con un margine del {margin_percent:.1f}%, ideale per future espansioni.")
    elif margin_color == "warning":
        st.warning(f"⚠️ **Configurazione accettabile:** Margine del {margin_percent:.1f}% sufficiente ma limitato per espansioni.")
    else:
        st.error(f"❌ **Attenzione:** Margine insufficiente del {margin_percent:.1f}%. Rischio di sovraccarico in caso di espansioni.")
    
    # Caratteristiche elettriche utilizzando display_utils
    electrical_specs = {
        'tensione_primaria_kv': st.session_state['distributor_data']['voltage_kv'],
        'tensione_secondaria_v': 415,
        'ucc_percent': base_transformer.ucc_percent,
        'corrente_secondario_a': (transformer_kva * 1000) / (1.732 * 415),
        'perdite_vuoto_w': base_transformer.losses_no_load_w,
        'perdite_carico_w': base_transformer.losses_load_w,
        'costo_eur': base_transformer.cost_estimate * num_transformers
    }
    
    technical_datasheet(
        "Caratteristiche Elettriche Trasformatore",
        electrical_specs,
        {
            'Elettriche': ['tensione_primaria_kv', 'tensione_secondaria_v', 'ucc_percent', 'corrente_secondario_a'],
            'Perdite': ['perdite_vuoto_w', 'perdite_carico_w'],
            'Economiche': ['costo_eur']
        }
    )
    
    # Analisi utilizzo business logic
    _display_transformer_analysis(transformer_sizer, transformer_kva, load_factor)
    
    # Conferma configurazione
    if st.button("✅ CONFERMA CONFIGURAZIONE", type="primary"):
        _save_transformer_configuration(db, base_transformer, num_transformers, load_factor, selected_series)


def _display_technical_documentation():
    """Visualizza link ai documenti tecnici ABB"""
    
    st.markdown("### 📚 Documentazione Tecnica")
    
    # Path relativo al documento
    docs_path = Path("docs/transformers")
    abb_catalog_path = docs_path / "abb_catalog_dry_type.pdf"
    
    # Verifica esistenza file
    if abb_catalog_path.exists():
        # Crea link per download
        with open(abb_catalog_path, "rb") as pdf_file:
            pdf_data = pdf_file.read()
            
        st.download_button(
            label="📄 Scarica Catalogo ABB Trasformatori",
            data=pdf_data,
            file_name="abb_catalog_dry_type.pdf",
            mime="application/pdf",
            help="Catalogo completo trasformatori ABB con specifiche tecniche dettagliate"
        )
        
        # Informazioni aggiuntive
        file_size = len(pdf_data) / (1024 * 1024)  # MB
        st.caption(f"📎 Documento: {abb_catalog_path.name} ({file_size:.1f} MB)")
        
    else:
        st.warning("⚠️ Catalogo ABB non trovato. Verifica che il file sia presente in docs/transformers/")
    
    # Link aggiuntivi utili
    st.markdown("#### 🔗 Risorse Online ABB")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        🌐 **Sito Ufficiale ABB:**
        - [Trasformatori di Distribuzione](https://new.abb.com/products/transformers)
        - [Catalogo Online](https://new.abb.com/search/results#query=transformer)
        """)
    
    with col2:
        st.markdown("""
        📖 **Documentazione Tecnica:**
        - [Specifiche RESIBLOC](https://new.abb.com/docs/librariesprovider50/kundem%C3%B8ter-konferanser/ren-metodedager-2019/resibloc-presentation-en-10-2018.pdf?sfvrsn=f6133915_2)
        - [Specifiche ONAN](https://electrification.us.abb.com/catalog/buylog/25_BuyLog2017_TransformersMandH.pdf)
        """)


def _display_transformer_analysis(transformer_sizer, transformer_kva, load_factor):
    """Visualizza analisi utilizzando business logic"""
    
    # Calcola perdite e efficienza utilizzando business module
    efficiency_analysis = transformer_sizer.calculate_losses_and_efficiency(
        transformer_kva, load_factor, "A"
    )
    
    with st.expander("📋 Analisi Efficienza Energetica", expanded=True):
        
        efficiency_metrics = {
            "Rendimento": f"{efficiency_analysis['efficiency_percent']}%",
            "Perdite Totali": f"{efficiency_analysis['total_losses_kw']} kW",
            "Costo Annuale Perdite": format_currency(efficiency_analysis['annual_loss_cost_eur']),
            "Classe Efficienza": efficiency_analysis['efficiency_class']
        }
        
        metrics_panel(efficiency_metrics, "⚡ Efficienza Energetica")


def _save_transformer_configuration(db, base_transformer, num_transformers, load_factor, selected_series):
    """Salva configurazione nella sessione"""
    
    # Recupera i valori originali per il calcolo corretto
    results = st.session_state['calculation_results']
    total_kva = results['total_power_kva']
    
    st.session_state['transformer_config'] = {
        'num_transformers': num_transformers,
        'power_kva': base_transformer.power_kva,
        'total_power': base_transformer.power_kva * num_transformers,
        'series': base_transformer.series,
        'series_code': selected_series,
        'specifications': base_transformer,
        'ucc_percent': base_transformer.ucc_percent,
        'current_secondary_a': (base_transformer.power_kva * 1000) / (1.732 * 415),
        'losses_no_load_w': base_transformer.losses_no_load_w,
        'losses_load_w': base_transformer.losses_load_w,
        'total_cost': base_transformer.cost_estimate * num_transformers,
        'load_factor': load_factor,
        'normative_compliance': True,
        # 🆕 Info aggiuntive sul tipo di trasformatore
        'transformer_type': 'A SECCO' if selected_series in ['hi_t_plus', 'resibloc'] else 'IN OLIO',
        'isolation_type': {
            'hi_t_plus': 'Resina Epossidica',
            'resibloc': 'Resina Cast + Fibra di Vetro', 
            'onan': 'Olio Minerale'
        }[selected_series],
        'cooling_type': {
            'hi_t_plus': 'Aria Naturale (AN)',
            'resibloc': 'Aria Naturale/Forzata (AN/AF)',
            'onan': 'Olio Naturale/Aria Naturale (ONAN)'
        }[selected_series]
    }
    
    st.success("✅ Trasformatori configurati!")
    st.balloons()
    st.rerun()
