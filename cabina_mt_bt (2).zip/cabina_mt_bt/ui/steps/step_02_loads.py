"""
Step 2: Calcolo Carichi
Modulo refactored che utiliza i moduli di business logic esistenti
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from ui.step_components import (
    create_step_container, enhanced_dataframe, 
    editable_load_table, power_distribution_chart, metrics_panel
)
from calculations.loads import LoadCalculator, SimpleLoad
from ui.display_utils import format_engineering_value


def step_2_load_calculation():
    """Step 2: Calcolo carichi - Versione refactored"""
    
    create_step_container("⚡ Step 2: Calcolo Carichi Elettrici")
    
    if 1 not in st.session_state['completed_steps']:
        st.error("❌ Completa prima lo Step 1 (Dati Distributore)")
        return
    
    # Gestione carichi utilizzando componente esistente
    st.subheader("📝 Gestione Carichi")
    
    if not st.session_state['loads']:
        st.warning("⚠️ Nessun carico inserito. Usa la sidebar per aggiungere carichi.")
        return
    
    # Tabella carichi editabile con componente esistente
    st.session_state['loads'] = editable_load_table(
        st.session_state['loads'],
        on_change_callback=lambda: st.rerun()
    )
    
    # Calcolo carichi
    if st.button("🧮 CALCOLA CARICHI"):
        _perform_load_calculation()
    
    # ✅ PULSANTE AVANZAMENTO - Sempre visibile se il calcolo è stato fatto
    if st.session_state.get('calculation_results'):
        st.markdown("---")
        if st.button("➡️ PROCEDI AL STEP 3", type="primary"):
            st.session_state['completed_steps'].add(2)
            st.session_state['current_step'] = 3
            st.rerun()


def _perform_load_calculation():
    """Esegue il calcolo dei carichi utilizzando il modulo esistente con separazione CEI 64-8"""
    
    # 🆕 ESPANSIONE CARICHI MULTIPLI SECONDO CEI 64-8
    expanded_loads = []
    
    for load in st.session_state['loads']:
        # Motori ≥ 0.5 kW devono essere separati (CEI 64-8 Art. 552.1.2)
        if (load.quantity > 1 and 
            load.power_kw >= 0.5 and 
            ('motori' in load.type_str.lower() or 'motore' in load.name.lower())):
            
            # Crea un carico separato per ogni motore
            for i in range(load.quantity):
                individual_load = SimpleLoad(
                    name=f"{load.name} #{i+1}",
                    type_str=load.type_str,
                    power_kw=load.power_kw,
                    quantity=1,  # Ogni motore è individuale
                    ku_factor=load.ku_factor,
                    cos_phi=load.cos_phi,
                    voltage=load.voltage,
                    phases=load.phases
                )
                expanded_loads.append(individual_load)
        else:
            # Altri carichi rimangono aggregati
            expanded_loads.append(load)
    
    # Calcola con carichi espansi
    calc = LoadCalculator()
    results = calc.calculate_loads(expanded_loads)
    st.session_state['calculation_results'] = results
    
    # Info normativa
    motor_count = sum(1 for load in expanded_loads if 'motore' in load.name.lower())
    if motor_count > 1:
        st.info(f"ℹ️ **Conformità CEI 64-8:** {motor_count} motori separati secondo Art. 552.1.2")
    
    # Resto del codice rimane uguale...
    st.subheader("📊 Risultati Calcolo")
    
    main_metrics = {
        "Potenza Attiva": f"{results['total_power_kw']} kW",
        "Potenza Apparente": f"{results['total_power_kva']} kVA", 
        "Cos φ medio": f"{results['average_cos_phi']}"
    }
    
    metrics_panel(main_metrics)
    
    enhanced_dataframe(
        pd.DataFrame(results['load_breakdown']),
        title="Breakdown Dettagliato Carichi",
        enable_download=True
    )
    
    _display_load_distribution_chart(results)
    
    st.success("✅ Calcolo carichi completato secondo normative CEI")


def _display_load_distribution_chart(results):
    """Visualizza grafico distribuzione carichi con layout elegante"""
    st.subheader("📊 Distribuzione Tipologia Carichi")
    
    # Calcola distribuzione per tipo
    load_distribution = {}
    
    for load in st.session_state['loads']:
        load_power = load.power_kw * load.quantity * load.ku_factor
        load_type = load.type_str
        
        if load_type in load_distribution:
            load_distribution[load_type] += load_power
        else:
            load_distribution[load_type] = load_power
    
    if load_distribution:
        # Crea grafico a torta con effetto 3D
        fig = go.Figure(data=[go.Pie(
            labels=list(load_distribution.keys()),
            values=list(load_distribution.values()),
            hole=0.3,  # Dona effetto "anello"
            textinfo='label+percent',
            textfont_size=15,
            marker=dict(
                line=dict(color='#FFFFFF', width=3)  # Bordi bianchi
            ),
            pull=[0.1, 0, 0, 0]  # "Estrae" la prima fetta per effetto 3D
        )])
        
        # Layout con effetti 3D-ish
        fig.update_layout(
            
            width=800,
            height=600,
            showlegend=True,
            plot_bgcolor='rgba(0,0,0,0)',  # Sfondo trasparente
            paper_bgcolor='rgba(0,0,0,0)',
            legend=dict(
                font=dict(size=18)  # 🆕 Dimensione testo legenda (default è ~12)

            )
        )
        
        # Mostra con Streamlit
        st.plotly_chart(fig, use_container_width=True)
