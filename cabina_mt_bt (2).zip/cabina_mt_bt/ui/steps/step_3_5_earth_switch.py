"""
Step 3.5: Sezionatore di Terra
Selezione e configurazione sezionatore di terra MT
"""

import streamlit as st
from ui.step_components import create_step_container
from database.earth_switches import (
    select_optimal_earth_switch,
    calculate_installation_costs,
    get_technical_specifications,
    get_pole_configuration
)

def step_3_5_earth_switch_design():
    """Step 3.5: Sezionatore di Terra"""
    
    create_step_container("⚡ Step 3.5: Sezionatore di Terra")
    
    if 3 not in st.session_state['completed_steps']:
        st.error("❌ Completa prima lo Step 3 (Trasformatori)")
        return
    
    # 🔧 CORREZIONE: Gestione robusta dei dati
    transformer_config = st.session_state.get('transformer_config')
    distributor_data = st.session_state.get('distributor_data') or {}
    
    # 🆕 FALLBACK CON DATABASE SE DATI MANCANTI
    if not transformer_config:
        st.warning("⚠️ Configurazione trasformatore non trovata. Usando valori di default dal database.")
        
        # Importa il database prodotti
        from database.products import ProductDatabase
        db = ProductDatabase()
        
        # Usa valori di default realistici
        default_transformer = db.get_transformer_by_power(800, "hi_t_plus", margin=1.0)
        
        transformer_config = {
            'power_kva': default_transformer.power_kva,
            'series': default_transformer.series,
            'ucc_percent': default_transformer.ucc_percent,
            'current_secondary_a': (default_transformer.power_kva * 1000) / (1.732 * 415),
            'total_cost': default_transformer.cost_estimate
        }
        
        st.info(f"🔄 Usando trasformatore di default: {default_transformer.series} {default_transformer.power_kva} kVA")
    
    # Calcolo corrente nominale MT
    transformer_kva = transformer_config.get('power_kva')
    # Verifica che il valore sia valido
    if not transformer_kva:
        st.error("❌ Potenza trasformatore non trovata. Torna allo Step 3 e conferma la configurazione.")
        return
    voltage_kv = distributor_data.get('voltage_kv', 20)
    current_mt_calc = transformer_kva / (1.732 * voltage_kv)
    
    # Selezione corrente nominale sezionatore
    available_ratings = [400, 630, 800, 1000]
    min_required = current_mt_calc * 1.1
    recommended_rating = next((rating for rating in available_ratings if rating >= min_required), 1000)
    
    # Corrente cortocircuito MT
    icc_mt = distributor_data.get('icc_3phase_ka', 16)
    
    # 🧮 CALCOLI AUTOMATICI COMPATTI
    st.subheader("🧮 Calcoli Automatici")
    
    calc_col1, calc_col2, calc_col3 = st.columns(3)
    with calc_col1:
        st.metric("Potenza Trasformatore", f"{transformer_kva} kVA")
        st.metric("Tensione MT", f"{voltage_kv} kV")
    with calc_col2:
        st.metric("Corrente Nominale MT", f"{current_mt_calc:.1f} A")
        st.metric("Corrente CC MT", f"{icc_mt} kA")
    with calc_col3:
        st.metric("Corrente Min Richiesta", f"{min_required:.0f} A")
        st.metric("🎯 Raccomandazione", f"{recommended_rating} A")
    
    # 🆕 SELEZIONE AUTOMATICA MODELLO ABB
    # 🆕 SOLUZIONE EVIDENZIATA - Header migliorato
    st.markdown("### ⚡ **INTERRUTTORE DI ISOLAMENTO - SOLUZIONE ABB CONSIGLIATA**")

    # Selezione automatica usando il modulo
    earth_fault_current = distributor_data.get('earth_fault_current_a', 50)
    neutral_regime = distributor_data.get('neutral_regime', 'isolato')

    recommended_switch = select_optimal_earth_switch(
        current_required_a=current_mt_calc,
        voltage_kv=voltage_kv,
        icc_ka=icc_mt,
        neutral_regime=neutral_regime,
        earth_fault_current_a=earth_fault_current
    )

    #  BOX EVIDENZIATO CON LA SOLUZIONE
    col_badge, col_spacer = st.columns([3, 1])
    with col_badge:
        st.success(f"""
        # **{recommended_switch['model_complete']}**
        ### Codice ABB: `{recommended_switch['full_code']}`
        **La soluzione ottimale per la tua cabina MT/BT da {transformer_kva} kVA**
        """)

    st.markdown("---")
    st.markdown("#### 📋 Dettagli Tecnici e Motivazione")

    # 🆕 LAYOUT COMPATTO A 2 COLONNE PRINCIPALI
    main_col1, main_col2 = st.columns(2)

    with main_col1:
        # Box modello raccomandato compatto
        st.success(f"""
**🔧 {recommended_switch['model_complete']}**

**Caratteristiche Principali:**
- **Codice ABB:** {recommended_switch['full_code']}
- **Tensione nominale:** {recommended_switch['voltage_kv']} kV
- **Corrente nominale:** {recommended_switch['current_a']} A
- **Configurazione:** {recommended_switch['pole_configuration']}
- **Potere di chiusura:** {recommended_switch['breaking_capacity_ka']} kA
- **Installazione:** {', '.join(recommended_switch['installation_types'])}

**💰 Prezzo base: €{recommended_switch['price_eur']:,}**
""")

    with main_col2:
        # Box motivazione scelta compatto
        st.info(f"""
**🧠 Perché questo sezionatore:**

- **Corrente:** {recommended_switch['current_a']}A > {current_mt_calc:.1f}A richiesta ✅
- **Cortocircuito:** Resistente a {icc_mt} kA ✅  
- **Tensione:** {recommended_switch['voltage_kv']} kV > {voltage_kv} kV rete ✅
- **Normative:** Conforme CEI 11-27 ✅

**Configurazione poli:** {recommended_switch['pole_explanation']}

**Descrizione:** {recommended_switch['description']}
""")

    # 🔧 CONFIGURAZIONE COMPATTA
    st.subheader("🔧 Optional e Configurazioni")
    
    config_col1, config_col2 = st.columns(2)
    
    with config_col1:
        switch_type = st.selectbox("Tipo Sezionatore:", ["Manuale", "Motorizzato"])
        
        # Corrente nominale con raccomandazione automatica
        available_options = ["400A", "630A", "800A", "1000A"]
        recommended_option = f"{recommended_rating}A"
        
        if recommended_option in available_options:
            default_index = available_options.index(recommended_option)
        else:
            default_index = 1
        
        current_rating = st.selectbox(
            "Corrente Nominale:", 
            available_options,
            index=default_index,
            help=f"🎯 Raccomandato: {recommended_rating}A (In_MT = {current_mt_calc:.1f}A + margine 10%)"
        )
    
    with config_col2:
        installation = st.selectbox("Installazione:", ["Indoor", "Outdoor"])
        cei_compliant = st.checkbox("Conformità CEI 11-27", value=True)
        
        # Verifica conformità compatta
        selected_current = int(current_rating.replace('A', ''))
        is_compliant = selected_current >= current_mt_calc * 1.1
        
        if is_compliant:
            st.success(f"✅ Conforme: {selected_current}A ≥ {current_mt_calc * 1.1:.0f}A")
        else:
            st.error(f"❌ Non conforme: {selected_current}A < {current_mt_calc * 1.1:.0f}A")

    # 🆕 CARATTERISTICHE TECNICHE COMPATTE
    with st.expander("⚡ Caratteristiche Tecniche Dettagliate", expanded=False):
        tech_specs = get_technical_specifications(recommended_switch, switch_type, installation)
        
        spec_col1, spec_col2 = st.columns(2)
        
        with spec_col1:
            st.markdown("#### 🔌 Caratteristiche Elettriche")
            st.markdown(f"• **Tensione nominale:** {tech_specs['elettriche']['tensione_nominale']}")
            st.markdown(f"• **Corrente nominale:** {tech_specs['elettriche']['corrente_nominale']}")
            st.markdown(f"• **Configurazione poli:** {tech_specs['elettriche']['configurazione_poli']}")
            st.markdown(f"• **Frequenza:** {tech_specs['elettriche']['frequenza']}")
            st.markdown(f"• **Potere chiusura c.c.:** {tech_specs['elettriche']['potere_chiusura_cc']}")
            st.markdown(f"• **Corrente picco:** {tech_specs['elettriche']['corrente_picco']}")
            
            st.markdown("#### 🛡️ Sicurezza e Protezione")
            st.markdown(f"• **Grado protezione:** {tech_specs['sicurezza']['grado_protezione']}")
            st.markdown(f"• **Classe isolamento:** {tech_specs['sicurezza']['classe_isolamento']}")
            st.markdown(f"• **Indicazione posizione:** {tech_specs['sicurezza']['indicazione_posizione']}")
            st.markdown(f"• **Conformità normative:** {tech_specs['sicurezza']['conformita_normative']}")
        
        with spec_col2:
            st.markdown("#### 🔧 Caratteristiche Meccaniche")
            for key, value in tech_specs['meccaniche'].items():
                st.markdown(f"• **{key.replace('_', ' ').title()}:** {value}")
            
            st.markdown("#### 🌡️ Condizioni Ambientali")
            st.markdown(f"• **Temperatura servizio:** {tech_specs['ambientali']['temperatura_servizio']}")
            st.markdown(f"• **Umidità relativa:** {tech_specs['ambientali']['umidita_relativa']}")
            st.markdown(f"• **Altitudine max:** {tech_specs['ambientali']['altitudine_max']}")
            st.markdown(f"• **Resistenza sismica:** {tech_specs['ambientali']['resistenza_sismica']}")
            
            st.markdown("#### 📏 Dimensioni e Peso")
            st.markdown(f"• **Dimensioni:** {tech_specs['dimensioni']['altezza']} × {tech_specs['dimensioni']['larghezza']} × {tech_specs['dimensioni']['profondita']}")
            st.markdown(f"• **Peso:** {tech_specs['dimensioni']['peso']}")
            st.markdown(f"• **Spazio manovra:** {tech_specs['dimensioni']['spazio_manovra']}")

    # 🆕 ANALISI ECONOMICA COMPATTA
    st.markdown("#### 💰 Analisi Economica e Installazione")

    cost_analysis = calculate_installation_costs(recommended_switch, switch_type, installation)

    eco_col1, eco_col2 = st.columns(2)

    with eco_col1:
        st.markdown("**💵 Breakdown Costi:**")
        st.markdown(f"""
- **Sezionatore base:** €{cost_analysis['sezionatore_base']:,}
- **Accessori/optional:** €{cost_analysis['accessori_optional']:,}
- **Installazione manodopera:** €{cost_analysis['installazione_manodopera']:,.0f}
- **Cablaggio:** €{cost_analysis['cablaggio']:,}
- **Supporti meccanici:** €{cost_analysis['supporti_meccanici']:,}

**🎯 TOTALE PROGETTO: €{cost_analysis['totale_progetto']:,.0f}**
""")

    with eco_col2:
        st.markdown("**🔧 Installazione Richiesta:**")
        st.markdown(f"""
- **Tipo installazione:** {installation}
- **Spazio richiesto:** 600×420×280 mm + manovra
- **Supporti:** Pannello/mensola metallica
- **Cablaggio:** Cavi MT + controllo ({switch_type.lower()})
- **Messa a terra:** Connessione equipotenziale
- **Tempo installazione:** 4-6 ore

**📋 Documenti necessari:**
- Certificato CE + DoC
- Istruzioni montaggio ABB
- Schemi elettrici collegamento
""")
    
    # PULSANTI
    if st.button("✅ CONFIGURA SEZIONATORE"):
        st.session_state['earth_switch_system'] = {
            'type': switch_type,
            'current_rating': current_rating,
            'installation': installation,
            'cei_compliant': cei_compliant,
            'configured': True,
            'model': recommended_switch['model_complete'],
            'code': recommended_switch['full_code'],
            'total_cost': cost_analysis['totale_progetto'],
            'pole_configuration': recommended_switch['pole_configuration']
        }
        st.success("✅ Sezionatore configurato!")
        st.rerun()
    
    # ✅ PULSANTE AVANZAMENTO
    if st.session_state.get('earth_switch_system', {}).get('configured'):
        st.markdown("---")
        if st.button("➡️ PROCEDI AL STEP 4", type="primary"):
            st.session_state['completed_steps'].add(3.5)
            st.session_state['current_step'] = 4
            st.rerun()