"""
Validation UI - Componenti UI per validazioni e verifiche
Software Cabina MT/BT Professional v2.0 - OTTIMIZZATO
"""

import streamlit as st
from typing import Dict, List, Any, Tuple, Optional, Callable
import pandas as pd

# ===============================================================================
# VALIDAZIONE E CONTROLLI
# ===============================================================================

def validation_panel(validation_results: Dict[str, Any], 
                    title: str = "Validazione Sistema") -> bool:
    """
    Pannello di validazione con risultati strutturati
    
    Args:
        validation_results: Dict con chiavi valid, issues, warnings, suggestions
        title: Titolo del pannello
    
    Returns:
        True se validazione passata
    """
    st.subheader(title)
    
    is_valid = validation_results.get('valid', False)
    issues = validation_results.get('issues', [])
    warnings = validation_results.get('warnings', [])
    suggestions = validation_results.get('suggestions', [])
    score = validation_results.get('score', 0)
    
    # Status principale
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        if is_valid:
            st.success(f"✅ **{title} SUPERATA**")
        else:
            st.error(f"❌ **{title} FALLITA**")
    
    with col2:
        if score > 0:
            st.metric("Punteggio", f"{score}/100")
    
    with col3:
        status_color = "normal" if is_valid else "inverse"
        st.metric("Status", "PASS" if is_valid else "FAIL")
    
    # Dettagli problemi
    if issues:
        st.markdown("**🚨 Problemi Critici:**")
        for issue in issues:
            st.error(f"• {issue}")
    
    if warnings:
        st.markdown("**⚠️ Avvertimenti:**")
        for warning in warnings:
            st.warning(f"• {warning}")
    
    if suggestions:
        st.markdown("**💡 Suggerimenti:**")
        for suggestion in suggestions:
            st.info(f"• {suggestion}")
    
    return is_valid

def step_prerequisites_check(step_number: int, 
                           required_steps: List[int],
                           completed_steps: set,
                           show_details: bool = True) -> bool:
    """
    Verifica prerequisiti per uno step
    
    Args:
        step_number: Numero step corrente
        required_steps: Lista step richiesti
        completed_steps: Set step completati
        show_details: Mostra dettagli verifica
    
    Returns:
        True se prerequisiti soddisfatti
    """
    missing_steps = [s for s in required_steps if s not in completed_steps]
    
    if not missing_steps:
        if show_details:
            st.success(f"✅ **Step {step_number}:** Tutti i prerequisiti soddisfatti")
        return True
    
    if show_details:
        st.error(f"❌ **Step {step_number}:** Prerequisiti mancanti")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.metric("Step Richiesti", len(required_steps))
            st.metric("Step Mancanti", len(missing_steps))
        
        with col2:
            st.markdown("**Step da completare:**")
            for step in missing_steps:
                st.error(f"• Step {step}")
    
    return False

def field_validation_indicator(field_name: str, 
                             value: Any,
                             validator: Callable[[Any], Tuple[bool, str]],
                             show_inline: bool = True) -> bool:
    """
    Indicatore di validazione per singolo campo
    
    Args:
        field_name: Nome campo
        value: Valore da validare
        validator: Funzione validazione che ritorna (is_valid, message)
        show_inline: Mostra indicatore inline
    
    Returns:
        True se campo valido
    """
    is_valid, message = validator(value)
    
    if show_inline:
        if is_valid:
            st.success(f"✅ {field_name}: {message}")
        else:
            st.error(f"❌ {field_name}: {message}")
    
    return is_valid

def compliance_matrix(compliance_checks: Dict[str, bool],
                     category_title: str = "Conformità Normative") -> float:
    """
    Matrice di conformità normative
    
    Args:
        compliance_checks: Dict norma: is_compliant
        category_title: Titolo categoria
    
    Returns:
        Percentuale di conformità
    """
    st.subheader(category_title)
    
    total_checks = len(compliance_checks)
    passed_checks = sum(1 for check in compliance_checks.values() if check)
    compliance_percentage = (passed_checks / total_checks * 100) if total_checks > 0 else 0
    
    # Indicatore generale
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Verifiche Totali", total_checks)
    with col2:
        st.metric("Verifiche Superate", passed_checks)
    with col3:
        st.metric("Conformità", f"{compliance_percentage:.1f}%")
    
    # Status generale
    if compliance_percentage >= 90:
        st.success("🎯 **SISTEMA COMPLETAMENTE CONFORME**")
    elif compliance_percentage >= 70:
        st.warning("⚠️ **Sistema prevalentemente conforme**")
    else:
        st.error("❌ **Sistema non conforme**")
    
    # Dettagli conformità
    with st.expander("📋 Dettaglio Conformità", expanded=compliance_percentage < 90):
        for norm, is_compliant in compliance_checks.items():
            if is_compliant:
                st.success(f"✅ {norm}")
            else:
                st.error(f"❌ {norm}")
    
    return compliance_percentage

def safety_check_panel(safety_parameters: Dict[str, Dict],
                      critical_thresholds: Dict[str, float] = None) -> bool:
    """
    Pannello di controlli di sicurezza
    
    Args:
        safety_parameters: Dict parametro: {value, threshold, unit, critical}
        critical_thresholds: Soglie critiche opzionali
    
    Returns:
        True se tutti i controlli di sicurezza passano
    """
    st.subheader("🔒 Controlli di Sicurezza")
    
    all_safe = True
    critical_issues = []
    warnings = []
    
    for param_name, param_data in safety_parameters.items():
        value = param_data['value']
        threshold = param_data['threshold']
        unit = param_data.get('unit', '')
        is_critical = param_data.get('critical', False)
        
        # Determina se il valore è sicuro (valore <= soglia)
        is_safe = value <= threshold
        
        if not is_safe:
            all_safe = False
            if is_critical:
                critical_issues.append(f"{param_name}: {value}{unit} > {threshold}{unit}")
            else:
                warnings.append(f"{param_name}: {value}{unit} > {threshold}{unit}")
        
        # Visualizza metrica
        col1, col2 = st.columns([2, 1])
        
        with col1:
            delta_color = "normal" if is_safe else "inverse"
            st.metric(
                f"🔧 {param_name}", 
                f"{value}{unit}",
                delta=f"Limite: {threshold}{unit}"
            )
        
        with col2:
            if is_safe:
                st.success("✅ SICURO" if not is_critical else "✅ CRIT OK")
            else:
                if is_critical:
                    st.error("🚨 CRITICO")
                else:
                    st.warning("⚠️ ATTENZIONE")
    
    # Riepilogo finale
    st.markdown("---")
    
    if all_safe:
        st.success("🛡️ **TUTTI I CONTROLLI DI SICUREZZA SUPERATI**")
    else:
        if critical_issues:
            st.error("🚨 **PROBLEMI CRITICI DI SICUREZZA RILEVATI**")
            for issue in critical_issues:
                st.error(f"• {issue}")
        
        if warnings:
            st.warning("⚠️ **Avvertimenti di Sicurezza**")
            for warning in warnings:
                st.warning(f"• {warning}")
    
    return all_safe

# ===============================================================================
# VERIFICHE TECNICHE SPECIALIZZATE
# ===============================================================================

def electrical_validation_suite(electrical_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Suite di validazioni elettriche completa
    
    Args:
        electrical_data: Dati elettrici del sistema
    
    Returns:
        Risultati validazione strutturati
    """
    results = {
        'valid': True,
        'issues': [],
        'warnings': [],
        'suggestions': [],
        'score': 100
    }
    
    # Validazione tensioni
    voltage_checks = validate_voltage_levels(electrical_data.get('voltages', {}))
    if not voltage_checks['valid']:
        results['valid'] = False
        results['issues'].extend(voltage_checks['issues'])
        results['score'] -= 20
    
    # Validazione correnti
    current_checks = validate_current_levels(electrical_data.get('currents', {}))
    if not current_checks['valid']:
        results['valid'] = False
        results['issues'].extend(current_checks['issues'])
        results['score'] -= 20
    
    # Validazione potenze
    power_checks = validate_power_balance(electrical_data.get('powers', {}))
    if not power_checks['valid']:
        results['warnings'].extend(power_checks['warnings'])
        results['score'] -= 10
    
    # Validazione protezioni
    protection_checks = validate_protection_coordination(electrical_data.get('protections', {}))
    if not protection_checks['valid']:
        results['valid'] = False
        results['issues'].extend(protection_checks['issues'])
        results['score'] -= 30
    
    return results

def validate_voltage_levels(voltages: Dict[str, float]) -> Dict[str, Any]:
    """Validazione livelli di tensione"""
    issues = []
    
    # Standard tensioni italiane
    standard_voltages = {
        'mt_primary': [15000, 20000, 23000],  # Tensioni MT standard
        'bt_secondary': [400, 415, 230]       # Tensioni BT standard
    }
    
    for voltage_type, voltage_value in voltages.items():
        if voltage_type in standard_voltages:
            if voltage_value not in standard_voltages[voltage_type]:
                issues.append(f"Tensione {voltage_type} non standard: {voltage_value}V")
    
    return {
        'valid': len(issues) == 0,
        'issues': issues
    }

def validate_current_levels(currents: Dict[str, float]) -> Dict[str, Any]:
    """Validazione livelli di corrente"""
    issues = []
    
    # Controllo sovraccarichi
    if 'transformer_current' in currents and 'load_current' in currents:
        utilization = currents['load_current'] / currents['transformer_current']
        if utilization > 0.9:
            issues.append(f"Sovraccarico trasformatore: {utilization*100:.1f}%")
    
    return {
        'valid': len(issues) == 0,
        'issues': issues
    }

def validate_power_balance(powers: Dict[str, float]) -> Dict[str, Any]:
    """Validazione bilanciamento potenze"""
    warnings = []
    
    if 'transformer_power' in powers and 'load_power' in powers:
        utilization = powers['load_power'] / powers['transformer_power']
        
        if utilization < 0.6:
            warnings.append(f"Sottoutilizzo trasformatore: {utilization*100:.1f}%")
        elif utilization > 0.85:
            warnings.append(f"Utilizzo elevato trasformatore: {utilization*100:.1f}%")
    
    return {
        'valid': True,
        'warnings': warnings
    }

def validate_protection_coordination(protections: Dict[str, Any]) -> Dict[str, Any]:
    """Validazione coordinamento protezioni"""
    issues = []
    
    # Verifica selettività
    selectivity = protections.get('selectivity_percentage', 0)
    if selectivity < 85:
        issues.append(f"Selettività insufficiente: {selectivity:.1f}% < 85%")
    
    # Verifica coordinamento MT-BT
    mt_bt_coordination = protections.get('mt_bt_coordinated', False)
    if not mt_bt_coordination:
        issues.append("Coordinamento MT-BT non verificato")
    
    return {
        'valid': len(issues) == 0,
        'issues': issues
    }

# ===============================================================================
# REPORTS E EXPORT VALIDAZIONI
# ===============================================================================

def validation_report_generator(all_validations: Dict[str, Dict]) -> pd.DataFrame:
    """
    Genera report completo di tutte le validazioni
    
    Args:
        all_validations: Dict categoria: validation_results
    
    Returns:
        DataFrame con report dettagliato
    """
    report_data = []
    
    for category, validation in all_validations.items():
        report_data.append({
            'Categoria': category,
            'Status': 'PASS' if validation.get('valid', False) else 'FAIL',
            'Punteggio': validation.get('score', 0),
            'Problemi': len(validation.get('issues', [])),
            'Avvertimenti': len(validation.get('warnings', [])),
            'Note': '; '.join(validation.get('suggestions', [])[:2])  # Prime 2 suggestions
        })
    
    return pd.DataFrame(report_data)

def export_validation_results(validations: Dict[str, Dict], 
                            project_name: str = "progetto") -> None:
    """
    Esporta risultati validazioni in formato scaricabile
    
    Args:
        validations: Risultati validazioni
        project_name: Nome progetto per file
    """
    report_df = validation_report_generator(validations)
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Download CSV
        csv = report_df.to_csv(index=False)
        st.download_button(
            label="📥 Scarica Report CSV",
            data=csv,
            file_name=f"validazione_{project_name}.csv",
            mime="text/csv"
        )
    
    with col2:
        # Download JSON dettagliato
        import json
        json_data = json.dumps(validations, indent=2, ensure_ascii=False)
        st.download_button(
            label="📥 Scarica JSON Dettagliato",
            data=json_data,
            file_name=f"validazione_dettaglio_{project_name}.json",
            mime="application/json"
        )

# ===============================================================================
# HELPER E UTILITY PER VALIDAZIONI
# ===============================================================================

def create_validator(validation_type: str, **params) -> Callable:
    """
    Factory per creare validatori personalizzati
    
    Args:
        validation_type: Tipo validatore ('range', 'list', 'custom')
        **params: Parametri specifici per il validatore
    
    Returns:
        Funzione validatore
    """
    if validation_type == 'range':
        min_val = params.get('min', float('-inf'))
        max_val = params.get('max', float('inf'))
        
        def range_validator(value):
            if min_val <= value <= max_val:
                return True, f"Valore nel range [{min_val}, {max_val}]"
            else:
                return False, f"Valore fuori range: {value} non in [{min_val}, {max_val}]"
        
        return range_validator
    
    elif validation_type == 'list':
        valid_values = params.get('values', [])
        
        def list_validator(value):
            if value in valid_values:
                return True, f"Valore valido: {value}"
            else:
                return False, f"Valore non valido: {value} non in {valid_values}"
        
        return list_validator
    
    elif validation_type == 'custom':
        check_func = params.get('func')
        success_msg = params.get('success_msg', "Validazione superata")
        error_msg = params.get('error_msg', "Validazione fallita")
        
        def custom_validator(value):
            if check_func(value):
                return True, success_msg
            else:
                return False, error_msg
        
        return custom_validator
    
    # Default validator
    def default_validator(value):
        return True, "Validazione di base"
    
    return default_validator

def batch_validate(data: Dict[str, Any], validators: Dict[str, Callable]) -> Dict[str, Any]:
    """
    Valida un batch di campi con i rispettivi validatori
    
    Args:
        data: Dati da validare
        validators: Dict campo: validator_function
    
    Returns:
        Risultati validazione strutturati
    """
    results = {
        'valid': True,
        'field_results': {},
        'issues': [],
        'score': 100
    }
    
    failed_fields = 0
    total_fields = len(validators)
    
    for field_name, validator in validators.items():
        if field_name in data:
            try:
                is_valid, message = validator(data[field_name])
                results['field_results'][field_name] = {
                    'valid': is_valid,
                    'message': message,
                    'value': data[field_name]
                }
                
                if not is_valid:
                    results['valid'] = False
                    results['issues'].append(f"{field_name}: {message}")
                    failed_fields += 1
            
            except Exception as e:
                results['valid'] = False
                results['issues'].append(f"Errore validazione {field_name}: {str(e)}")
                failed_fields += 1
        else:
            results['issues'].append(f"Campo mancante: {field_name}")
            failed_fields += 1
    
    # Calcola punteggio
    if total_fields > 0:
        results['score'] = int((total_fields - failed_fields) / total_fields * 100)
    
    return results
