"""
UI Progress - Progress bar e gestione session state
"""

import streamlit as st

def initialize_session_state():
    """Inizializza tutti i session state necessari"""
    
    # Dati distributore
    if 'distributor_data' not in st.session_state:
        st.session_state['distributor_data'] = {
            'voltage_kv': 20.0,
            'icc_3phase_ka': 12.5,
            'neutral_state': 'compensato',
            'earth_fault_current_a': 50,
            'earth_fault_time_s': 10.0,
            'double_earth_fault_time_s': 0.2,
            'cei_en_50160_compliant': True
        }
    
    # Carichi
    if 'loads' not in st.session_state:
        st.session_state['loads'] = []
    
    # Parametri progetto
    if 'project_params' not in st.session_state:
        st.session_state['project_params'] = {
            'installation_type': 'indoor',
            'service_continuity': 'normale',
            'transformer_redundancy': False,  # ✅ Ripristinata checkbox ridondanza
            'cei_016_required': True
        }
    
    # Risultati calcoli
    if 'calculation_results' not in st.session_state:
        st.session_state['calculation_results'] = None
    
    # Step corrente
    if 'current_step' not in st.session_state:
        st.session_state['current_step'] = 1
    
    # Step completati
    if 'completed_steps' not in st.session_state:
        st.session_state['completed_steps'] = set()

def render_progress_bar():
    """Progress bar con step del progetto"""
    
    step_names = [
        "Dati Distributore",      # Step 1
        "Calcolo Carichi",        # Step 2
        "Trasformatori",          # Step 3
        "Sezionatore di Terra",   # Step 3.5
        "Quadro MT",              # Step 4
        "Coordinamento",          # Step 5
        "Quadro BT"               # Step 6
    ]
    
    # Mapping step number to index (per gestire step 3.5)
    step_mapping = {1: 0, 2: 1, 3: 2, 3.5: 3, 4: 4, 5: 5, 6: 6}
    step_numbers = [1, 2, 3, 3.5, 4, 5, 6]
    
    current_step = st.session_state['current_step']
    completed_steps = st.session_state['completed_steps']
    
    # Progress bar visuale
    progress_value = len(completed_steps) / len(step_names)
    st.progress(progress_value, f"Progresso: {len(completed_steps)}/{len(step_names)} step completati")
    
    # Indicatori step
    cols = st.columns(len(step_names))
    for i, (col, step_name, step_num) in enumerate(zip(cols, step_names, step_numbers)):
        with col:
            if step_num in completed_steps:
                st.success(f"✅ Step {step_num}")
            elif step_num == current_step:
                st.info(f"🔄 Step {step_num}")
            else:
                st.error(f"⭕ Step {step_num}")
            st.caption(step_name)
    
    return current_step