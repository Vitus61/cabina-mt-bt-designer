"""
Defaults - Valori di Default Sistema
Valori predefiniti per tutti i componenti del sistema
Software Cabina MT/BT Professional v2.0
"""

from typing import Dict, Any, List

# ===============================================================================
# DEFAULTS DISTRIBUTORE
# ===============================================================================

DISTRIBUTOR_DEFAULTS = {
    "enel_distribuzione": {
        "voltage_kv": 20.0,
        "icc_3phase_ka": 16.0,
        "neutral_state": "Isolato",
        "earth_fault_current_a": 20,
        "earth_fault_time_s": 1.0,
        "double_earth_fault_time_s": 5.0,
        "frequency_hz": 50,
        "voltage_tolerance_percent": 10.0
    },
    
    "a2a_distribuzione": {
        "voltage_kv": 15.0,
        "icc_3phase_ka": 12.5,
        "neutral_state": "Compensato",
        "earth_fault_current_a": 15,
        "earth_fault_time_s": 1.5,
        "double_earth_fault_time_s": 6.0,
        "frequency_hz": 50,
        "voltage_tolerance_percent": 10.0
    },
    
    "unareti": {
        "voltage_kv": 20.0,
        "icc_3phase_ka": 20.0,
        "neutral_state": "Isolato",
        "earth_fault_current_a": 25,
        "earth_fault_time_s": 0.8,
        "double_earth_fault_time_s": 4.0,
        "frequency_hz": 50,
        "voltage_tolerance_percent": 10.0
    },
    
    "generico": {
        "voltage_kv": 20.0,
        "icc_3phase_ka": 16.0,
        "neutral_state": "Isolato", 
        "earth_fault_current_a": 20,
        "earth_fault_time_s": 1.0,
        "double_earth_fault_time_s": 5.0,
        "frequency_hz": 50,
        "voltage_tolerance_percent": 10.0
    }
}

# ===============================================================================
# DEFAULTS CARICHI TIPICI
# ===============================================================================

LOAD_TEMPLATES = {
    "industriale_generale": [
        {
            "name": "Illuminazione generale",
            "type": "illuminazione",
            "power_kw": 15.0,
            "quantity": 1,
            "ku_factor": 0.8,
            "cos_phi": 0.9,
            "priority": "media"
        },
        {
            "name": "Prese generali",
            "type": "prese", 
            "power_kw": 20.0,
            "quantity": 1,
            "ku_factor": 0.6,
            "cos_phi": 0.8,
            "priority": "bassa"
        },
        {
            "name": "Motori produzione",
            "type": "motori",
            "power_kw": 75.0,
            "quantity": 4,
            "ku_factor": 0.85,
            "cos_phi": 0.87,
            "priority": "alta"
        },
        {
            "name": "Compressore aria",
            "type": "motori",
            "power_kw": 45.0,
            "quantity": 2,
            "ku_factor": 0.9,
            "cos_phi": 0.89,
            "priority": "alta"
        }
    ],
    
    "terziario_uffici": [
        {
            "name": "Illuminazione uffici",
            "type": "illuminazione",
            "power_kw": 25.0,
            "quantity": 1,
            "ku_factor": 0.7,
            "cos_phi": 0.95,
            "priority": "media"
        },
        {
            "name": "Condizionamento",
            "type": "condizionamento",
            "power_kw": 150.0,
            "quantity": 1,
            "ku_factor": 0.8,
            "cos_phi": 0.85,
            "priority": "alta"
        },
        {
            "name": "Server e IT",
            "type": "prese",
            "power_kw": 30.0,
            "quantity": 1,
            "ku_factor": 0.95,
            "cos_phi": 0.8,
            "priority": "essenziale"
        }
    ],
    
    "residenziale_condominio": [
        {
            "name": "Ascensori",
            "type": "motori",
            "power_kw": 15.0,
            "quantity": 2,
            "ku_factor": 0.3,
            "cos_phi": 0.8,
            "priority": "media"
        },
        {
            "name": "Illuminazione comune",
            "type": "illuminazione",
            "power_kw": 8.0,
            "quantity": 1,
            "ku_factor": 0.6,
            "cos_phi": 0.9,
            "priority": "media"
        },
        {
            "name": "Pompe acqua",
            "type": "motori",
            "power_kw": 5.5,
            "quantity": 2,
            "ku_factor": 0.8,
            "cos_phi": 0.85,
            "priority": "alta"
        }
    ]
}

# ===============================================================================
# DEFAULTS TRASFORMATORI
# ===============================================================================

TRANSFORMER_DEFAULTS = {
    "selection_criteria": {
        "min_utilization_percent": 60.0,
        "max_utilization_percent": 90.0,
        "redundancy_threshold_kva": 800,
        "essential_service_redundancy": True
    },
    
    "protection_by_installation": {
        "indoor": {
            "essential": "onan",      # Involucro proprio
            "privileged": "onan",     # Involucro proprio
            "normal": "hi_t_plus"     # Economico con barriere
        },
        "outdoor": {
            "essential": "onan",      # Massima affidabilità
            "privileged": "hi_t_plus", # Economico
            "normal": "hi_t_plus"     # Economico
        }
    }
}

# ===============================================================================
# DEFAULTS PROTEZIONI
# ===============================================================================

PROTECTION_DEFAULTS = {
    "cei_016_mt": {
        "I_1_multiplier": 0.9,      # Sovraccarico (xIn)
        "t_1_seconds": 10.0,        # Tempo sovraccarico
        "I_2_ampere": 250,          # CC moderato
        "t_2_seconds": 0.4,         # Tempo CC moderato
        "I_3_ampere": 600,          # CC elevato (fisso)
        "t_3_seconds": 0.05,        # Tempo CC elevato (fisso)
        "Io_1_ampere": 2.0,         # Terra sensibile
        "to_1_seconds": 0.4,        # Tempo terra sensibile
        "Io_2_factor": 1.4,         # Terra principale (x Icc terra rete)
        "to_2_seconds": 0.15        # Tempo terra principale
    },
    
    "bt_selectivity": {
        "min_ratio": 1.6,           # Rapporto minimo correnti
        "time_step_ms": 150,        # Gradino temporale
        "coordination_margin": 1.2,  # Margine coordinamento
        "i2t_safety_factor": 1.5   # Sicurezza coordinamento energetico
    }
}

# ===============================================================================
# DEFAULTS QUADRI E APPARECCHIATURE
# ===============================================================================

SWITCHGEAR_DEFAULTS = {
    "mt_quadro": {
        "ip_rating": "IP3X",
        "internal_arc_class": "IAC AFL 25kA 1s",
        "insulation_level": "24/50/125",
        "frequency_hz": 50,
        "altitude_m": 1000
    },
    
    "bt_quadro": {
        "ip_rating": "IP54",
        "rated_voltage": 415,
        "frequency_hz": 50,
        "main_switch_required": True,  # CEI 23-51
        "fault_current_duration_s": 1.0
    },
    
    "earth_switch": {
        "type_default": "fixed",    # fisso/mobile
        "ip_rating": "IP3X",
        "key_interlock": True,      # Obbligatorio
        "warning_labels": True,     # Obbligatorio CEI 11-27
        "separate_room_required": True
    }
}

# ===============================================================================
# DEFAULTS IMPIANTO DI TERRA
# ===============================================================================

EARTHING_DEFAULTS = {
    "design_criteria": {
        "max_earth_resistance_ohm": 20.0,       # CEI 11-1
        "max_touch_voltage_v": 50.0,            # CEI 64-8
        "max_step_voltage_v": 125.0,            # CEI 64-8
        "safety_factor": 2.0,
        "electrode_min_length_m": 2.0
    },
    
    "soil_types": {
        "sabbioso": {"resistivity": 250, "description": "Terreno sabbioso"},
        "argilloso": {"resistivity": 150, "description": "Terreno argilloso"},
        "roccioso": {"resistivity": 800, "description": "Terreno roccioso"},
        "paludoso": {"resistivity": 80, "description": "Terreno paludoso"}
    },
    
    "electrode_specs": {
        "diameter_mm": 20,
        "material": "acciaio_zincato",
        "min_depth_m": 0.8,
        "length_standard_m": 2.5
    }
}

# ===============================================================================
# DEFAULTS COSTI (VALORI INDICATIVI 2024)
# ===============================================================================

COST_ESTIMATES = {
    "transformers": {
        "hi_t_plus": {
            "base_cost_per_kva": 85,   # €/kVA
            "installation_factor": 1.15,
            "barrier_cost_eur": 4500
        },
        "onan": {
            "base_cost_per_kva": 120,  # €/kVA
            "installation_factor": 1.10,
            "barrier_cost_eur": 0
        }
    },
    
    "mt_switchgear": {
        "unisec_base_eur": 25000,
        "per_feeder_eur": 3500,
        "installation_factor": 1.20
    },
    
    "bt_switchgear": {
        "main_switch_per_amp": 1.2,    # €/A
        "emax2_base_eur": 15000,
        "tmax_base_eur": 2500,
        "installation_factor": 1.12
    },
    
    "earthing": {
        "electrode_eur": 150,
        "conductor_per_meter": 8,
        "installation_per_electrode": 200
    }
}

# ===============================================================================
# UTILITÀ PER ACCESSO AI DEFAULT
# ===============================================================================

def get_distributor_default(distributor_name: str = "generico") -> Dict[str, Any]:
    """Ottiene default per un distributore specifico"""
    return DISTRIBUTOR_DEFAULTS.get(distributor_name.lower(), DISTRIBUTOR_DEFAULTS["generico"])

def get_load_template(template_name: str) -> List[Dict[str, Any]]:
    """Ottiene template carichi per tipologia"""
    return LOAD_TEMPLATES.get(template_name.lower(), LOAD_TEMPLATES["industriale_generale"])

def get_protection_default(protection_type: str) -> Dict[str, Any]:
    """Ottiene default per un tipo di protezione"""
    return PROTECTION_DEFAULTS.get(protection_type.lower(), PROTECTION_DEFAULTS["cei_016_mt"])

def get_switchgear_default(switchgear_type: str) -> Dict[str, Any]:
    """Ottiene default per un tipo di quadro"""
    return SWITCHGEAR_DEFAULTS.get(switchgear_type.lower(), SWITCHGEAR_DEFAULTS["bt_quadro"])

def get_cost_estimate_base(component_type: str) -> Dict[str, Any]:
    """Ottiene stima costi base per componente"""
    return COST_ESTIMATES.get(component_type.lower(), {})

# ===============================================================================
# VALIDATORI DEFAULT
# ===============================================================================

def validate_distributor_data(data: Dict[str, Any]) -> tuple[bool, List[str]]:
    """Valida dati distributore contro criteri standard"""
    errors = []
    
    # Controlli base
    if data.get('voltage_kv', 0) < 6 or data.get('voltage_kv', 0) > 35:
        errors.append("Tensione MT fuori range standard (6-35 kV)")
    
    if data.get('icc_3phase_ka', 0) < 8 or data.get('icc_3phase_ka', 0) > 50:
        errors.append("Corrente di cortocircuito fuori range tipico (8-50 kA)")
    
    if data.get('earth_fault_current_a', 0) > 100:
        errors.append("Corrente di guasto terra molto elevata (>100A)")
    
    return len(errors) == 0, errors

def validate_load_data(load: Dict[str, Any]) -> tuple[bool, List[str]]:
    """Valida dati singolo carico"""
    errors = []
    
    if load.get('power_kw', 0) <= 0:
        errors.append("Potenza deve essere positiva")
    
    cos_phi = load.get('cos_phi', 1.0)
    if cos_phi < 0.6 or cos_phi > 1.0:
        errors.append("Cos φ fuori range realistico (0.6-1.0)")
    
    ku = load.get('ku_factor', 1.0)
    if ku < 0.1 or ku > 1.0:
        errors.append("Fattore Ku fuori range (0.1-1.0)")
    
    return len(errors) == 0, errors

if __name__ == "__main__":
    # Test dei default
    print("🧪 Test Default Values:")
    print(f"Distributore ENEL: {get_distributor_default('enel_distribuzione')['voltage_kv']} kV")
    print(f"Template industriale: {len(get_load_template('industriale_generale'))} carichi")
    print(f"Protezioni CEI 0-16: I2 = {get_protection_default('cei_016_mt')['I_2_ampere']} A")
