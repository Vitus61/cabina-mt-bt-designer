"""Configurazioni globali dell'applicazione"""

# Configurazioni Streamlit
APP_CONFIG = {
    "page_title": "Cabina MT/BT Professional v2.0",
    "page_icon": "⚡",
    "layout": "wide",
    "initial_sidebar_state": "expanded"
}

# Versioni
VERSION = "2.0.0"
BUILD_DATE = "2024-12-20"

# Configurazioni UI
UI_THEMES = {
    "modern_blue": {
        "primary_color": "#1f77b4",
        "background_color": "#ffffff",
        "secondary_color": "#ff7f0e",
        "text_color": "#262730"
    },
    "dark_mode": {
        "primary_color": "#00d4aa",
        "background_color": "#0e1117", 
        "secondary_color": "#ff6b6b",
        "text_color": "#fafafa"
    }
}

# Thresholds di validazione
VALIDATION_LIMITS = {
    "earth_resistance_max_ohm": 20.0,
    "selectivity_min_percent": 85.0,
    "transformer_utilization_min": 60.0,
    "transformer_utilization_max": 90.0,
    "voltage_tolerance_percent": 10.0
}

# Configurazioni calcolo
CALCULATION_CONFIG = {
    "safety_factors": {
        "general": 1.25,
        "earth_fault": 1.4,
        "short_circuit": 1.1
    },
    "standard_values": {
        "bt_voltage": 415,  # V
        "frequency": 50,    # Hz
        "cos_phi_default": 0.85
    }
}