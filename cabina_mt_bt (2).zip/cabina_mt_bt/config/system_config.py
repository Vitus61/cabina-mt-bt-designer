"""
Sistema di Configurazione Centralizzato - Elimina import condizionali
Software Cabina MT/BT Professional v2.0
"""

import sys
import os
import importlib
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
import logging

# Configurazione logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ModuleAvailabilityManager:
    """
    Gestore centralizzato per la disponibilità dei moduli opzionali.
    Elimina la necessità di try/except sparsi nel codice.
    """
    
    def __init__(self):
        self._modules = {}
        self._availability_cache = {}
        self._system_paths = []
        
        # Inizializza i percorsi di sistema
        self._initialize_system_paths()
        
        # Verifica disponibilità moduli
        self._check_all_modules()
    
    def _initialize_system_paths(self):
        """Inizializza percorsi di sistema per i moduli"""
        current_dir = Path(__file__).parent.parent
        
        # Percorsi possibili per i moduli
        possible_paths = [
            current_dir / "abb_database",
            current_dir / "mt_equipment", 
            current_dir / "bt_equipment",
            current_dir / "earthing_system",
            Path("./abb_database"),
            Path("../abb_database"),
            Path("/projects/Desktop/cabina_mt_bt/abb_database")
        ]
        
        # Aggiunge percorsi esistenti al Python path
        for path in possible_paths:
            if path.exists():
                path_str = str(path.absolute())
                if path_str not in sys.path:
                    sys.path.insert(0, path_str)
                    self._system_paths.append(path_str)
                    logger.info(f"✅ Percorso aggiunto: {path_str}")
    
    def _check_all_modules(self):
        """Verifica disponibilità di tutti i moduli opzionali"""
        
        # Configurazione moduli da verificare
        modules_config = {
            'abb_emax2': {
                'import_path': 'abb_database.abb_python_interface',
                'classes': ['ABBEmax2Interface', 'ABBBreakerSpecs', 'ProtectionSettings'],
                'test_method': '_test_abb_system'
            },
            'earth_switch': {
                'import_path': 'mt_equipment.earth_switch',
                'classes': ['EarthSwitchDesigner', 'EarthSwitchType'],
                'test_method': '_test_earth_switch'
            },
            'bt_equipment': {
                'import_path': 'bt_equipment',
                'classes': ['get_artu_for_unisec', 'bt_breaker_db', 'BTBreakerSpec'],
                'test_method': '_test_bt_equipment'
            },
            'unisec': {
                'import_path': 'mt_equipment.unisec',
                'classes': ['unisec_technical_data', 'verify_switchgear_compatibility'],
                'test_method': '_test_unisec'
            },
            'earthing_calculator': {
                'import_path': 'earthing_system.earthing_calculator',
                'classes': ['EarthingCalculator'],
                'test_method': '_test_earthing'
            }
        }
        
        # Verifica ogni modulo
        for module_name, config in modules_config.items():
            available, module_obj, message = self._check_module(config)
            
            self._availability_cache[module_name] = {
                'available': available,
                'module': module_obj,
                'message': message,
                'config': config
            }
            
            if available:
                logger.info(f"✅ {module_name}: {message}")
            else:
                logger.warning(f"⚠️ {module_name}: {message}")
    
    def _check_module(self, config: Dict) -> Tuple[bool, Optional[Any], str]:
        """Verifica un singolo modulo"""
        try:
            # Importa il modulo
            module = importlib.import_module(config['import_path'])
            
            # Verifica che le classi/funzioni esistano
            missing_items = []
            for item_name in config['classes']:
                if not hasattr(module, item_name):
                    missing_items.append(item_name)
            
            if missing_items:
                return False, None, f"Classi mancanti: {', '.join(missing_items)}"
            
            # Test specifico del modulo se disponibile
            if hasattr(self, config['test_method']):
                test_method = getattr(self, config['test_method'])
                test_passed, test_message = test_method(module)
                if not test_passed:
                    return False, None, f"Test fallito: {test_message}"
            
            return True, module, "Modulo caricato e testato con successo"
            
        except ImportError as e:
            return False, None, f"Import Error: {str(e)}"
        except Exception as e:
            return False, None, f"Errore generico: {str(e)}"
    
    def _test_abb_system(self, module) -> Tuple[bool, str]:
        """Test specifico per sistema ABB"""
        try:
            # Test inizializzazione interfaccia
            abb_interface = module.ABBEmax2Interface()
            
            # Test metodi base
            if hasattr(abb_interface, 'get_available_breakers'):
                breakers = abb_interface.get_available_breakers()
                if not breakers:
                    return False, "Nessun interruttore disponibile nel database"
            
            return True, f"Sistema ABB operativo"
            
        except Exception as e:
            return False, f"Test ABB fallito: {str(e)}"
    
    def _test_earth_switch(self, module) -> Tuple[bool, str]:
        """Test specifico per sezionatore di terra"""
        try:
            designer = module.EarthSwitchDesigner()
            # Test base: verifica che possa fare una progettazione semplice
            return True, "Earth Switch Designer operativo"
        except Exception as e:
            return False, f"Test Earth Switch fallito: {str(e)}"
    
    def _test_bt_equipment(self, module) -> Tuple[bool, str]:
        """Test specifico per BT equipment"""
        try:
            # Test database interruttori BT
            if hasattr(module, 'bt_breaker_db'):
                return True, "BT Equipment operativo"
            return False, "Database BT non trovato"
        except Exception as e:
            return False, f"Test BT Equipment fallito: {str(e)}"
    
    def _test_unisec(self, module) -> Tuple[bool, str]:
        """Test specifico per UniSec"""
        try:
            if hasattr(module, 'unisec_technical_data'):
                return True, "UniSec operativo"
            return False, "Dati tecnici UniSec non trovati"
        except Exception as e:
            return False, f"Test UniSec fallito: {str(e)}"
    
    def _test_earthing(self, module) -> Tuple[bool, str]:
        """Test specifico per calcolatore impianto di terra"""
        try:
            calculator = module.EarthingCalculator()
            return True, "Earthing Calculator operativo"
        except Exception as e:
            return False, f"Test Earthing fallito: {str(e)}"
    
    def is_available(self, module_name: str) -> bool:
        """Verifica se un modulo è disponibile"""
        return self._availability_cache.get(module_name, {}).get('available', False)
    
    def get_module(self, module_name: str) -> Optional[Any]:
        """Ottiene il modulo se disponibile"""
        if self.is_available(module_name):
            return self._availability_cache[module_name]['module']
        return None
    
    def get_status_message(self, module_name: str) -> str:
        """Ottiene il messaggio di status per un modulo"""
        return self._availability_cache.get(module_name, {}).get('message', 'Modulo non configurato')
    
    def get_all_status(self) -> Dict[str, Dict]:
        """Ottiene status di tutti i moduli"""
        return {
            name: {
                'available': info['available'],
                'message': info['message']
            }
            for name, info in self._availability_cache.items()
        }
    
    def get_availability_report(self) -> str:
        """Genera report di disponibilità moduli"""
        lines = ["🔍 REPORT DISPONIBILITÀ MODULI SISTEMA:\n"]
        
        available_count = 0
        total_count = len(self._availability_cache)
        
        for name, info in self._availability_cache.items():
            status_icon = "✅" if info['available'] else "❌"
            lines.append(f"{status_icon} {name.upper()}: {info['message']}")
            if info['available']:
                available_count += 1
        
        lines.append(f"\n📊 RIEPILOGO: {available_count}/{total_count} moduli disponibili")
        
        if available_count == total_count:
            lines.append("🚀 SISTEMA COMPLETO - Tutte le funzionalità disponibili")
        elif available_count >= total_count * 0.7:
            lines.append("⚡ SISTEMA FUNZIONALE - Funzionalità principali disponibili")
        else:
            lines.append("⚠️ SISTEMA LIMITATO - Alcune funzionalità non disponibili")
        
        return "\n".join(lines)

# ===============================================================================
# SINGLETON INSTANCE - USO GLOBALE
# ===============================================================================

# Istanza singleton del gestore moduli
_module_manager = None

def get_available_modules():
    """
    Ottiene l'istanza singleton del gestore moduli.
    Elimina la necessità di import condizionali nel codice.
    
    Uso:
        modules = get_available_modules()
        if modules.is_available('abb_emax2'):
            abb_interface = modules.get_module('abb_emax2').ABBEmax2Interface()
    """
    global _module_manager
    if _module_manager is None:
        _module_manager = ModuleAvailabilityManager()
    return _module_manager

def reinitialize_modules():
    """Reinizializza il sistema di gestione moduli (per testing/debug)"""
    global _module_manager
    _module_manager = None
    return get_available_modules()

# ===============================================================================
# CONFIGURAZIONI DEFAULT
# ===============================================================================

DEFAULT_VALUES = {
    "distributor_data": {
        "voltage_kv": 20.0,
        "icc_3phase_ka": 16.0,
        "neutral_state": "Isolato",
        "earth_fault_current_a": 20,
        "earth_fault_time_s": 1.0,
        "double_earth_fault_time_s": 5.0
    },
    
    "project_params": {
        "service_continuity": "normale",
        "installation_type": "indoor", 
        "transformer_redundancy": False,
        "design_approach": "standard"
    },
    
    "validation_thresholds": {
        "min_selectivity_percentage": 85.0,
        "max_earth_resistance": 20.0,
        "min_transformer_utilization": 60.0,
        "max_transformer_utilization": 90.0
    }
}

def get_default_value(key_path: str, default=None):
    """
    Ottiene un valore di default navigando la struttura con notazione punto
    
    Esempi:
        get_default_value("distributor_data.voltage_kv")  # 20.0
        get_default_value("validation_thresholds.min_selectivity_percentage")  # 85.0
    """
    keys = key_path.split('.')
    value = DEFAULT_VALUES
    
    try:
        for key in keys:
            value = value[key]
        return value
    except (KeyError, TypeError):
        return default

# ===============================================================================
# API COMPATIBILITÀ CON CODICE ESISTENTE  
# ===============================================================================

def verify_system_status() -> Dict[str, Any]:
    """
    API di compatibilità per il codice esistente.
    Verifica stato del sistema e restituisce informazioni.
    """
    modules = get_available_modules()
    status = modules.get_all_status()
    
    return {
        'abb_emax2_available': status.get('abb_emax2', {}).get('available', False),
        'earth_switch_available': status.get('earth_switch', {}).get('available', False),
        'bt_equipment_available': status.get('bt_equipment', {}).get('available', False),
        'unisec_available': status.get('unisec', {}).get('available', False),
        'earthing_available': status.get('earthing_calculator', {}).get('available', False),
        'system_report': modules.get_availability_report()
    }

# ===============================================================================
# HELPER PER DEBUG
# ===============================================================================

def print_system_status():
    """Stampa status sistema (per debug)"""
    modules = get_available_modules()
    print(modules.get_availability_report())

if __name__ == "__main__":
    # Test del sistema
    print_system_status()
