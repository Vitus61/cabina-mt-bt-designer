"""
Config Package - Configurazioni Applicazione
Impostazioni e configurazioni sistema centralizzate
Software Cabina MT/BT Professional v2.0
"""

# Import delle configurazioni
from .settings import (
    APP_CONFIG, 
    VERSION, 
    BUILD_DATE,
    UI_THEMES,
    VALIDATION_LIMITS,
    CALCULATION_CONFIG
)

from .system_config import (
    get_available_modules,
    verify_system_status,
    get_default_value,
    DEFAULT_VALUES,
    reinitialize_modules,
    print_system_status
)

# API pubblica del package
__all__ = [
    # Configurazioni base
    'APP_CONFIG',
    'VERSION', 
    'BUILD_DATE',
    'UI_THEMES',
    'VALIDATION_LIMITS', 
    'CALCULATION_CONFIG',
    
    # Sistema gestione moduli
    'get_available_modules',
    'verify_system_status',
    'get_default_value',
    'DEFAULT_VALUES',
    'reinitialize_modules',
    'print_system_status'
]

__version__ = "2.0.0"
__author__ = "Software Cabina MT/BT Professional"
