"""
cei_016_parameters.py
TODO: Implementare contenuto
"""