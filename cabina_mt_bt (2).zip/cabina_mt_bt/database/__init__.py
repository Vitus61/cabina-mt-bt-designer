"""
Database Package - Database Prodotti
Database trasformatori e apparecchiature
Software Cabina MT/BT Professional v2.0
"""

from .products import ProductDatabase

__all__ = [
    'ProductDatabase'
]

__version__ = "1.0.0"
__author__ = "Software Cabina MT/BT Professional"
