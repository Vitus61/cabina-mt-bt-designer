"""
selectivity_rules.py
TODO: Implementare contenuto
"""