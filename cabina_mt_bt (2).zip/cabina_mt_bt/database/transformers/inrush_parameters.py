"""
database/transformers/inrush_parameters.py
SINGLE SOURCE OF TRUTH per parametri ki e Ti
Sostituisce tutti i parametri sparsi nei vari file
"""

from dataclasses import dataclass
from typing import Dict, Optional

@dataclass
class InrushParameters:
    """Parametri corrente di inserzione CEI 0-16"""
    ki: float  # Coefficiente inserzione
    Ti: float  # Durata inserzione (secondi)
    source: str = "CEI 0-16"  # Fonte del dato
    notes: str = ""
    transformer_type: str = "standard"  # standard, premium, economy

class InrushDatabase:
    """Database unificato parametri ki/Ti per trasformatori"""
    
    def __init__(self):
        self._parameters = self._load_inrush_parameters()
    
    def _load_inrush_parameters(self) -> Dict[int, InrushParameters]:
        """
        🎯 TABELLA MASTER ki/Ti - SINGLE SOURCE OF TRUTH
        Sostituisce TUTTE le tabelle sparse nei file:
        - step_04_mt_design.py
        - step_05_protection.py  
        - calculations.py
        - transformer_sizing.py
        - equipment_selection.py
        """
        return {
            # Piccole potenze
            100: InrushParameters(
                ki=13.7, Ti=0.45, 
                source="CEI 0-16 Tab A.1", 
                notes="Piccola potenza, alta corrente inserzione",
                transformer_type="standard"
            ),
            160: InrushParameters(
                ki=11.1, Ti=0.65,
                source="CEI 0-16 Tab A.1",
                notes="Potenza industriale minima",
                transformer_type="standard"
            ),
            250: InrushParameters(
                ki=11.3, Ti=0.65,
                source="CEI 0-16 Tab A.1", 
                notes="Potenza commerciale standard",
                transformer_type="standard"
            ),
            315: InrushParameters(
                ki=11.0, Ti=0.65,
                source="CEI 0-16 Tab A.1",
                notes="Potenza intermedia",
                transformer_type="standard"
            ),
            400: InrushParameters(
                ki=10.5, Ti=0.65,
                source="CEI 0-16 Tab A.1",
                notes="Media potenza industriale", 
                transformer_type="standard"
            ),
            
            # 🎯 VALORE CRITICO - UNIFICATO
            500: InrushParameters(
                ki=10.0, Ti=0.70,
                source="CEI 0-16 Tab A.1",
                notes="Media-alta potenza, VALORE UNIFICATO post-correzione",
                transformer_type="standard"
            ),
            
            # Potenze elevate
            630: InrushParameters(
                ki=10.1, Ti=0.70,
                source="CEI 0-16 Tab A.1",
                notes="Alta potenza industriale",
                transformer_type="standard"
            ),
            800: InrushParameters(
                ki=9.8, Ti=0.70,
                source="CEI 0-16 Tab A.1",
                notes="Alta potenza",
                transformer_type="standard"  
            ),
            1000: InrushParameters(
                ki=9.0, Ti=0.75,
                source="CEI 0-16 Tab A.1",
                notes="Molto alta potenza",
                transformer_type="standard"
            ),
            1250: InrushParameters(
                ki=8.9, Ti=0.75,
                source="CEI 0-16 Tab A.1",
                notes="Potenza elevata industriale",
                transformer_type="standard"
            ),
            1600: InrushParameters(
                ki=8.8, Ti=0.75,
                source="CEI 0-16 Tab A.1", 
                notes="Extra alta potenza",
                transformer_type="standard"
            ),
            2000: InrushParameters(
                ki=8.1, Ti=0.80,
                source="CEI 0-16 Tab A.1",
                notes="Massima potenza industriale",
                transformer_type="standard"
            ),
            2500: InrushParameters(
                ki=8.0, Ti=0.85,
                source="CEI 0-16 Tab A.1",
                notes="Potenza massima distribuzione",
                transformer_type="standard"
            )
        }
    
    def get_parameters(self, power_kva: int) -> InrushParameters:
        """
        🎯 API PRINCIPALE - Ottieni parametri ki/Ti
        
        Args:
            power_kva: Potenza trasformatore in kVA
            
        Returns:
            InrushParameters con ki, Ti e metadati
        """
        if power_kva in self._parameters:
            return self._parameters[power_kva]
        
        # Interpolazione per potenze non standard
        return self._interpolate_parameters(power_kva)
    
    def get_ki_ti(self, power_kva: int) -> tuple[float, float]:
        """
        🎯 API SEMPLIFICATA - Solo ki e Ti
        Per compatibilità con codice esistente
        
        Returns:
            (ki, Ti) tuple
        """
        params = self.get_parameters(power_kva)
        return params.ki, params.Ti
    
    def calculate_inrush_current(self, power_kva: int, voltage_kv: float = 20.0) -> Dict:
        """
        🎯 CALCOLO COMPLETO corrente inserzione
        Logica unificata per CEI 0-16
        
        Args:
            power_kva: Potenza trasformatore
            voltage_kv: Tensione primaria
            
        Returns:
            Dict con tutti i parametri calcolati
        """
        params = self.get_parameters(power_kva)
        
        # Corrente nominale primaria
        I_r = (power_kva * 1000) / (1.732 * voltage_kv * 1000)
        
        # Corrente di inserzione
        I_oi = params.ki * I_r
        
        # Limite protezione CEI 0-16
        I_protection_min = 0.7 * I_oi
        
        return {
            'ki': params.ki,
            'Ti': params.Ti,
            'I_nominal_primary': I_r,
            'I_inrush': I_oi,
            'I_protection_min_cei016': I_protection_min,
            'transformer_power': power_kva,
            'voltage_primary': voltage_kv,
            'source': params.source,
            'notes': params.notes,
            'exact_match': power_kva in self._parameters
        }
    
    def _interpolate_parameters(self, power_kva: int) -> InrushParameters:
        """Interpola parametri per potenze non standard"""
        powers = sorted(self._parameters.keys())
        
        # Trova potenze adiacenti
        lower_power = max([p for p in powers if p <= power_kva], default=powers[0])
        upper_power = min([p for p in powers if p >= power_kva], default=powers[-1])
        
        if lower_power == upper_power:
            return self._parameters[lower_power]
        
        # Interpolazione lineare
        factor = (power_kva - lower_power) / (upper_power - lower_power)
        
        lower_params = self._parameters[lower_power]
        upper_params = self._parameters[upper_power]
        
        ki_interpolated = lower_params.ki + factor * (upper_params.ki - lower_params.ki)
        Ti_interpolated = lower_params.Ti + factor * (upper_params.Ti - lower_params.Ti)
        
        return InrushParameters(
            ki=round(ki_interpolated, 1),
            Ti=round(Ti_interpolated, 2),
            source="Interpolato",
            notes=f"Interpolato tra {lower_power} e {upper_power} kVA",
            transformer_type="interpolated"
        )
    
    def get_available_powers(self) -> list[int]:
        """Ottieni lista potenze disponibili"""
        return sorted(self._parameters.keys())
    
    def validate_power(self, power_kva: int) -> bool:
        """Verifica se potenza è supportata (diretta o interpolata)"""
        if power_kva <= 0:
            return False
        
        powers = self.get_available_powers()
        return powers[0] <= power_kva <= powers[-1]

# ========================================
# ISTANZA GLOBALE - SINGLE SOURCE OF TRUTH  
# ========================================

inrush_db = InrushDatabase()

# ========================================
# FUNZIONI DI CONVENIENZA
# ========================================

def get_inrush_parameters(power_kva: int) -> InrushParameters:
    """🎯 FUNZIONE PRINCIPALE - Ottieni parametri completi"""
    return inrush_db.get_parameters(power_kva)

def get_ki_ti(power_kva: int) -> tuple[float, float]:
    """🎯 FUNZIONE SEMPLICE - Solo ki e Ti"""
    return inrush_db.get_ki_ti(power_kva)

def calculate_inrush_current(power_kva: int, voltage_kv: float = 20.0) -> Dict:
    """🎯 FUNZIONE CALCOLO - Corrente inserzione completa"""
    return inrush_db.calculate_inrush_current(power_kva, voltage_kv)

# ========================================
# MIGRAZIONE - ESEMPI DI USO
# ========================================

def migration_examples():
    """Esempi di come migrare il codice esistente"""
    
    print("🔄 ESEMPI MIGRAZIONE DA CODICE VECCHIO A NUOVO")
    print("=" * 50)
    
    # ❌ VECCHIO CODICE (da eliminare):
    # TRANSFORMER_PARAMS = {
    #     400: {'ki': 10.5, 'Ti': 0.65},
    #     500: {'ki': 10.0, 'Ti': 0.70},
    # }
    # ki = TRANSFORMER_PARAMS[power]['ki']
    
    # ✅ NUOVO CODICE:
    power_kva = 500
    
    # Metodo 1: Solo ki e Ti
    ki, Ti = get_ki_ti(power_kva)
    print(f"Metodo 1 - ki: {ki}, Ti: {Ti}")
    
    # Metodo 2: Parametri completi
    params = get_inrush_parameters(power_kva)
    print(f"Metodo 2 - ki: {params.ki}, Ti: {params.Ti}, Source: {params.source}")
    
    # Metodo 3: Calcolo completo
    result = calculate_inrush_current(power_kva, voltage_kv=20.0)
    print(f"Metodo 3 - I_oi: {result['I_inrush']:.0f}A, I_min: {result['I_protection_min_cei016']:.0f}A")

if __name__ == "__main__":
    migration_examples()