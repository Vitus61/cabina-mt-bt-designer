"""
Database Sezionatori di Terra ABB
Modelli, caratteristiche tecniche e logica di selezione automatica
"""

def get_earth_switch_database():
    """
    Database completo sezionatori di terra ABB serie OETL-NF00
    
    Returns:
        dict: Database con caratteristiche tecniche complete
    """
    return {
        400: {
            "model": "OETL-NF00 400A",
            "series": "OETL-NF00",
            "full_code_3p": "1SCA022714R8520",
            "full_code_4p": "1SCA022714R8521", 
            "voltage_kv": 24,
            "current_a": 400,
            "breaking_capacity_ka": 40,
            "impulse_voltage_kv": 125,
            "power_frequency_voltage_kv": 50,
            "short_time_current_ka": 40,
            "peak_current_ka": 100,
            "price_eur_3p": 3200,
            "price_eur_4p": 3800,
            "installation_types": ["Indoor", "Outdoor"],
            "protection_degree": "IP2X",
            "mechanical_endurance": 1000,
            "operating_time_manual_s": 3,
            "operating_time_motorized_s": 10,
            "description": "Sezionatore di terra standard per installazioni MT",
            "weight_kg": 15,
            "dimensions_mm": {"height": 850, "width": 420, "depth": 280}
        },
        630: {
            "model": "OETL-NF00 630A",
            "series": "OETL-NF00", 
            "full_code_3p": "1SCA022714R8530",
            "full_code_4p": "1SCA022714R8531",
            "voltage_kv": 24,
            "current_a": 630,
            "breaking_capacity_ka": 50,
            "impulse_voltage_kv": 125,
            "power_frequency_voltage_kv": 50,
            "short_time_current_ka": 50,
            "peak_current_ka": 125,
            "price_eur_3p": 4100,
            "price_eur_4p": 4800,
            "installation_types": ["Indoor", "Outdoor"],
            "protection_degree": "IP2X",
            "mechanical_endurance": 1000,
            "operating_time_manual_s": 3,
            "operating_time_motorized_s": 10,
            "description": "Sezionatore di terra potenziato per carichi elevati",
            "weight_kg": 18,
            "dimensions_mm": {"height": 850, "width": 420, "depth": 280}
        },
        800: {
            "model": "OETL-NF00 800A",
            "series": "OETL-NF00",
            "full_code_3p": "1SCA022714R8540",
            "full_code_4p": "1SCA022714R8541",
            "voltage_kv": 24,
            "current_a": 800,
            "breaking_capacity_ka": 63,
            "impulse_voltage_kv": 125,
            "power_frequency_voltage_kv": 50,
            "short_time_current_ka": 63,
            "peak_current_ka": 160,
            "price_eur_3p": 5300,
            "price_eur_4p": 6100,
            "installation_types": ["Indoor", "Outdoor"],
            "protection_degree": "IP2X",
            "mechanical_endurance": 1000,
            "operating_time_manual_s": 3,
            "operating_time_motorized_s": 10,
            "description": "Sezionatore di terra per installazioni industriali",
            "weight_kg": 22,
            "dimensions_mm": {"height": 850, "width": 420, "depth": 280}
        },
        1000: {
            "model": "OETL-NF00 1000A",
            "series": "OETL-NF00",
            "full_code_3p": "1SCA022714R8550", 
            "full_code_4p": "1SCA022714R8551",
            "voltage_kv": 24,
            "current_a": 1000,
            "breaking_capacity_ka": 80,
            "impulse_voltage_kv": 125,
            "power_frequency_voltage_kv": 50,
            "short_time_current_ka": 80,
            "peak_current_ka": 200,
            "price_eur_3p": 6800,
            "price_eur_4p": 7800,
            "installation_types": ["Indoor", "Outdoor"],
            "protection_degree": "IP2X",
            "mechanical_endurance": 1000,
            "operating_time_manual_s": 3,
            "operating_time_motorized_s": 10,
            "description": "Sezionatore di terra per grandi installazioni",
            "weight_kg": 28,
            "dimensions_mm": {"height": 850, "width": 420, "depth": 280}
        }
    }


def get_pole_configuration(neutral_regime=None, earth_fault_current_a=None):
    """
    Determina configurazione poli necessaria (3P o 4P)
    
    Args:
        neutral_regime (str): Regime del neutro ('isolato', 'terra', 'impedenza')
        earth_fault_current_a (float): Corrente di guasto a terra in Ampere
        
    Returns:
        dict: Configurazione poli con spiegazione
    """
    
    # Logica principale: corrente di guasto a terra
    if earth_fault_current_a is not None:
        if earth_fault_current_a <= 50:  # Neutro isolato (tipico ENEL)
            pole_config = "3P"
            reason = "Neutro isolato (Ig ≤ 50A) - sezionatore 3 poli sufficiente"
            explanation = "Il neutro non è distribuito, quindi non necessita di sezionamento"
        else:  # Neutro a terra o tramite impedenza
            pole_config = "4P"
            reason = "Neutro a terra (Ig > 50A) - sezionatore 4 poli necessario"
            explanation = "Il neutro è distribuito e deve essere sezionabile per sicurezza"
    
    # Logica secondaria: regime neutro dichiarato
    elif neutral_regime is not None:
        if neutral_regime.lower() in ['isolato', 'isolated']:
            pole_config = "3P"
            reason = "Neutro isolato dichiarato - sezionatore 3 poli"
            explanation = "Sistema con neutro isolato standard italiano"
        else:  # terra, impedenza, resistance
            pole_config = "4P" 
            reason = "Neutro collegato - sezionatore 4 poli necessario"
            explanation = "Sistema con neutro accessibile richiede sezionamento"
    
    # Default per reti italiane
    else:
        pole_config = "3P"
        reason = "Default per reti italiane - neutro isolato presunto"
        explanation = "La maggior parte delle reti MT italiane ha neutro isolato"
    
    return {
        "poles": pole_config,
        "reason": reason,
        "explanation": explanation,
        "safety_note": "Verificare sempre i parametri di rete con il distributore"
    }


def select_optimal_earth_switch(current_required_a, voltage_kv, icc_ka=None, 
                               neutral_regime=None, earth_fault_current_a=None, 
                               safety_margin=1.1):
    """
    Selezione automatica sezionatore di terra ottimale
    
    Args:
        current_required_a (float): Corrente nominale richiesta in A
        voltage_kv (float): Tensione di rete in kV
        icc_ka (float): Corrente di cortocircuito in kA (opzionale)
        neutral_regime (str): Regime del neutro
        earth_fault_current_a (float): Corrente di guasto a terra
        safety_margin (float): Margine di sicurezza (default 1.1 = 10%)
        
    Returns:
        dict: Sezionatore selezionato con caratteristiche complete
    """
    
    database = get_earth_switch_database()
    available_ratings = sorted(database.keys())
    
    # Calcolo corrente minima necessaria con margine
    min_current_needed = current_required_a * safety_margin
    
    # Selezione taglia appropriata
    selected_rating = None
    for rating in available_ratings:
        if rating >= min_current_needed:
            selected_rating = rating
            break
    
    # Se nessuna taglia è sufficiente, prendi la più grande
    if selected_rating is None:
        selected_rating = max(available_ratings)
    
    # Recupera dati sezionatore selezionato
    selected_switch = database[selected_rating].copy()
    
    # Determina configurazione poli
    pole_config = get_pole_configuration(neutral_regime, earth_fault_current_a)
    
    # Aggiorna informazioni con configurazione poli
    selected_switch.update({
        "pole_configuration": pole_config["poles"],
        "pole_reason": pole_config["reason"],
        "pole_explanation": pole_config["explanation"],
        "full_code": selected_switch[f"full_code_{pole_config['poles'].lower()}"],
        "price_eur": selected_switch[f"price_eur_{pole_config['poles'].lower()}"],
        "model_complete": f"{selected_switch['model']} {pole_config['poles']}",
        "selection_criteria": {
            "current_required": current_required_a,
            "current_with_margin": min_current_needed,
            "current_selected": selected_switch["current_a"],
            "margin_applied": safety_margin,
            "voltage_compatibility": voltage_kv <= selected_switch["voltage_kv"],
            "icc_compatibility": icc_ka <= selected_switch["breaking_capacity_ka"] if icc_ka else True
        }
    })
    
    return selected_switch


def calculate_installation_costs(selected_switch, switch_type="Manuale", installation="Indoor"):
    """
    Calcola costi completi di installazione
    
    Args:
        selected_switch (dict): Sezionatore selezionato
        switch_type (str): "Manuale" o "Motorizzato"
        installation (str): "Indoor" o "Outdoor"
        
    Returns:
        dict: Breakdown completo dei costi
    """
    
    base_price = selected_switch["price_eur"]
    
    # Costi accessori
    accessories_cost = 0
    if switch_type == "Motorizzato":
        accessories_cost += 800  # Motore + controlli + cablaggio
    
    if installation == "Outdoor":
        accessories_cost += 400  # Protezioni UV + guarnizioni rinforzate
    
    # Costi installazione (% del costo apparecchio)
    installation_cost = base_price * 0.25
    
    # Costi materiali ausiliari
    if installation == "Indoor":
        cable_cost = 300  # Cavi MT + supporti
        support_cost = 200  # Mensole/pannelli
    else:  # Outdoor
        cable_cost = 500  # Cavi MT rinforzati + protezioni
        support_cost = 400  # Fondazioni + strutture
    
    # Totale
    total_cost = base_price + accessories_cost + installation_cost + cable_cost + support_cost
    
    return {
        "sezionatore_base": base_price,
        "accessori_optional": accessories_cost,
        "installazione_manodopera": installation_cost,
        "cablaggio": cable_cost,
        "supporti_meccanici": support_cost,
        "totale_progetto": total_cost,
        "breakdown_percentages": {
            "apparecchio": (base_price / total_cost) * 100,
            "accessori": (accessories_cost / total_cost) * 100,
            "installazione": (installation_cost / total_cost) * 100,
            "materiali": ((cable_cost + support_cost) / total_cost) * 100
        }
    }


def get_technical_specifications(selected_switch, switch_type="Manuale", installation="Indoor"):
    """
    Genera specifiche tecniche complete formattate
    
    Args:
        selected_switch (dict): Sezionatore selezionato  
        switch_type (str): Tipo comando
        installation (str): Tipo installazione
        
    Returns:
        dict: Specifiche tecniche organizzate per sezioni
    """
    
    # Temperature di esercizio in base all'installazione
    temp_range = "-25°C / +40°C" if installation == "Indoor" else "-40°C / +40°C"
    
    # Caratteristiche comando
    if switch_type == "Manuale":
        command_specs = {
            "tipo_comando": "Manuale a leva",
            "forza_manovra": "< 200 N",
            "tempo_manovra": f"{selected_switch['operating_time_manual_s']} secondi",
            "accessori": "Lucchetto di sicurezza incluso",
            "manovre_meccaniche": f"> {selected_switch['mechanical_endurance']} cicli"
        }
    else:  # Motorizzato
        command_specs = {
            "tipo_comando": "Motorizzato 24V DC",
            "tempo_manovra": f"{selected_switch['operating_time_motorized_s']} secondi", 
            "alimentazione": "24V DC / 230V AC",
            "contatti_ausiliari": "2 NO + 2 NC",
            "segnalazione_remota": "Disponibile"
        }
    
    return {
        "elettriche": {
            "tensione_nominale": f"{selected_switch['voltage_kv']} kV",
            "corrente_nominale": f"{selected_switch['current_a']} A",
            "configurazione_poli": selected_switch["pole_configuration"],
            "frequenza": "50/60 Hz",
            "tensione_tenuta_impulso": f"{selected_switch['impulse_voltage_kv']} kV (1.2/50 μs)",
            "tensione_tenuta_frequenza": f"{selected_switch['power_frequency_voltage_kv']} kV (1 min)",
            "potere_chiusura_cc": f"{selected_switch['breaking_capacity_ka']} kA",
            "corrente_breve_durata": f"{selected_switch['short_time_current_ka']} kA (1s)",
            "corrente_picco": f"{selected_switch['peak_current_ka']} kA"
        },
        "meccaniche": command_specs,
        "sicurezza": {
            "grado_protezione": selected_switch["protection_degree"],
            "classe_isolamento": "Classe I", 
            "resistenza_meccanica": "IK08",
            "indicazione_posizione": "Meccanica visibile",
            "blocco_meccanico": "Standard (previene manovre errate)",
            "conformita_normative": "IEC 62271-102, CEI 11-27"
        },
        "ambientali": {
            "temperatura_servizio": temp_range,
            "umidita_relativa": "95% (senza condensa)",
            "altitudine_max": "1000 m s.l.m.",
            "resistenza_sismica": "Classe II (ag = 0.25g)",
            "resistenza_uv": "Eccellente (per outdoor)" if installation == "Outdoor" else "Standard",
            "grado_inquinamento": "Livello III"
        },
        "dimensioni": {
            "altezza": f"{selected_switch['dimensions_mm']['height']} mm",
            "larghezza": f"{selected_switch['dimensions_mm']['width']} mm",
            "profondita": f"{selected_switch['dimensions_mm']['depth']} mm", 
            "peso": f"{selected_switch['weight_kg']} kg",
            "spazio_manovra": "600 mm (accesso frontale)"
        }
    }