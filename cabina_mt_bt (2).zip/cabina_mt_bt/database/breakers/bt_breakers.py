"""
bt_breakers.py
TODO: Implementare contenuto
"""