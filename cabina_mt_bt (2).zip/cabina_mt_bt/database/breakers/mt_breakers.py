"""
mt_breakers.py
TODO: Implementare contenuto
"""