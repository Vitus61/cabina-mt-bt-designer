"""
Modulo per coordinamento protezioni elettriche.
Algoritmi per selettività e tarature protezioni.
"""
from typing import Dict, List, Optional, Tuple, Union
import math
from dataclasses import dataclass
from enum import Enum

class ProtectionType(Enum):
    """Tipi di protezione"""
    OVERCURRENT = "overcurrent"
    EARTH_FAULT = "earth_fault" 
    SHORT_CIRCUIT = "short_circuit"
    ARC_FAULT = "arc_fault"
    DIFFERENTIAL = "differential"

class CurveType(Enum):
    """Tipi di curve protezione"""
    DEFINITE_TIME = "definite_time"
    INVERSE_TIME = "inverse_time"
    VERY_INVERSE = "very_inverse"
    EXTREMELY_INVERSE = "extremely_inverse"
    LONG_INVERSE = "long_inverse"

@dataclass
class ProtectionSettings:
    """Impostazioni protezione"""
    pickup_current: float  # Corrente di intervento (A o xIn)
    time_delay: float      # Ritardo temporale (s)
    curve_type: CurveType  # Tipo curva
    enabled: bool = True   # Abilitata
    time_multiplier: float = 1.0  # Moltiplicatore temporale

@dataclass 
class ProtectionDevice:
    """Dispositivo di protezione"""
    name: str
    device_type: str  # "relay", "circuit_breaker", "fuse"
    rated_current: float
    breaking_capacity: float
    settings: Dict[ProtectionType, ProtectionSettings]
    level: int = 1  # Livello gerarchico (1=monte, 2=intermedio, 3=valle)

class SelectivityAnalyzer:
    """Analizzatore di selettività protezioni"""
    
    def __init__(self):
        self.minimum_discrimination_time = 0.3  # secondi
        self.coordination_factors = {
            'fuse_fuse': 2.0,
            'relay_relay': 1.6, 
            'fuse_relay': 1.4,
            'relay_fuse': 1.2
        }
    
    def analyze_selectivity(self, protection_cascade: List[ProtectionDevice], 
                          fault_currents: List[float]) -> Dict:
        """
        Analizza selettività completa della cascata
        
        Args:
            protection_cascade: Lista dispositivi dal monte al valle
            fault_currents: Correnti di guasto da analizzare
        
        Returns:
            Dict con risultati selettività
        """
        results = {
            'overall_selective': True,
            'selectivity_percentage': 100.0,
            'coordination_issues': [],
            'detailed_analysis': [],
            'recommendations': []
        }
        
        total_pairs = 0
        selective_pairs = 0
        
        # Analizza ogni coppia adiacente
        for i in range(len(protection_cascade) - 1):
            upstream = protection_cascade[i]
            downstream = protection_cascade[i + 1]
            
            pair_result = self._analyze_pair_selectivity(upstream, downstream, fault_currents)
            results['detailed_analysis'].append(pair_result)
            
            total_pairs += 1
            if pair_result['selective']:
                selective_pairs += 1
            else:
                results['overall_selective'] = False
                results['coordination_issues'].extend(pair_result['issues'])
        
        # Calcola percentuale selettività
        if total_pairs > 0:
            results['selectivity_percentage'] = (selective_pairs / total_pairs) * 100
        
        # Genera raccomandazioni
        results['recommendations'] = self._generate_recommendations(results)
        
        return results
    
    def _analyze_pair_selectivity(self, upstream: ProtectionDevice, 
                                downstream: ProtectionDevice,
                                fault_currents: List[float]) -> Dict:
        """Analizza selettività tra due dispositivi adiacenti"""
        pair_result = {
            'upstream_name': upstream.name,
            'downstream_name': downstream.name,
            'selective': True,
            'issues': [],
            'current_analysis': [],
            'time_margins': []
        }
        
        for fault_current in fault_currents:
            # Calcola tempi di intervento per ogni protezione
            upstream_times = self._calculate_operating_times(upstream, fault_current)
            downstream_times = self._calculate_operating_times(downstream, fault_current)
            
            # Verifica selettività per ogni tipo di protezione
            for prot_type in [ProtectionType.OVERCURRENT, ProtectionType.SHORT_CIRCUIT]:
                if (prot_type in upstream.settings and prot_type in downstream.settings and
                    upstream.settings[prot_type].enabled and downstream.settings[prot_type].enabled):
                    
                    t_upstream = upstream_times.get(prot_type, float('inf'))
                    t_downstream = downstream_times.get(prot_type, float('inf'))
                    
                    time_margin = t_upstream - t_downstream
                    
                    current_analysis = {
                        'fault_current_a': fault_current,
                        'protection_type': prot_type.value,
                        'upstream_time_s': t_upstream,
                        'downstream_time_s': t_downstream,
                        'time_margin_s': time_margin,
                        'selective': time_margin >= self.minimum_discrimination_time
                    }
                    
                    pair_result['current_analysis'].append(current_analysis)
                    pair_result['time_margins'].append(time_margin)
                    
                    if not current_analysis['selective']:
                        pair_result['selective'] = False
                        issue = (f"Selettività insufficiente per {prot_type.value} a {fault_current}A: "
                               f"margine {time_margin:.2f}s < {self.minimum_discrimination_time}s")
                        pair_result['issues'].append(issue)
        
        return pair_result
    
    def _calculate_operating_times(self, device: ProtectionDevice, 
                                 fault_current: float) -> Dict[ProtectionType, float]:
        """Calcola tempi di intervento per ogni protezione del dispositivo"""
        operating_times = {}
        
        for prot_type, settings in device.settings.items():
            if not settings.enabled:
                continue
                
            # Controlla se la corrente supera la soglia
            if fault_current < settings.pickup_current:
                operating_times[prot_type] = float('inf')
                continue
            
            # Calcola tempo in base al tipo di curva
            if settings.curve_type == CurveType.DEFINITE_TIME:
                operating_times[prot_type] = settings.time_delay
            
            elif settings.curve_type == CurveType.INVERSE_TIME:
                # Curva inversa standard IEC 60255
                M = fault_current / settings.pickup_current
                if M > 1:
                    t = settings.time_multiplier * (0.14 / (M**0.02 - 1))
                    operating_times[prot_type] = max(t, settings.time_delay)
                else:
                    operating_times[prot_type] = float('inf')
            
            elif settings.curve_type == CurveType.VERY_INVERSE:
                # Curva molto inversa IEC 60255
                M = fault_current / settings.pickup_current
                if M > 1:
                    t = settings.time_multiplier * (13.5 / (M - 1))
                    operating_times[prot_type] = max(t, settings.time_delay)
                else:
                    operating_times[prot_type] = float('inf')
            
            else:
                # Default a tempo definito
                operating_times[prot_type] = settings.time_delay
        
        return operating_times
    
    def optimize_settings(self, protection_cascade: List[ProtectionDevice],
                         fault_currents: List[float]) -> Dict:
        """
        Ottimizza impostazioni per migliorare selettività
        
        Args:
            protection_cascade: Cascata protezioni da ottimizzare
            fault_currents: Correnti di guasto di riferimento
        
        Returns:
            Dict con nuove impostazioni ottimizzate
        """
        optimized_settings = {}
        
        # Inizia dal valle e procedi verso monte
        for i in range(len(protection_cascade) - 1, -1, -1):
            device = protection_cascade[i]
            
            if i == len(protection_cascade) - 1:
                # Dispositivo finale (valle) - usa impostazioni originali
                optimized_settings[device.name] = device.settings
            else:
                # Dispositivi a monte - ottimizza in base al downstream
                downstream_device = protection_cascade[i + 1]
                optimized = self._optimize_device_settings(
                    device, downstream_device, fault_currents)
                optimized_settings[device.name] = optimized
        
        return {
            'optimized_settings': optimized_settings,
            'improvement_summary': self._calculate_improvement_summary(
                protection_cascade, optimized_settings, fault_currents)
        }
    
    def _optimize_device_settings(self, upstream: ProtectionDevice, 
                                downstream: ProtectionDevice,
                                fault_currents: List[float]) -> Dict[ProtectionType, ProtectionSettings]:
        """Ottimizza impostazioni di un dispositivo rispetto al downstream"""
        optimized = {}
        
        for prot_type, upstream_settings in upstream.settings.items():
            if (prot_type in downstream.settings and 
                downstream.settings[prot_type].enabled and
                upstream_settings.enabled):
                
                # Calcola tempo minimo richiesto per selettività
                min_times = []
                for fault_current in fault_currents:
                    downstream_time = self._calculate_single_protection_time(
                        downstream.settings[prot_type], fault_current)
                    
                    if downstream_time < float('inf'):
                        required_upstream_time = downstream_time + self.minimum_discrimination_time
                        min_times.append(required_upstream_time)
                
                if min_times:
                    # Usa il tempo massimo richiesto
                    optimal_time = max(min_times)
                    
                    # Crea nuove impostazioni ottimizzate
                    optimized[prot_type] = ProtectionSettings(
                        pickup_current=upstream_settings.pickup_current,
                        time_delay=optimal_time,
                        curve_type=upstream_settings.curve_type,
                        enabled=upstream_settings.enabled,
                        time_multiplier=upstream_settings.time_multiplier
                    )
                else:
                    # Mantieni impostazioni originali
                    optimized[prot_type] = upstream_settings
            else:
                # Mantieni impostazioni originali per protezioni non coordinate
                optimized[prot_type] = upstream_settings
        
        return optimized
    
    def _calculate_single_protection_time(self, settings: ProtectionSettings, 
                                        fault_current: float) -> float:
        """Calcola tempo di intervento per una singola protezione"""
        if fault_current < settings.pickup_current:
            return float('inf')
        
        if settings.curve_type == CurveType.DEFINITE_TIME:
            return settings.time_delay
        elif settings.curve_type == CurveType.INVERSE_TIME:
            M = fault_current / settings.pickup_current
            if M > 1:
                t = settings.time_multiplier * (0.14 / (M**0.02 - 1))
                return max(t, settings.time_delay)
        
        return settings.time_delay
    
    def _generate_recommendations(self, analysis_results: Dict) -> List[str]:
        """Genera raccomandazioni per migliorare selettività"""
        recommendations = []
        
        selectivity_pct = analysis_results['selectivity_percentage']
        
        if selectivity_pct >= 95:
            recommendations.append("Selettività eccellente - Sistema ottimale")
        elif selectivity_pct >= 85:
            recommendations.append("Selettività buona - Possibili ottimizzazioni minori")
        elif selectivity_pct >= 70:
            recommendations.append("Selettività sufficiente - Raccomandati miglioramenti")
        else:
            recommendations.append("Selettività insufficiente - Revisione necessaria")
        
        # Raccomandazioni specifiche
        if analysis_results['coordination_issues']:
            recommendations.append("Aumentare ritardi temporali delle protezioni a monte")
            recommendations.append("Verificare curve di intervento e moltiplicatori temporali")
            
            if len(analysis_results['coordination_issues']) > 3:
                recommendations.append("Considerare uso di relè con curve ottimizzate")
                recommendations.append("Valutare modifica delle soglie di corrente")
        
        return recommendations
    
    def _calculate_improvement_summary(self, original_cascade: List[ProtectionDevice],
                                     optimized_settings: Dict,
                                     fault_currents: List[float]) -> Dict:
        """Calcola miglioramento ottenuto con le ottimizzazioni"""
        # Crea cascata ottimizzata
        optimized_cascade = []
        for device in original_cascade:
            optimized_device = ProtectionDevice(
                name=device.name,
                device_type=device.device_type,
                rated_current=device.rated_current,
                breaking_capacity=device.breaking_capacity,
                settings=optimized_settings.get(device.name, device.settings),
                level=device.level
            )
            optimized_cascade.append(optimized_device)
        
        # Analizza selettività originale e ottimizzata
        original_analysis = self.analyze_selectivity(original_cascade, fault_currents)
        optimized_analysis = self.analyze_selectivity(optimized_cascade, fault_currents)
        
        improvement = (optimized_analysis['selectivity_percentage'] - 
                      original_analysis['selectivity_percentage'])
        
        return {
            'original_selectivity_pct': original_analysis['selectivity_percentage'],
            'optimized_selectivity_pct': optimized_analysis['selectivity_percentage'],
            'improvement_pct': improvement,
            'issues_resolved': (len(original_analysis['coordination_issues']) - 
                              len(optimized_analysis['coordination_issues']))
        }

class ArcFaultAnalyzer:
    """Analizzatore per protezioni arco elettrico"""
    
    def __init__(self):
        self.arc_constants = {
            'k_factor': 2.1,  # Costante per calcolo energia incidente
            'working_distance_mm': 610,  # Distanza lavoro tipica
            'arc_duration_cycles': 30  # Durata arco tipica in cicli
        }
    
    def calculate_incident_energy(self, fault_current_ka: float, 
                                clearing_time_s: float,
                                working_distance_mm: float = None) -> Dict:
        """
        Calcola energia incidente per arco elettrico
        
        Args:
            fault_current_ka: Corrente di guasto arco (kA)
            clearing_time_s: Tempo eliminazione guasto (s)
            working_distance_mm: Distanza di lavoro (mm)
        
        Returns:
            Dict con energia incidente e categoria PPE
        """
        if working_distance_mm is None:
            working_distance_mm = self.arc_constants['working_distance_mm']
        
        # Formula IEEE 1584 semplificata per 480V
        log_ie = (self.arc_constants['k_factor'] + 
                 1.081 * math.log10(fault_current_ka * 1000) +
                 0.0011 * 240 +  # Gap factor tipico
                 math.log10(clearing_time_s * 1000) -
                 1.4738 * math.log10(working_distance_mm))
        
        incident_energy = 10 ** log_ie  # cal/cm²
        
        # Determina categoria PPE
        if incident_energy <= 1.2:
            ppe_category = 1
            required_clothing = "Camicia e pantaloni resistenti arco"
        elif incident_energy <= 8:
            ppe_category = 2
            required_clothing = "Tuta resistente arco + casco"
        elif incident_energy <= 25:
            ppe_category = 3
            required_clothing = "Tuta resistente arco classe 3"
        else:
            ppe_category = 4
            required_clothing = "Tuta resistente arco classe 4"
        
        return {
            'incident_energy_cal_cm2': round(incident_energy, 2),
            'ppe_category': ppe_category,
            'required_clothing': required_clothing,
            'arc_flash_boundary_mm': self._calculate_arc_flash_boundary(
                fault_current_ka, clearing_time_s),
            'working_distance_mm': working_distance_mm,
            'safe_for_work': incident_energy <= 40  # Limite pratico
        }
    
    def _calculate_arc_flash_boundary(self, fault_current_ka: float,
                                    clearing_time_s: float) -> float:
        """Calcola confine arco elettrico (distanza per 1.2 cal/cm²)"""
        # Formula IEEE 1584 per confine arco
        log_afb = (self.arc_constants['k_factor'] + 
                  1.081 * math.log10(fault_current_ka * 1000) +
                  0.0011 * 240 +
                  math.log10(clearing_time_s * 1000) -
                  math.log10(1.2))  # Energia soglia
        
        return 10 ** (log_afb / 1.4738)  # mm

# Factory functions
def get_selectivity_analyzer() -> SelectivityAnalyzer:
    """Factory per SelectivityAnalyzer"""
    return SelectivityAnalyzer()

def get_arc_fault_analyzer() -> ArcFaultAnalyzer:
    """Factory per ArcFaultAnalyzer"""
    return ArcFaultAnalyzer()

def create_protection_device(name: str, device_type: str, rated_current: float,
                           breaking_capacity: float = None) -> ProtectionDevice:
    """
    Factory per creare dispositivo protezione con impostazioni default
    
    Args:
        name: Nome dispositivo
        device_type: Tipo ("relay", "circuit_breaker", "fuse")
        rated_current: Corrente nominale
        breaking_capacity: Potere interruzione
    
    Returns:
        ProtectionDevice configurato
    """
    # Impostazioni default basate sul tipo
    if device_type == "relay":
        default_settings = {
            ProtectionType.OVERCURRENT: ProtectionSettings(
                pickup_current=rated_current * 1.25,
                time_delay=0.5,
                curve_type=CurveType.INVERSE_TIME,
                time_multiplier=0.1
            ),
            ProtectionType.SHORT_CIRCUIT: ProtectionSettings(
                pickup_current=rated_current * 10,
                time_delay=0.05,
                curve_type=CurveType.DEFINITE_TIME
            )
        }
    elif device_type == "circuit_breaker":
        default_settings = {
            ProtectionType.OVERCURRENT: ProtectionSettings(
                pickup_current=rated_current * 1.0,
                time_delay=0.1,
                curve_type=CurveType.DEFINITE_TIME
            ),
            ProtectionType.SHORT_CIRCUIT: ProtectionSettings(
                pickup_current=rated_current * 8,
                time_delay=0.02,
                curve_type=CurveType.DEFINITE_TIME
            )
        }
    else:  # fuse
        default_settings = {
            ProtectionType.OVERCURRENT: ProtectionSettings(
                pickup_current=rated_current * 1.35,
                time_delay=0.01,
                curve_type=CurveType.INVERSE_TIME,
                time_multiplier=1.0
            )
        }
    
    return ProtectionDevice(
        name=name,
        device_type=device_type,
        rated_current=rated_current,
        breaking_capacity=breaking_capacity or rated_current * 20,
        settings=default_settings
    )
