"""
Modulo per le regole di validazione business.
Contiene tutte le regole di validazione separate dall'UI.
"""
from typing import Dict, List, Optional, Tuple, Union
import re
from datetime import datetime

class ValidationResult:
    """Risultato di una validazione"""
    
    def __init__(self, is_valid: bool, message: str = "", severity: str = "info"):
        self.is_valid = is_valid
        self.message = message
        self.severity = severity  # info, warning, error, critical
    
    def __bool__(self):
        return self.is_valid
    
    def __str__(self):
        return self.message

class PowerSystemValidation:
    """Validazioni per sistemi elettrici"""
    
    @staticmethod
    def validate_power_factor(power_factor: float) -> ValidationResult:
        """Valida fattore di potenza"""
        if not 0 < power_factor <= 1:
            return ValidationResult(False, "Il fattore di potenza deve essere tra 0 e 1", "error")
        
        if power_factor < 0.6:
            return ValidationResult(True, "Fattore di potenza molto basso (<0.6), verificare carichi", "warning")
        
        if power_factor < 0.8:
            return ValidationResult(True, "Fattore di potenza basso (<0.8), considerare rifasamento", "warning")
        
        return ValidationResult(True, "Fattore di potenza valido")
    
    @staticmethod
    def validate_voltage_level(voltage: float, system_type: str = "bt") -> ValidationResult:
        """Valida livello di tensione"""
        if system_type.lower() == "bt":
            standard_voltages = [230, 400]
            if voltage not in standard_voltages:
                return ValidationResult(False, f"Tensione BT non standard: {voltage}V. Standard: {standard_voltages}", "warning")
        
        elif system_type.lower() == "mt":
            if not (3000 <= voltage <= 35000):
                return ValidationResult(False, "Tensione MT deve essere tra 3kV e 35kV", "error")
        
        return ValidationResult(True, f"Tensione {voltage}V valida per sistema {system_type.upper()}")
    
    @staticmethod
    def validate_current_density(current: float, section: float, max_density: float = 4.0) -> ValidationResult:
        """Valida densità di corrente"""
        if section <= 0:
            return ValidationResult(False, "Sezione cavo deve essere maggiore di 0", "error")
        
        density = current / section
        
        if density > max_density:
            return ValidationResult(False, 
                f"Densità corrente troppo alta: {density:.1f} A/mm² > {max_density} A/mm²", "error")
        
        if density > max_density * 0.8:
            return ValidationResult(True, 
                f"Densità corrente alta: {density:.1f} A/mm² (max consigliato: {max_density*0.8:.1f})", "warning")
        
        return ValidationResult(True, f"Densità corrente OK: {density:.1f} A/mm²")

class LoadValidation:
    """Validazioni per carichi elettrici"""
    
    @staticmethod
    def validate_load_data(load: Dict) -> List[ValidationResult]:
        """Valida dati di un carico"""
        results = []
        
        # Verifica campi obbligatori
        required_fields = ['name', 'power', 'type']
        for field in required_fields:
            if field not in load or not load[field]:
                results.append(ValidationResult(False, f"Campo obbligatorio mancante: {field}", "error"))
        
        # Valida potenza
        power = load.get('power', 0)
        if not isinstance(power, (int, float)) or power <= 0:
            results.append(ValidationResult(False, "La potenza deve essere un numero positivo", "error"))
        elif power > 10000000:  # 10 MW
            results.append(ValidationResult(True, f"Potenza molto elevata: {power/1000:.1f} kW", "warning"))
        
        # Valida tipo carico
        valid_types = ['lighting', 'motors', 'outlets', 'hvac', 'ups', 'other']
        load_type = load.get('type', '').lower()
        if load_type not in valid_types:
            results.append(ValidationResult(False, 
                f"Tipo carico non valido: {load_type}. Validi: {valid_types}", "warning"))
        
        # Valida fattore di potenza se presente
        pf = load.get('power_factor')
        if pf is not None:
            pf_result = PowerSystemValidation.validate_power_factor(pf)
            results.append(pf_result)
        
        return results
    
    @staticmethod
    def validate_load_distribution(loads: List[Dict]) -> List[ValidationResult]:
        """Valida distribuzione dei carichi"""
        results = []
        
        if not loads:
            return [ValidationResult(False, "Nessun carico definito", "error")]
        
        total_power = sum(load.get('power', 0) for load in loads)
        
        # Verifica potenza totale ragionevole
        if total_power > 50000000:  # 50 MW
            results.append(ValidationResult(True, 
                f"Potenza totale molto alta: {total_power/1000000:.1f} MW", "warning"))
        
        # Verifica distribuzione per tipo
        load_by_type = {}
        for load in loads:
            load_type = load.get('type', 'other')
            load_by_type[load_type] = load_by_type.get(load_type, 0) + load.get('power', 0)
        
        # Avvisa se un tipo domina troppo
        for load_type, power in load_by_type.items():
            percentage = (power / total_power) * 100
            if percentage > 80:
                results.append(ValidationResult(True, 
                    f"Tipo '{load_type}' rappresenta {percentage:.1f}% del totale", "warning"))
        
        return results

class TransformerValidation:
    """Validazioni per trasformatori"""
    
    @staticmethod
    def validate_transformer_sizing(required_kva: float, selected_kva: float) -> ValidationResult:
        """Valida dimensionamento trasformatore"""
        if selected_kva <= 0:
            return ValidationResult(False, "Potenza trasformatore deve essere positiva", "error")
        
        utilization = (required_kva / selected_kva) * 100
        
        if utilization > 100:
            return ValidationResult(False, 
                f"Trasformatore sottodimensionato: {utilization:.1f}% > 100%", "critical")
        
        if utilization > 90:
            return ValidationResult(True, 
                f"Utilizzo trasformatore alto: {utilization:.1f}%", "warning")
        
        if utilization < 50:
            return ValidationResult(True, 
                f"Trasformatore sovradimensionato: {utilization:.1f}% < 50%", "warning")
        
        return ValidationResult(True, f"Dimensionamento trasformatore OK: {utilization:.1f}%")
    
    @staticmethod
    def validate_transformer_losses(losses_kw: float, power_kva: float) -> ValidationResult:
        """Valida perdite trasformatore"""
        if power_kva <= 0:
            return ValidationResult(False, "Potenza trasformatore non valida", "error")
        
        loss_percentage = (losses_kw / power_kva) * 100
        
        if loss_percentage > 3:
            return ValidationResult(True, 
                f"Perdite elevate: {loss_percentage:.2f}%", "warning")
        
        return ValidationResult(True, f"Perdite accettabili: {loss_percentage:.2f}%")

class ProtectionValidation:
    """Validazioni per protezioni elettriche"""
    
    @staticmethod
    def validate_protection_coordination(upstream_setting: float, downstream_setting: float, 
                                       selectivity_ratio: float = 1.6) -> ValidationResult:
        """Valida coordinamento protezioni"""
        if upstream_setting <= 0 or downstream_setting <= 0:
            return ValidationResult(False, "Tarature protezioni devono essere positive", "error")
        
        actual_ratio = upstream_setting / downstream_setting
        
        if actual_ratio < selectivity_ratio:
            return ValidationResult(False, 
                f"Coordinamento insufficiente: rapporto {actual_ratio:.2f} < {selectivity_ratio}", "error")
        
        if actual_ratio > selectivity_ratio * 2:
            return ValidationResult(True, 
                f"Coordinamento eccessivo: rapporto {actual_ratio:.2f}", "warning")
        
        return ValidationResult(True, f"Coordinamento OK: rapporto {actual_ratio:.2f}")
    
    @staticmethod
    def validate_breaking_capacity(breaking_capacity_ka: float, fault_current_ka: float) -> ValidationResult:
        """Valida potere di interruzione"""
        if fault_current_ka <= 0:
            return ValidationResult(False, "Corrente di guasto non valida", "error")
        
        if breaking_capacity_ka < fault_current_ka:
            return ValidationResult(False, 
                f"Potere di interruzione insufficiente: {breaking_capacity_ka} kA < {fault_current_ka} kA", "critical")
        
        safety_margin = (breaking_capacity_ka / fault_current_ka - 1) * 100
        
        if safety_margin < 20:
            return ValidationResult(True, 
                f"Margine di sicurezza basso: {safety_margin:.1f}%", "warning")
        
        return ValidationResult(True, f"Potere di interruzione OK (margine: {safety_margin:.1f}%)")

class CableValidation:
    """Validazioni per cavi elettrici"""
    
    @staticmethod
    def validate_cable_ampacity(cable_current: float, required_current: float) -> ValidationResult:
        """Valida portata cavo"""
        if cable_current <= 0:
            return ValidationResult(False, "Portata cavo non valida", "error")
        
        utilization = (required_current / cable_current) * 100
        
        if utilization > 100:
            return ValidationResult(False, 
                f"Cavo sottodimensionato: {utilization:.1f}% > 100%", "critical")
        
        if utilization > 80:
            return ValidationResult(True, 
                f"Utilizzo cavo alto: {utilization:.1f}%", "warning")
        
        return ValidationResult(True, f"Portata cavo OK: {utilization:.1f}%")
    
    @staticmethod
    def validate_voltage_drop(voltage_drop_percent: float, max_drop: float = 4.0) -> ValidationResult:
        """Valida caduta di tensione"""
        if voltage_drop_percent > max_drop:
            return ValidationResult(False, 
                f"Caduta tensione eccessiva: {voltage_drop_percent:.2f}% > {max_drop}%", "error")
        
        if voltage_drop_percent > max_drop * 0.8:
            return ValidationResult(True, 
                f"Caduta tensione elevata: {voltage_drop_percent:.2f}%", "warning")
        
        return ValidationResult(True, f"Caduta tensione OK: {voltage_drop_percent:.2f}%")

class SystemValidation:
    """Validazioni complete di sistema"""
    
    def __init__(self):
        self.power_validator = PowerSystemValidation()
        self.load_validator = LoadValidation()
        self.transformer_validator = TransformerValidation()
        self.protection_validator = ProtectionValidation()
        self.cable_validator = CableValidation()
    
    def validate_complete_system(self, system_data: Dict) -> Dict[str, List[ValidationResult]]:
        """Valida sistema completo"""
        results = {
            'loads': [],
            'transformer': [],
            'protections': [],
            'cables': [],
            'system': []
        }
        
        try:
            # Valida carichi
            loads = system_data.get('loads', [])
            for load in loads:
                results['loads'].extend(self.load_validator.validate_load_data(load))
            
            if loads:
                results['loads'].extend(self.load_validator.validate_load_distribution(loads))
            
            # Valida trasformatore
            transformer = system_data.get('transformer', {})
            if transformer:
                req_power = transformer.get('required_power_kva', 0)
                sel_power = transformer.get('selected_power_kva', 0)
                if req_power and sel_power:
                    results['transformer'].append(
                        self.transformer_validator.validate_transformer_sizing(req_power, sel_power))
                
                losses = transformer.get('losses_kw', 0)
                if losses and sel_power:
                    results['transformer'].append(
                        self.transformer_validator.validate_transformer_losses(losses, sel_power))
            
            # Valida protezioni
            protections = system_data.get('protections', [])
            for i in range(len(protections) - 1):
                upstream = protections[i].get('setting', 0)
                downstream = protections[i + 1].get('setting', 0)
                if upstream and downstream:
                    results['protections'].append(
                        self.protection_validator.validate_protection_coordination(upstream, downstream))
            
            # Valida cavi
            cables = system_data.get('cables', [])
            for cable in cables:
                capacity = cable.get('current_capacity', 0)
                required = cable.get('required_current', 0)
                if capacity and required:
                    results['cables'].append(
                        self.cable_validator.validate_cable_ampacity(capacity, required))
                
                v_drop = cable.get('voltage_drop_percent', 0)
                if v_drop:
                    results['cables'].append(
                        self.cable_validator.validate_voltage_drop(v_drop))
        
        except Exception as e:
            results['system'].append(ValidationResult(False, f"Errore validazione sistema: {str(e)}", "critical"))
        
        return results
    
    def get_validation_summary(self, validation_results: Dict[str, List[ValidationResult]]) -> Dict:
        """Riassunto risultati validazione"""
        summary = {
            'total_checks': 0,
            'passed': 0,
            'warnings': 0,
            'errors': 0,
            'critical': 0,
            'details': {}
        }
        
        for category, results in validation_results.items():
            category_summary = {'passed': 0, 'warnings': 0, 'errors': 0, 'critical': 0}
            
            for result in results:
                summary['total_checks'] += 1
                
                if result.is_valid:
                    if result.severity == 'warning':
                        category_summary['warnings'] += 1
                        summary['warnings'] += 1
                    else:
                        category_summary['passed'] += 1
                        summary['passed'] += 1
                else:
                    if result.severity == 'critical':
                        category_summary['critical'] += 1
                        summary['critical'] += 1
                    else:
                        category_summary['errors'] += 1
                        summary['errors'] += 1
            
            summary['details'][category] = category_summary
        
        # Calcola stato generale
        if summary['critical'] > 0:
            summary['overall_status'] = 'CRITICAL'
        elif summary['errors'] > 0:
            summary['overall_status'] = 'ERROR'
        elif summary['warnings'] > 0:
            summary['overall_status'] = 'WARNING'
        else:
            summary['overall_status'] = 'PASSED'
        
        return summary

# Factory function
def get_system_validator() -> SystemValidation:
    """Restituisce istanza del validatore di sistema"""
    return SystemValidation()
