"""
Modulo per la selezione automatica delle apparecchiature elettriche.
Contiene la logica per scegliere interruttori, cavi, trasformatori, etc.
"""
from typing import Dict, List, Optional, Tuple
import json

class BreakerSelector:
    """Selezione interruttori automatici"""
    
    def __init__(self):
        # Database semplificato interruttori MT (ABB, Schneider, Siemens)
        self.mt_breakers = {
            'vacuum': [
                {'model': 'VD4', 'brand': 'ABB', 'current': [630, 1250, 2000, 3150], 
                 'voltage': 17.5, 'breaking_capacity': 25, 'type': 'Vacuum'},
                {'model': 'SM6', 'brand': 'Schneider', 'current': [630, 1250, 2000], 
                 'voltage': 17.5, 'breaking_capacity': 25, 'type': 'Vacuum'},
                {'model': '3AH', 'brand': 'Siemens', 'current': [630, 1250, 2000], 
                 'voltage': 17.5, 'breaking_capacity': 25, 'type': 'Vacuum'}
            ]
        }
        
        # Database interruttori BT
        self.bt_breakers = {
            'mccb': [  # Interruttori scatolati
                {'model': 'Tmax T1', 'brand': 'ABB', 'current': [160], 'icu': 25, 'type': 'MCCB'},
                {'model': 'Tmax T2', 'brand': 'ABB', 'current': [250], 'icu': 36, 'type': 'MCCB'},
                {'model': 'Tmax T4', 'brand': 'ABB', 'current': [320, 400], 'icu': 50, 'type': 'MCCB'},
                {'model': 'Tmax T5', 'brand': 'ABB', 'current': [630, 800], 'icu': 70, 'type': 'MCCB'},
                {'model': 'NSX', 'brand': 'Schneider', 'current': [100, 160, 250, 400, 630], 'icu': 50, 'type': 'MCCB'},
                {'model': 'CVS', 'brand': 'Schneider', 'current': [100, 160, 250, 400, 630], 'icu': 36, 'type': 'MCCB'}
            ],
            'acb': [  # Interruttori aperti
                {'model': 'Emax 2', 'brand': 'ABB', 'current': [800, 1000, 1250, 1600, 2000, 2500, 3200, 4000], 'icu': 100, 'type': 'ACB'},
                {'model': 'Masterpact', 'brand': 'Schneider', 'current': [800, 1000, 1250, 1600, 2000, 3200, 4000], 'icu': 100, 'type': 'ACB'}
            ],
            'mcb': [  # Interruttori modulari
                {'model': 'S200', 'brand': 'ABB', 'current': [6, 10, 16, 20, 25, 32, 40, 50, 63], 'icu': 6, 'type': 'MCB', 'curve': 'C'},
                {'model': 'C60', 'brand': 'Schneider', 'current': [6, 10, 16, 20, 25, 32, 40, 50, 63], 'icu': 6, 'type': 'MCB', 'curve': 'C'}
            ]
        }
    
    def select_mt_breaker(self, rated_current: float, breaking_capacity_req: float = 25, 
                         preferred_brand: str = None) -> Dict:
        """Seleziona interruttore MT"""
        suitable_breakers = []
        
        for breaker in self.mt_breakers['vacuum']:
            # Verifica corrente nominale (deve essere >= richiesta)
            suitable_currents = [c for c in breaker['current'] if c >= rated_current]
            
            if (suitable_currents and 
                breaker['breaking_capacity'] >= breaking_capacity_req and
                (preferred_brand is None or breaker['brand'] == preferred_brand)):
                
                min_current = min(suitable_currents)
                suitable_breakers.append({
                    **breaker,
                    'selected_current': min_current,
                    'oversizing_factor': min_current / rated_current
                })
        
        if not suitable_breakers:
            return {'error': 'Nessun interruttore MT adatto trovato'}
        
        # Ordina per fattore di sovradimensionamento (preferisce quello più piccolo)
        suitable_breakers.sort(key=lambda x: x['oversizing_factor'])
        selected = suitable_breakers[0]
        
        return {
            'selected': True,
            'model': selected['model'],
            'brand': selected['brand'],
            'rated_current': selected['selected_current'],
            'breaking_capacity': selected['breaking_capacity'],
            'type': selected['type'],
            'oversizing_factor': round(selected['oversizing_factor'], 2),
            'alternatives': len(suitable_breakers) - 1
        }
    
    def select_bt_breaker(self, rated_current: float, short_circuit_current: float,
                         breaker_type: str = 'auto', preferred_brand: str = None) -> Dict:
        """Seleziona interruttore BT"""
        
        # Determina tipo interruttore se auto
        if breaker_type == 'auto':
            if rated_current <= 63:
                breaker_type = 'mcb'
            elif rated_current <= 800:
                breaker_type = 'mccb'
            else:
                breaker_type = 'acb'
        
        if breaker_type not in self.bt_breakers:
            return {'error': f'Tipo interruttore {breaker_type} non supportato'}
        
        suitable_breakers = []
        
        for breaker in self.bt_breakers[breaker_type]:
            # Verifica corrente nominale
            suitable_currents = [c for c in breaker['current'] if c >= rated_current]
            
            # Verifica potere di interruzione (Icu >= Icc)
            required_icu = short_circuit_current / 1000  # Converte in kA
            
            if (suitable_currents and 
                breaker['icu'] >= required_icu and
                (preferred_brand is None or breaker['brand'] == preferred_brand)):
                
                min_current = min(suitable_currents)
                suitable_breakers.append({
                    **breaker,
                    'selected_current': min_current,
                    'oversizing_factor': min_current / rated_current
                })
        
        if not suitable_breakers:
            return {'error': f'Nessun interruttore {breaker_type.upper()} adatto trovato'}
        
        # Seleziona quello con minor sovradimensionamento
        suitable_breakers.sort(key=lambda x: x['oversizing_factor'])
        selected = suitable_breakers[0]
        
        result = {
            'selected': True,
            'model': selected['model'],
            'brand': selected['brand'],
            'rated_current': selected['selected_current'],
            'breaking_capacity_ka': selected['icu'],
            'type': selected['type'],
            'oversizing_factor': round(selected['oversizing_factor'], 2),
            'alternatives': len(suitable_breakers) - 1
        }
        
        # Aggiungi curva per MCB
        if 'curve' in selected:
            result['curve'] = selected['curve']
        
        return result

class CableSelector:
    """Selezione cavi elettrici"""
    
    def __init__(self):
        # Database cavi standard (sezioni e portate)
        self.cable_data = {
            'copper': {
                'unipolar_pvc': {  # Cavi unipolari in PVC
                    1.5: {'current_air': 22, 'current_buried': 17},
                    2.5: {'current_air': 30, 'current_buried': 24},
                    4: {'current_air': 40, 'current_buried': 32},
                    6: {'current_air': 50, 'current_buried': 41},
                    10: {'current_air': 70, 'current_buried': 57},
                    16: {'current_air': 95, 'current_buried': 76},
                    25: {'current_air': 125, 'current_buried': 101},
                    35: {'current_air': 150, 'current_buried': 125},
                    50: {'current_air': 180, 'current_buried': 151},
                    70: {'current_air': 225, 'current_buried': 192},
                    95: {'current_air': 275, 'current_buried': 232},
                    120: {'current_air': 315, 'current_buried': 269},
                    150: {'current_air': 360, 'current_buried': 309},
                    185: {'current_air': 420, 'current_buried': 360},
                    240: {'current_air': 500, 'current_buried': 430},
                    300: {'current_air': 580, 'current_buried': 500},
                    400: {'current_air': 670, 'current_buried': 580}
                }
            }
        }
    
    def select_cable(self, current: float, installation_type: str = 'air',
                    cable_type: str = 'copper', insulation: str = 'pvc') -> Dict:
        """Seleziona sezione cavo"""
        
        cable_key = f"{cable_type}_{insulation}" if cable_type != 'copper' else f"unipolar_{insulation}"
        
        if cable_key not in self.cable_data['copper']:
            return {'error': f'Tipo cavo {cable_key} non supportato'}
        
        current_key = f'current_{installation_type}'
        cable_db = self.cable_data['copper'][cable_key]
        
        suitable_sections = []
        
        for section, data in cable_db.items():
            if current_key in data and data[current_key] >= current:
                suitable_sections.append({
                    'section': section,
                    'current_capacity': data[current_key],
                    'utilization': current / data[current_key] * 100
                })
        
        if not suitable_sections:
            return {'error': 'Nessuna sezione cavo adatta trovata'}
        
        # Ordina per utilizzo (preferisce utilizzo più alto senza superare il 100%)
        suitable_sections.sort(key=lambda x: x['section'])
        selected = suitable_sections[0]
        
        return {
            'selected': True,
            'section_mm2': selected['section'],
            'current_capacity_a': selected['current_capacity'],
            'utilization_percent': round(selected['utilization'], 1),
            'installation_type': installation_type,
            'cable_type': f"{cable_type.upper()} {insulation.upper()}",
            'alternatives': len(suitable_sections) - 1
        }

class TransformerSelector:
    """Selezione trasformatori MT/BT"""
    
    def __init__(self):
        self.transformer_data = {
            'oil_immersed': [
                {'power_kva': 100, 'losses_no_load': 0.32, 'losses_load': 1.6, 'voltage_regulation': 4},
                {'power_kva': 160, 'losses_no_load': 0.45, 'losses_load': 2.3, 'voltage_regulation': 4},
                {'power_kva': 250, 'losses_no_load': 0.65, 'losses_load': 3.2, 'voltage_regulation': 4},
                {'power_kva': 400, 'losses_no_load': 0.95, 'losses_load': 4.6, 'voltage_regulation': 4},
                {'power_kva': 630, 'losses_no_load': 1.3, 'losses_load': 6.5, 'voltage_regulation': 4},
                {'power_kva': 800, 'losses_no_load': 1.5, 'losses_load': 7.5, 'voltage_regulation': 4},
                {'power_kva': 1000, 'losses_no_load': 1.8, 'losses_load': 9.0, 'voltage_regulation': 4},
                {'power_kva': 1250, 'losses_no_load': 2.1, 'losses_load': 10.5, 'voltage_regulation': 4},
                {'power_kva': 1600, 'losses_no_load': 2.4, 'losses_load': 12.0, 'voltage_regulation': 4},
            ],
            'resin_cast': [
                {'power_kva': 100, 'losses_no_load': 0.38, 'losses_load': 1.8, 'voltage_regulation': 6},
                {'power_kva': 160, 'losses_no_load': 0.54, 'losses_load': 2.7, 'voltage_regulation': 6},
                {'power_kva': 250, 'losses_no_load': 0.78, 'losses_load': 3.8, 'voltage_regulation': 6},
                {'power_kva': 400, 'losses_no_load': 1.14, 'losses_load': 5.5, 'voltage_regulation': 6},
                {'power_kva': 630, 'losses_no_load': 1.56, 'losses_load': 7.8, 'voltage_regulation': 6},
                {'power_kva': 800, 'losses_no_load': 1.8, 'losses_load': 9.0, 'voltage_regulation': 6},
                {'power_kva': 1000, 'losses_no_load': 2.16, 'losses_load': 10.8, 'voltage_regulation': 6}
            ]
        }
    
    def select_transformer(self, required_power_kva: float, transformer_type: str = 'resin_cast',
                          safety_factor: float = 1.25) -> Dict:
        """Seleziona trasformatore"""
        
        if transformer_type not in self.transformer_data:
            return {'error': f'Tipo trasformatore {transformer_type} non supportato'}
        
        # Applica fattore di sicurezza
        design_power = required_power_kva * safety_factor
        
        suitable_transformers = [
            t for t in self.transformer_data[transformer_type] 
            if t['power_kva'] >= design_power
        ]
        
        if not suitable_transformers:
            return {'error': 'Nessun trasformatore adatto trovato'}
        
        # Seleziona il più piccolo adatto
        selected = min(suitable_transformers, key=lambda x: x['power_kva'])
        
        return {
            'selected': True,
            'power_kva': selected['power_kva'],
            'type': transformer_type.replace('_', ' ').title(),
            'utilization_percent': round(required_power_kva / selected['power_kva'] * 100, 1),
            'losses_no_load_kw': selected['losses_no_load'],
            'losses_load_kw': selected['losses_load'],
            'voltage_regulation_percent': selected['voltage_regulation'],
            'safety_factor': safety_factor,
            'oversizing_factor': round(selected['power_kva'] / required_power_kva, 2)
        }

class EquipmentSelector:
    """Classe principale per selezione apparecchiature"""
    
    def __init__(self):
        self.breaker_selector = BreakerSelector()
        self.cable_selector = CableSelector()
        self.transformer_selector = TransformerSelector()
    
    def get_complete_selection(self, requirements: Dict) -> Dict:
        """Selezione completa apparecchiature per un sistema"""
        
        results = {
            'requirements': requirements,
            'selections': {},
            'errors': [],
            'warnings': []
        }
        
        try:
            # Selezione trasformatore
            if 'transformer' in requirements:
                tf_req = requirements['transformer']
                tf_result = self.transformer_selector.select_transformer(
                    tf_req['power_kva'],
                    tf_req.get('type', 'resin_cast'),
                    tf_req.get('safety_factor', 1.25)
                )
                results['selections']['transformer'] = tf_result
            
            # Selezione interruttore MT
            if 'mt_breaker' in requirements:
                mt_req = requirements['mt_breaker']
                mt_result = self.breaker_selector.select_mt_breaker(
                    mt_req['current'],
                    mt_req.get('breaking_capacity', 25),
                    mt_req.get('brand', None)
                )
                results['selections']['mt_breaker'] = mt_result
            
            # Selezione interruttori BT
            if 'bt_breakers' in requirements:
                bt_results = []
                for i, bt_req in enumerate(requirements['bt_breakers']):
                    bt_result = self.breaker_selector.select_bt_breaker(
                        bt_req['current'],
                        bt_req['short_circuit_current'],
                        bt_req.get('type', 'auto'),
                        bt_req.get('brand', None)
                    )
                    bt_result['circuit_name'] = bt_req.get('name', f'Circuit_{i+1}')
                    bt_results.append(bt_result)
                results['selections']['bt_breakers'] = bt_results
            
            # Selezione cavi
            if 'cables' in requirements:
                cable_results = []
                for i, cable_req in enumerate(requirements['cables']):
                    cable_result = self.cable_selector.select_cable(
                        cable_req['current'],
                        cable_req.get('installation', 'air'),
                        cable_req.get('type', 'copper'),
                        cable_req.get('insulation', 'pvc')
                    )
                    cable_result['circuit_name'] = cable_req.get('name', f'Cable_{i+1}')
                    cable_results.append(cable_result)
                results['selections']['cables'] = cable_results
        
        except Exception as e:
            results['errors'].append(f"Errore nella selezione: {str(e)}")
        
        return results
    
    def export_selection_summary(self, selection_results: Dict) -> str:
        """Esporta riassunto selezione in formato testo"""
        lines = ["=== RIASSUNTO SELEZIONE APPARECCHIATURE ===\n"]
        
        selections = selection_results.get('selections', {})
        
        # Trasformatore
        if 'transformer' in selections:
            tf = selections['transformer']
            if tf.get('selected'):
                lines.append("TRASFORMATORE:")
                lines.append(f"  Potenza: {tf['power_kva']} kVA ({tf['type']})")
                lines.append(f"  Utilizzo: {tf['utilization_percent']}%")
                lines.append(f"  Perdite: {tf['losses_no_load_kw']} + {tf['losses_load_kw']} kW")
        
        # Interruttore MT
        if 'mt_breaker' in selections:
            mt = selections['mt_breaker']
            if mt.get('selected'):
                lines.append("\nINTERRUTTORE MT:")
                lines.append(f"  Modello: {mt['brand']} {mt['model']}")
                lines.append(f"  Corrente: {mt['rated_current']} A")
                lines.append(f"  Potere: {mt['breaking_capacity']} kA")
        
        # Interruttori BT
        if 'bt_breakers' in selections:
            lines.append("\nINTERRUTTORI BT:")
            for bt in selections['bt_breakers']:
                if bt.get('selected'):
                    lines.append(f"  {bt.get('circuit_name', 'N/A')}: {bt['brand']} {bt['model']} - {bt['rated_current']} A")
        
        return "\n".join(lines)

# Factory function
def get_equipment_selector() -> EquipmentSelector:
    """Restituisce istanza del selettore apparecchiature"""
    return EquipmentSelector()
