"""
Modulo per tutti i calcoli matematici e tecnici del sistema.
Separato dall'UI per essere testabile e riutilizzabile.
"""
import math
from typing import Dict, List, Tuple, Optional, Union

class PowerCalculations:
    """Calcoli relativi alla potenza elettrica"""
    
    @staticmethod
    def calculate_apparent_power(active_power: float, power_factor: float) -> float:
        """Calcola la potenza apparente da attiva e fattore di potenza"""
        if power_factor <= 0:
            raise ValueError("Il fattore di potenza deve essere maggiore di 0")
        return active_power / power_factor
    
    @staticmethod
    def calculate_current(power: float, voltage: float, power_factor: float = 1.0, phases: int = 3) -> float:
        """Calcola la corrente in base a potenza, tensione e fasi"""
        if voltage <= 0:
            raise ValueError("La tensione deve essere maggiore di 0")
        
        if phases == 3:
            return power / (math.sqrt(3) * voltage * power_factor)
        elif phases == 1:
            return power / (voltage * power_factor)
        else:
            raise ValueError("Il numero di fasi deve essere 1 o 3")
    
    @staticmethod
    def calculate_short_circuit_current(voltage: float, impedance: float) -> float:
        """Calcola corrente di cortocircuito"""
        if impedance <= 0:
            raise ValueError("L'impedenza deve essere maggiore di 0")
        return voltage / (math.sqrt(3) * impedance)

class LoadCalculations:
    """Calcoli relativi ai carichi elettrici"""
    
    @staticmethod
    def apply_diversity_factor(loads: List[Dict], diversity_factors: Dict[str, float] = None) -> float:
        """Applica fattori di diversità ai carichi"""
        if not diversity_factors:
            diversity_factors = {
                'lighting': 0.8,
                'motors': 0.7,
                'outlets': 0.6,
                'hvac': 0.9,
                'other': 0.8
            }
        
        total_diversified = 0
        for load in loads:
            load_type = load.get('type', 'other')
            power = load.get('power', 0)
            factor = diversity_factors.get(load_type, 0.8)
            total_diversified += power * factor
        
        return total_diversified
    
    @staticmethod
    def calculate_cable_sizing(current: float, length: float, voltage_drop_max: float = 0.04) -> Dict:
        """Calcola sezione cavo basata su corrente e caduta di tensione"""
        # Resistività rame a 20°C (Ohm*mm²/m)
        rho_cu = 0.0175
        
        # Sezione minima per corrente (regola semplificata)
        section_current = current / 4  # 4 A/mm² per cavi in aria
        
        # Sezione minima per caduta di tensione
        section_voltage_drop = (2 * rho_cu * current * length) / (voltage_drop_max * 400)
        
        # Sezione finale (la maggiore)
        section_final = max(section_current, section_voltage_drop)
        
        # Standardizza alle sezioni commerciali
        standard_sections = [1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300, 400, 500]
        section_standard = min([s for s in standard_sections if s >= section_final])
        
        return {
            'section_calculated': round(section_final, 2),
            'section_standard': section_standard,
            'current_density': current / section_standard,
            'voltage_drop': (2 * rho_cu * current * length) / section_standard / 400 * 100
        }

class TransformerCalculations:
    """Calcoli per trasformatori MT/BT"""
    
    @staticmethod
    def calculate_transformer_sizing(loads: List[Dict], safety_factor: float = 1.25) -> Dict:
        """Calcola potenza trasformatore necessaria"""
        total_active = sum(load.get('active_power', 0) for load in loads)
        total_apparent = sum(load.get('apparent_power', 0) for load in loads)
        
        # Se non specificata potenza apparente, calcola con cos(φ) = 0.85
        if total_apparent == 0:
            total_apparent = total_active / 0.85
        
        # Applica fattore di sicurezza
        required_power = total_apparent * safety_factor
        
        # Standardizza potenze trasformatori (kVA)
        standard_powers = [100, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600, 2000, 2500]
        transformer_power = min([p for p in standard_powers if p >= required_power/1000])
        
        return {
            'required_power_kva': round(required_power/1000, 1),
            'standard_power_kva': transformer_power,
            'utilization_factor': round((required_power/1000) / transformer_power * 100, 1),
            'total_active_kw': round(total_active/1000, 1),
            'total_apparent_kva': round(total_apparent/1000, 1)
        }
    
    @staticmethod
    def calculate_transformer_losses(power_kva: int, load_factor: float = 0.75) -> Dict:
        """Calcola perdite trasformatore"""
        # Perdite tipiche per trasformatori in resina
        no_load_losses = {
            100: 0.32, 160: 0.45, 200: 0.55, 250: 0.65, 315: 0.8, 
            400: 0.95, 500: 1.1, 630: 1.3, 800: 1.5, 1000: 1.8,
            1250: 2.1, 1600: 2.4, 2000: 2.8, 2500: 3.2
        }
        
        load_losses = {
            100: 1.6, 160: 2.3, 200: 2.8, 250: 3.2, 315: 3.8,
            400: 4.6, 500: 5.5, 630: 6.5, 800: 7.5, 1000: 9.0,
            1250: 10.5, 1600: 12.0, 2000: 14.0, 2500: 16.0
        }
        
        no_load_loss = no_load_losses.get(power_kva, power_kva * 0.003)
        load_loss = load_losses.get(power_kva, power_kva * 0.006) * (load_factor ** 2)
        
        total_losses = no_load_loss + load_loss
        efficiency = (1 - total_losses / (power_kva * load_factor)) * 100
        
        return {
            'no_load_losses_kw': round(no_load_loss, 2),
            'load_losses_kw': round(load_loss, 2),
            'total_losses_kw': round(total_losses, 2),
            'efficiency_percent': round(efficiency, 2)
        }

class ProtectionCalculations:
    """Calcoli per coordinamento protezioni"""
    
    @staticmethod
    def calculate_protection_settings(rated_current: float, cable_section: float, 
                                    protection_type: str = 'magnetothermic') -> Dict:
        """Calcola tarature protezioni"""
        
        # Corrente termica (In) = 80% della portata cavo
        cable_current_capacity = cable_section * 4  # Semplificato: 4 A/mm²
        thermal_setting = min(rated_current, cable_current_capacity * 0.8)
        
        if protection_type == 'magnetothermic':
            # Soglia magnetica = 10 x In per magnetotermici
            magnetic_threshold = thermal_setting * 10
            
            return {
                'thermal_setting_a': round(thermal_setting, 1),
                'magnetic_threshold_a': round(magnetic_threshold, 0),
                'protection_type': 'Magnetotermico',
                'curve': 'C'
            }
        
        elif protection_type == 'electronic':
            # Per relè elettronici
            return {
                'thermal_setting_a': round(thermal_setting, 1),
                'short_delay_setting_a': round(thermal_setting * 3, 1),
                'short_delay_time_ms': 100,
                'instantaneous_setting_a': round(thermal_setting * 10, 0),
                'protection_type': 'Elettronico'
            }
        
        else:
            raise ValueError(f"Tipo protezione non supportato: {protection_type}")

class EconomicCalculations:
    """Calcoli economici e analisi costi"""
    
    @staticmethod
    def calculate_energy_costs(power_kw: float, hours_year: int = 4000, 
                             energy_cost: float = 0.15) -> Dict:
        """Calcola costi energetici annuali"""
        annual_energy = power_kw * hours_year
        annual_cost = annual_energy * energy_cost
        
        return {
            'annual_energy_kwh': annual_energy,
            'annual_cost_eur': round(annual_cost, 2),
            'monthly_cost_eur': round(annual_cost / 12, 2),
            'energy_cost_per_kwh': energy_cost
        }
    
    @staticmethod
    def calculate_loss_costs(losses_kw: float, hours_year: int = 8760,
                           energy_cost: float = 0.15) -> Dict:
        """Calcola costi perdite energetiche"""
        annual_loss_energy = losses_kw * hours_year
        annual_loss_cost = annual_loss_energy * energy_cost
        
        return {
            'annual_loss_kwh': round(annual_loss_energy, 0),
            'annual_loss_cost_eur': round(annual_loss_cost, 2),
            'loss_percentage': 'Da calcolare rispetto al carico',
            'payback_info': 'Confrontare con investimento iniziale'
        }

# Factory function per accesso unificato
def get_calculator(calc_type: str):
    """Factory per ottenere il calcolatore richiesto"""
    calculators = {
        'power': PowerCalculations,
        'load': LoadCalculations, 
        'transformer': TransformerCalculations,
        'protection': ProtectionCalculations,
        'economic': EconomicCalculations
    }
    
    if calc_type not in calculators:
        available = ', '.join(calculators.keys())
        raise ValueError(f"Tipo calcolatore '{calc_type}' non disponibile. "
                        f"Disponibili: {available}")
    
    return calculators[calc_type]()
