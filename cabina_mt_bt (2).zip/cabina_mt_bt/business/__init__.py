# Business Logic Modules
"""
Questo package contiene la logica di business separata dall'UI.

Moduli:
- calculations.py: Calcoli matematici e tecnici
- equipment_selection.py: Logica di selezione apparecchiature  
- validation_rules.py: Regole di validazione business
- transformer_sizing.py: Dimensionamento trasformatori
- protection_coordination.py: Coordinamento protezioni
"""
