"""
Modulo per dimensionamento trasformatori.
Separato dall'UI per logica pulita e riutilizzabile.
"""
from typing import Dict, List, Optional, Tuple
import math

class TransformerSizer:
    """Classe per dimensionamento trasformatori MT/BT"""
    
    def __init__(self):
        # Standard power ratings (kVA)
        self.standard_powers = [100, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600, 2000, 2500]
        
        # Efficiency classes per Reg. UE 548/2014
        self.efficiency_classes = {
            'A+++': {'losses_multiplier': 0.7, 'cost_multiplier': 1.4},
            'A++': {'losses_multiplier': 0.8, 'cost_multiplier': 1.2},
            'A+': {'losses_multiplier': 0.9, 'cost_multiplier': 1.1},
            'A': {'losses_multiplier': 1.0, 'cost_multiplier': 1.0},
            'B': {'losses_multiplier': 1.2, 'cost_multiplier': 0.9}
        }
    
    def calculate_required_power(self, loads: List[Dict], safety_factor: float = 1.25) -> Dict:
        """
        Calcola potenza trasformatore necessaria
        
        Args:
            loads: Lista carichi con power_kw e cos_phi
            safety_factor: Fattore di sicurezza (default 1.25)
        
        Returns:
            Dict con dati potenza richiesta
        """
        total_active = sum(load.get('power_kw', 0) for load in loads)
        
        # Calcola potenza apparente considerando cos_phi di ogni carico
        total_apparent = 0
        for load in loads:
            power_kw = load.get('power_kw', 0)
            cos_phi = load.get('cos_phi', 0.85)
            apparent_kva = power_kw / cos_phi
            total_apparent += apparent_kva
        
        # Applica fattore di sicurezza
        required_kva = total_apparent * safety_factor
        
        return {
            'total_active_kw': total_active,
            'total_apparent_kva': total_apparent,
            'required_with_safety_kva': required_kva,
            'safety_factor': safety_factor,
            'average_cos_phi': total_active / total_apparent if total_apparent > 0 else 0.85
        }
    
    def select_standard_power(self, required_kva: float) -> int:
        """Seleziona potenza standard più piccola adeguata"""
        suitable_powers = [p for p in self.standard_powers if p >= required_kva]
        if not suitable_powers:
            # Se richiesta superiore al massimo, ritorna il massimo
            return self.standard_powers[-1]
        return suitable_powers[0]
    
    def evaluate_single_vs_double_configuration(self, required_kva: float, 
                                              service_continuity: str = "normale") -> Dict:
        """
        Valuta configurazione singolo vs doppio trasformatore
        
        Args:
            required_kva: Potenza richiesta
            service_continuity: "normale", "privilegiata", "essenziale"
        
        Returns:
            Dict con raccomandazioni
        """
        # Configurazione singolo
        single_power = self.select_standard_power(required_kva)
        single_utilization = required_kva / single_power
        
        # Configurazione doppio
        double_power_each = self.select_standard_power(required_kva / 2)
        double_total_power = double_power_each * 2
        double_utilization = required_kva / double_total_power
        
        # Analisi costi (stima semplificata)
        single_cost = self._estimate_transformer_cost(single_power)
        double_cost = self._estimate_transformer_cost(double_power_each) * 2
        
        # Raccomandazione basata su criteri multipli
        recommendation = self._get_configuration_recommendation(
            required_kva, service_continuity, single_utilization, double_utilization
        )
        
        return {
            'single_config': {
                'power_kva': single_power,
                'utilization_percent': single_utilization * 100,
                'cost_estimate': single_cost,
                'redundancy': False
            },
            'double_config': {
                'power_each_kva': double_power_each,
                'total_power_kva': double_total_power,
                'utilization_percent': double_utilization * 100,
                'cost_estimate': double_cost,
                'redundancy': True
            },
            'recommendation': recommendation,
            'service_continuity': service_continuity
        }
    
    def calculate_losses_and_efficiency(self, power_kva: int, load_factor: float = 0.75,
                                      efficiency_class: str = "A") -> Dict:
        """
        Calcola perdite e rendimento trasformatore
        
        Args:
            power_kva: Potenza trasformatore
            load_factor: Fattore di carico (0-1)
            efficiency_class: Classe efficienza (A+++, A++, A+, A, B)
        
        Returns:
            Dict con perdite e rendimento
        """
        # Perdite tipiche base (kW)
        base_no_load_losses = {
            100: 0.32, 160: 0.45, 200: 0.55, 250: 0.65, 315: 0.8, 
            400: 0.95, 500: 1.1, 630: 1.3, 800: 1.5, 1000: 1.8,
            1250: 2.1, 1600: 2.4, 2000: 2.8, 2500: 3.2
        }
        
        base_load_losses = {
            100: 1.6, 160: 2.3, 200: 2.8, 250: 3.2, 315: 3.8,
            400: 4.6, 500: 5.5, 630: 6.5, 800: 7.5, 1000: 9.0,
            1250: 10.5, 1600: 12.0, 2000: 14.0, 2500: 16.0
        }
        
        # Perdite base
        no_load_base = base_no_load_losses.get(power_kva, power_kva * 0.003)
        load_base = base_load_losses.get(power_kva, power_kva * 0.006)
        
        # Applica moltiplicatore classe efficienza
        efficiency_multiplier = self.efficiency_classes.get(efficiency_class, 
                                                           self.efficiency_classes['A'])['losses_multiplier']
        
        no_load_losses = no_load_base * efficiency_multiplier
        load_losses = load_base * efficiency_multiplier * (load_factor ** 2)
        
        total_losses = no_load_losses + load_losses
        
        # Calcolo rendimento
        output_power = power_kva * load_factor
        input_power = output_power + total_losses
        efficiency = (output_power / input_power) * 100 if input_power > 0 else 0
        
        # Costi energetici annuali (stima)
        annual_cost_no_load = no_load_losses * 8760 * 0.15  # €/kWh
        annual_cost_load = load_losses * 8760 * 0.15
        
        return {
            'no_load_losses_kw': round(no_load_losses, 2),
            'load_losses_kw': round(load_losses, 2),
            'total_losses_kw': round(total_losses, 2),
            'efficiency_percent': round(efficiency, 2),
            'efficiency_class': efficiency_class,
            'annual_loss_cost_eur': round(annual_cost_no_load + annual_cost_load, 0),
            'load_factor': load_factor
        }
    
    def calculate_short_circuit_current(self, power_kva: int, ucc_percent: float, 
                                      voltage_secondary: float = 415) -> Dict:
        """
        Calcola corrente di cortocircuito secondario
        
        Args:
            power_kva: Potenza trasformatore
            ucc_percent: Tensione di cortocircuito (%)
            voltage_secondary: Tensione secondario (V)
        
        Returns:
            Dict con correnti di cortocircuito
        """
        # Corrente nominale secondario
        in_secondary = (power_kva * 1000) / (math.sqrt(3) * voltage_secondary)
        
        # Corrente di cortocircuito
        icc_secondary = in_secondary / (ucc_percent / 100)
        
        # Verifica potere interruzione richiesto (margine 20%)
        required_breaking_capacity = icc_secondary * 1.2
        
        return {
            'nominal_current_a': round(in_secondary, 1),
            'short_circuit_current_a': round(icc_secondary, 0),
            'required_breaking_capacity_a': round(required_breaking_capacity, 0),
            'ucc_percent': ucc_percent,
            'voltage_secondary_v': voltage_secondary
        }
    
    def analyze_parallel_operation(self, transformer1: Dict, transformer2: Dict) -> Dict:
        """
        Analizza possibilità di funzionamento in parallelo
        
        Args:
            transformer1, transformer2: Dict con dati trasformatori
        
        Returns:
            Dict con analisi parallelo
        """
        # Controlli per parallelo
        voltage_ratio_match = abs(transformer1.get('voltage_ratio', 1) - 
                                transformer2.get('voltage_ratio', 1)) < 0.005
        
        ucc_difference = abs(transformer1.get('ucc_percent', 6) - 
                           transformer2.get('ucc_percent', 6))
        ucc_compatible = ucc_difference <= 0.5  # Max 0.5% differenza
        
        power_ratio = min(transformer1.get('power_kva', 100), 
                         transformer2.get('power_kva', 100)) / \
                     max(transformer1.get('power_kva', 100), 
                         transformer2.get('power_kva', 100))
        power_compatible = power_ratio >= 0.5  # Rapporto potenze >= 1:2
        
        parallel_possible = voltage_ratio_match and ucc_compatible and power_compatible
        
        # Calcolo distribuzione carichi
        total_power = transformer1.get('power_kva', 100) + transformer2.get('power_kva', 100)
        load_distribution_1 = transformer1.get('power_kva', 100) / total_power
        load_distribution_2 = transformer2.get('power_kva', 100) / total_power
        
        return {
            'parallel_possible': parallel_possible,
            'voltage_ratio_match': voltage_ratio_match,
            'ucc_compatible': ucc_compatible,
            'ucc_difference_percent': round(ucc_difference, 2),
            'power_compatible': power_compatible,
            'power_ratio': round(power_ratio, 2),
            'load_distribution': {
                'transformer_1_percent': round(load_distribution_1 * 100, 1),
                'transformer_2_percent': round(load_distribution_2 * 100, 1)
            },
            'recommendations': self._get_parallel_recommendations(
                parallel_possible, ucc_difference, power_ratio)
        }
    
    def _estimate_transformer_cost(self, power_kva: int, 
                                 transformer_type: str = "resin_cast") -> int:
        """Stima costo trasformatore"""
        base_costs = {
            'resin_cast': {
                100: 8000, 160: 12000, 200: 14000, 250: 16000, 315: 20000,
                400: 24000, 500: 28000, 630: 32000, 800: 38000, 1000: 45000,
                1250: 55000, 1600: 65000, 2000: 75000, 2500: 90000
            },
            'oil_immersed': {
                100: 6000, 160: 9000, 200: 11000, 250: 13000, 315: 16000,
                400: 19000, 500: 23000, 630: 27000, 800: 32000, 1000: 38000,
                1250: 46000, 1600: 55000, 2000: 64000, 2500: 76000
            }
        }
        
        costs = base_costs.get(transformer_type, base_costs['resin_cast'])
        return costs.get(power_kva, power_kva * 45)  # €45/kVA se non in tabella
    
    def _get_configuration_recommendation(self, required_kva: float, 
                                        service_continuity: str,
                                        single_utilization: float,
                                        double_utilization: float) -> Dict:
        """Logica raccomandazione configurazione"""
        
        # Criterio 1: Continuità servizio
        if service_continuity == "essenziale":
            return {
                'configuration': 'double',
                'reason': 'Servizio essenziale richiede ridondanza obbligatoria',
                'confidence': 'alta'
            }
        
        # Criterio 2: Limiti tecnici
        if required_kva > 1600:  # Limite pratico trasformatori singoli
            return {
                'configuration': 'double',
                'reason': 'Potenza richiesta supera limiti pratici trasformatore singolo',
                'confidence': 'alta'
            }
        
        # Criterio 3: Efficienza economica
        if service_continuity == "privilegiata":
            if required_kva > 800:
                return {
                    'configuration': 'double',
                    'reason': 'Servizio privilegiato + potenza elevata favorisce ridondanza',
                    'confidence': 'media'
                }
            else:
                return {
                    'configuration': 'single',
                    'reason': 'Potenza contenuta, singolo accettabile anche per servizio privilegiato',
                    'confidence': 'media'
                }
        
        # Criterio 4: Servizio normale - analisi economica
        if single_utilization > 0.9:
            return {
                'configuration': 'double',
                'reason': 'Utilizzo trasformatore singolo troppo elevato (>90%)',
                'confidence': 'media'
            }
        elif required_kva > 1000:
            return {
                'configuration': 'double',
                'reason': 'Potenza elevata favorisce efficienza variabile con doppio trasformatore',
                'confidence': 'bassa'
            }
        else:
            return {
                'configuration': 'single',
                'reason': 'Soluzione economicamente ottimale per servizio normale',
                'confidence': 'media'
            }
    
    def _get_parallel_recommendations(self, parallel_possible: bool, 
                                    ucc_difference: float, power_ratio: float) -> List[str]:
        """Genera raccomandazioni per funzionamento parallelo"""
        recommendations = []
        
        if not parallel_possible:
            if ucc_difference > 0.5:
                recommendations.append(f"Differenza Ucc troppo elevata ({ucc_difference:.1f}%)")
            if power_ratio < 0.5:
                recommendations.append(f"Rapporto potenze troppo squilibrato ({power_ratio:.2f})")
            recommendations.append("Considerare trasformatori con caratteristiche più simili")
        else:
            recommendations.append("Funzionamento in parallelo possibile")
            if ucc_difference > 0.2:
                recommendations.append("Monitorare distribuzione carichi per differenza Ucc")
            if power_ratio < 0.8:
                recommendations.append("Prevedere logica di gestione carichi differenziata")
        
        return recommendations

class TransformerProtectionCoordinator:
    """Classe per coordinamento protezioni trasformatore"""
    
    def __init__(self):
        self.protection_curves = {
            'damage_curve': self._transformer_damage_curve,
            'magnetizing_inrush': self._magnetizing_inrush_curve
        }
    
    def calculate_protection_settings(self, transformer_data: Dict) -> Dict:
        """
        Calcola impostazioni protezioni trasformatore
        
        Args:
            transformer_data: Dati trasformatore
        
        Returns:
            Dict con impostazioni protezioni
        """
        power_kva = transformer_data.get('power_kva', 800)
        in_primary = transformer_data.get('current_primary_a', 50)
        in_secondary = transformer_data.get('current_secondary_a', 1000)
        
        # Protezione sovraccarico (51)
        overload_pickup = in_primary * 1.25  # 125% In
        overload_time = 600  # 10 minuti
        
        # Protezione cortocircuito fase (50/51)
        phase_fault_pickup = in_primary * 8  # 800% In
        phase_fault_time = 0.1  # 100 ms
        
        # Protezione guasto terra (50N/51N)
        earth_fault_pickup = in_primary * 0.2  # 20% In
        earth_fault_time = 0.5  # 500 ms
        
        # Protezione Buchholz (gas)
        buchholz_enabled = transformer_data.get('oil_immersed', False)
        
        return {
            'overload_protection': {
                'pickup_a': round(overload_pickup, 1),
                'time_s': overload_time,
                'curve': 'inverse_time'
            },
            'phase_fault_protection': {
                'pickup_a': round(phase_fault_pickup, 1),
                'time_s': phase_fault_time,
                'curve': 'definite_time'
            },
            'earth_fault_protection': {
                'pickup_a': round(earth_fault_pickup, 1),
                'time_s': earth_fault_time,
                'curve': 'definite_time'
            },
            'buchholz_protection': {
                'enabled': buchholz_enabled,
                'alarm_level': 'low_gas',
                'trip_level': 'high_gas'
            },
            'temperature_protection': {
                'oil_temp_alarm_c': 85,
                'oil_temp_trip_c': 95,
                'winding_temp_alarm_c': 120,
                'winding_temp_trip_c': 140
            }
        }
    
    def _transformer_damage_curve(self, current_multiple: float) -> float:
        """Curva danni trasformatore secondo IEEE C57.109"""
        if current_multiple <= 2:
            return float('inf')  # Nessun danno
        elif current_multiple <= 25:
            return 1250 / (current_multiple ** 2)  # Secondi
        else:
            return 2  # Danno immediato
    
    def _magnetizing_inrush_curve(self, current_multiple: float) -> float:
        """Curva corrente di inserzione"""
        # Tipicamente 8-12 volte In per 0.1-0.5 secondi
        if current_multiple <= 12:
            return 0.5
        else:
            return 0.1

# Factory functions
def get_transformer_sizer() -> TransformerSizer:
    """Factory per TransformerSizer"""
    return TransformerSizer()

def get_protection_coordinator() -> TransformerProtectionCoordinator:
    """Factory per TransformerProtectionCoordinator"""
    return TransformerProtectionCoordinator()
