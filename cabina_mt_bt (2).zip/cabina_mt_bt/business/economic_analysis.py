"""
Modulo per analisi economiche e ROI del progetto.
Calcoli finanziari, costi lifecycle e analisi investimenti.
"""
from typing import Dict, List, Optional, Tuple, Union
import math
from dataclasses import dataclass
from datetime import datetime, timedelta

@dataclass
class CostItem:
    """Elemento di costo"""
    category: str
    description: str
    quantity: int
    unit_cost: float
    total_cost: float
    supplier: Optional[str] = None
    delivery_time_days: Optional[int] = None

@dataclass
class EnergyConsumption:
    """Dati consumo energetico"""
    annual_kwh: float
    peak_kw: float
    load_factor: float
    energy_cost_per_kwh: float
    demand_charge_per_kw: float = 0

class ProjectEconomics:
    """Analizzatore economico del progetto"""
    
    def __init__(self):
        self.discount_rate = 0.05  # 5% WACC
        self.analysis_years = 25   # Anni analisi
        self.inflation_rate = 0.02 # 2% inflazione annua
        
        # Fattori di costo per categoria
        self.cost_factors = {
            'transformers': {'installation': 0.15, 'commissioning': 0.05},
            'switchgear_mt': {'installation': 0.20, 'commissioning': 0.08},
            'switchgear_bt': {'installation': 0.12, 'commissioning': 0.03},
            'earthing': {'installation': 0.25, 'commissioning': 0.02},
            'civil_works': {'contingency': 0.10}
        }
    
    def calculate_total_project_cost(self, cost_breakdown: Dict[str, float]) -> Dict:
        """
        Calcola costo totale progetto con tutti i fattori
        
        Args:
            cost_breakdown: Dict categoria: costo_base
        
        Returns:
            Dict con analisi costi completa
        """
        detailed_costs = {}
        total_equipment = 0
        total_installation = 0
        total_commissioning = 0
        total_contingency = 0
        
        for category, base_cost in cost_breakdown.items():
            if base_cost <= 0:
                continue
                
            # Costi installazione e commissioning
            factors = self.cost_factors.get(category, {})
            installation_cost = base_cost * factors.get('installation', 0.15)
            commissioning_cost = base_cost * factors.get('commissioning', 0.05)
            contingency_cost = base_cost * factors.get('contingency', 0.10)
            
            category_total = base_cost + installation_cost + commissioning_cost + contingency_cost
            
            detailed_costs[category] = {
                'equipment': base_cost,
                'installation': installation_cost,
                'commissioning': commissioning_cost,
                'contingency': contingency_cost,
                'total': category_total
            }
            
            total_equipment += base_cost
            total_installation += installation_cost
            total_commissioning += commissioning_cost
            total_contingency += contingency_cost
        
        # Costi generali di progetto (engineering, PM, etc.)
        total_direct = total_equipment + total_installation + total_commissioning + total_contingency
        engineering_cost = total_direct * 0.08  # 8% engineering
        project_management = total_direct * 0.05  # 5% PM
        permits_approvals = total_direct * 0.03  # 3% permessi
        
        total_project_cost = total_direct + engineering_cost + project_management + permits_approvals
        
        return {
            'equipment_cost': total_equipment,
            'installation_cost': total_installation,
            'commissioning_cost': total_commissioning,
            'contingency_cost': total_contingency,
            'engineering_cost': engineering_cost,
            'project_management_cost': project_management,
            'permits_cost': permits_approvals,
            'total_direct_cost': total_direct,
            'total_project_cost': total_project_cost,
            'cost_per_kva': None,  # Calcolato externally
            'detailed_breakdown': detailed_costs
        }
    
    def calculate_lifecycle_costs(self, project_cost: float, 
                                annual_energy_cost: float,
                                annual_maintenance_rate: float = 0.02) -> Dict:
        """
        Calcola costi ciclo di vita (LCC)
        
        Args:
            project_cost: Costo iniziale progetto
            annual_energy_cost: Costo energetico annuale
            annual_maintenance_rate: % costo annuale manutenzione
        
        Returns:
            Dict con analisi LCC
        """
        annual_maintenance_cost = project_cost * annual_maintenance_rate
        
        # Calcolo NPV dei costi operativi
        total_energy_npv = 0
        total_maintenance_npv = 0
        yearly_costs = []
        
        for year in range(1, self.analysis_years + 1):
            # Inflazione sui costi
            inflated_energy_cost = annual_energy_cost * ((1 + self.inflation_rate) ** year)
            inflated_maintenance_cost = annual_maintenance_cost * ((1 + self.inflation_rate) ** year)
            
            # Fattore di sconto
            discount_factor = 1 / ((1 + self.discount_rate) ** year)
            
            # NPV annuale
            energy_npv = inflated_energy_cost * discount_factor
            maintenance_npv = inflated_maintenance_cost * discount_factor
            
            total_energy_npv += energy_npv
            total_maintenance_npv += maintenance_npv
            
            yearly_costs.append({
                'year': year,
                'energy_cost': inflated_energy_cost,
                'maintenance_cost': inflated_maintenance_cost,
                'total_annual': inflated_energy_cost + inflated_maintenance_cost,
                'npv_annual': energy_npv + maintenance_npv
            })
        
        # Major overhaul a metà vita (anno 12-15)
        overhaul_cost = project_cost * 0.15  # 15% del costo iniziale
        overhaul_year = 15
        overhaul_npv = overhaul_cost / ((1 + self.discount_rate) ** overhaul_year)
        
        # Valore residuo (5% del costo iniziale)
        residual_value = project_cost * 0.05
        residual_npv = residual_value / ((1 + self.discount_rate) ** self.analysis_years)
        
        total_lcc = (project_cost + total_energy_npv + total_maintenance_npv + 
                    overhaul_npv - residual_npv)
        
        return {
            'initial_investment': project_cost,
            'energy_costs_npv': total_energy_npv,
            'maintenance_costs_npv': total_maintenance_npv,
            'overhaul_cost_npv': overhaul_npv,
            'residual_value_npv': residual_npv,
            'total_lcc': total_lcc,
            'annual_equivalent_cost': self._calculate_annual_equivalent_cost(total_lcc),
            'cost_breakdown_percent': {
                'initial': (project_cost / total_lcc) * 100,
                'energy': (total_energy_npv / total_lcc) * 100,
                'maintenance': (total_maintenance_npv / total_lcc) * 100,
                'overhaul': (overhaul_npv / total_lcc) * 100
            },
            'yearly_analysis': yearly_costs[:10]  # Prime 10 anni
        }
    
    def analyze_transformer_efficiency_roi(self, 
                                         standard_losses_kw: float,
                                         efficient_losses_kw: float,
                                         efficiency_premium: float,
                                         annual_operating_hours: int = 8760) -> Dict:
        """
        Analizza ROI per trasformatori ad alta efficienza
        
        Args:
            standard_losses_kw: Perdite trasformatore standard
            efficient_losses_kw: Perdite trasformatore efficiente  
            efficiency_premium: Costo aggiuntivo per efficienza
            annual_operating_hours: Ore funzionamento annuali
        
        Returns:
            Dict con analisi ROI efficienza
        """
        # Risparmio energetico annuale
        annual_savings_kwh = (standard_losses_kw - efficient_losses_kw) * annual_operating_hours
        annual_savings_euro = annual_savings_kwh * 0.15  # €0.15/kWh
        
        # Payback semplice
        simple_payback_years = efficiency_premium / annual_savings_euro if annual_savings_euro > 0 else float('inf')
        
        # NPV del risparmio energetico
        savings_npv = 0
        for year in range(1, self.analysis_years + 1):
            inflated_savings = annual_savings_euro * ((1 + self.inflation_rate) ** year)
            discount_factor = 1 / ((1 + self.discount_rate) ** year)
            savings_npv += inflated_savings * discount_factor
        
        # NPV netto dell'investimento
        net_npv = savings_npv - efficiency_premium
        
        # IRR (approssimato)
        irr = self._calculate_irr_approximation(efficiency_premium, annual_savings_euro)
        
        return {
            'annual_energy_savings_kwh': annual_savings_kwh,
            'annual_cost_savings_eur': annual_savings_euro,
            'efficiency_premium_eur': efficiency_premium,
            'simple_payback_years': simple_payback_years,
            'npv_savings': savings_npv,
            'net_npv': net_npv,
            'irr_percent': irr,
            'profitable': net_npv > 0 and simple_payback_years < 10,
            'recommendation': self._get_efficiency_recommendation(net_npv, simple_payback_years)
        }
    
    def compare_single_vs_double_transformer(self,
                                           single_config: Dict,
                                           double_config: Dict,
                                           reliability_value_per_hour: float = 1000) -> Dict:
        """
        Confronto economico configurazione singola vs doppia
        
        Args:
            single_config: Dati configurazione singola
            double_config: Dati configurazione doppia
            reliability_value_per_hour: Valore €/ora di interruzione
        
        Returns:
            Dict con confronto economico
        """
        # Costi iniziali
        single_cost = single_config.get('total_cost', 0)
        double_cost = double_config.get('total_cost', 0)
        investment_difference = double_cost - single_cost
        
        # Stima affidabilità
        single_mtbf_hours = 50000  # MTBF trasformatore singolo
        double_mtbf_hours = 200000  # MTBF con ridondanza
        
        single_annual_outage_hours = 8760 / single_mtbf_hours
        double_annual_outage_hours = 8760 / double_mtbf_hours
        
        # Costi interruzione annuali
        single_interruption_cost = single_annual_outage_hours * reliability_value_per_hour
        double_interruption_cost = double_annual_outage_hours * reliability_value_per_hour
        
        annual_reliability_savings = single_interruption_cost - double_interruption_cost
        
        # Differenza costi operativi (perdite)
        single_losses = single_config.get('annual_loss_cost', 0)
        double_losses = double_config.get('annual_loss_cost', 0)
        annual_loss_difference = double_losses - single_losses
        
        # NPV dell'investimento in ridondanza
        total_annual_benefit = annual_reliability_savings - annual_loss_difference
        
        benefit_npv = 0
        for year in range(1, self.analysis_years + 1):
            inflated_benefit = total_annual_benefit * ((1 + self.inflation_rate) ** year)
            discount_factor = 1 / ((1 + self.discount_rate) ** year)
            benefit_npv += inflated_benefit * discount_factor
        
        net_npv_redundancy = benefit_npv - investment_difference
        
        return {
            'single_transformer_cost': single_cost,
            'double_transformer_cost': double_cost,
            'investment_difference': investment_difference,
            'annual_reliability_savings': annual_reliability_savings,
            'annual_loss_difference': annual_loss_difference,
            'total_annual_benefit': total_annual_benefit,
            'benefit_npv': benefit_npv,
            'net_npv_redundancy': net_npv_redundancy,
            'payback_years': investment_difference / total_annual_benefit if total_annual_benefit > 0 else float('inf'),
            'recommendation': self._get_redundancy_recommendation(net_npv_redundancy),
            'risk_analysis': {
                'single_expected_annual_outage_hours': single_annual_outage_hours,
                'double_expected_annual_outage_hours': double_annual_outage_hours,
                'reliability_improvement_factor': single_mtbf_hours / double_mtbf_hours
            }
        }
    
    def calculate_financing_options(self, total_investment: float) -> Dict:
        """
        Analizza opzioni di finanziamento
        
        Args:
            total_investment: Investimento totale
        
        Returns:
            Dict con opzioni finanziamento
        """
        options = {}
        
        # Opzione 1: Cash
        options['cash'] = {
            'description': 'Pagamento immediato',
            'initial_payment': total_investment,
            'total_cost': total_investment,
            'monthly_payment': 0,
            'interest_cost': 0
        }
        
        # Opzione 2: Finanziamento bancario
        loan_rate = 0.04  # 4% annuale
        loan_years = 7
        monthly_rate = loan_rate / 12
        num_payments = loan_years * 12
        
        monthly_payment = total_investment * (monthly_rate * (1 + monthly_rate)**num_payments) / \
                         ((1 + monthly_rate)**num_payments - 1)
        
        total_payments = monthly_payment * num_payments
        interest_cost = total_payments - total_investment
        
        options['bank_loan'] = {
            'description': f'Finanziamento bancario {loan_years} anni al {loan_rate*100}%',
            'initial_payment': 0,
            'monthly_payment': monthly_payment,
            'total_cost': total_payments,
            'interest_cost': interest_cost,
            'loan_years': loan_years
        }
        
        # Opzione 3: Leasing
        lease_rate = 0.05  # 5% annuale
        lease_years = 5
        monthly_lease = total_investment * (lease_rate / 12) * 1.1  # Maggiorazione leasing
        
        options['leasing'] = {
            'description': f'Leasing operativo {lease_years} anni',
            'initial_payment': total_investment * 0.1,  # Anticipo 10%
            'monthly_payment': monthly_lease,
            'total_cost': monthly_lease * lease_years * 12 + total_investment * 0.1,
            'lease_years': lease_years,
            'ownership': False
        }
        
        return {
            'financing_options': options,
            'recommendation': self._get_financing_recommendation(options),
            'cash_flow_analysis': self._analyze_cash_flows(options, total_investment)
        }
    
    def _calculate_annual_equivalent_cost(self, total_lcc: float) -> float:
        """Calcola costo annuale equivalente"""
        annuity_factor = (self.discount_rate * (1 + self.discount_rate)**self.analysis_years) / \
                        ((1 + self.discount_rate)**self.analysis_years - 1)
        return total_lcc * annuity_factor
    
    def _calculate_irr_approximation(self, initial_investment: float, 
                                   annual_cashflow: float) -> float:
        """Calcola IRR approssimato per cash flow costanti"""
        if annual_cashflow <= 0:
            return 0
        
        # Formula approssimata per IRR con cash flow costanti
        payback = initial_investment / annual_cashflow
        
        if payback >= self.analysis_years:
            return 0
        
        # Approssimazione IRR
        irr_approx = (annual_cashflow * self.analysis_years - initial_investment) / \
                    (initial_investment * self.analysis_years) * 100
        
        return max(0, min(irr_approx, 50))  # Cap tra 0% e 50%
    
    def _get_efficiency_recommendation(self, net_npv: float, payback_years: float) -> str:
        """Raccomandazione per investimento in efficienza"""
        if net_npv > 0 and payback_years <= 5:
            return "Fortemente raccomandato - ROI eccellente"
        elif net_npv > 0 and payback_years <= 8:
            return "Raccomandato - ROI positivo"
        elif payback_years <= 10:
            return "Da valutare - ROI marginale"
        else:
            return "Non raccomandato - ROI insufficiente"
    
    def _get_redundancy_recommendation(self, net_npv: float) -> str:
        """Raccomandazione per investimento in ridondanza"""
        if net_npv > 50000:
            return "Fortemente raccomandato - Valore eccellente per continuità servizio"
        elif net_npv > 0:
            return "Raccomandato - Investimento giustificato economicamente"
        elif net_npv > -20000:
            return "Da valutare - Considera valore strategico continuità servizio"
        else:
            return "Non giustificato economicamente - Valutare solo se criticamente necessario"
    
    def _get_financing_recommendation(self, options: Dict) -> str:
        """Raccomandazione opzione finanziamento"""
        cash_cost = options['cash']['total_cost']
        loan_cost = options['bank_loan']['total_cost']
        lease_cost = options['leasing']['total_cost']
        
        if cash_cost == min(cash_cost, loan_cost, lease_cost):
            return "Cash - Costo totale minimo se liquidità disponibile"
        elif loan_cost < lease_cost:
            return "Finanziamento bancario - Bilanciamento ottimale costo/liquidità"
        else:
            return "Leasing - Flessibilità massima ma costo maggiore"
    
    def _analyze_cash_flows(self, options: Dict, investment: float) -> Dict:
        """Analizza flussi di cassa per opzioni finanziamento"""
        cash_flow_analysis = {}
        
        for option_name, option_data in options.items():
            monthly_payment = option_data.get('monthly_payment', 0)
            initial_payment = option_data.get('initial_payment', investment)
            
            # Impatto su cash flow primo anno
            first_year_impact = initial_payment + (monthly_payment * 12)
            
            cash_flow_analysis[option_name] = {
                'initial_cash_requirement': initial_payment,
                'monthly_cash_impact': monthly_payment,
                'first_year_total': first_year_impact,
                'liquidity_preservation': (investment - initial_payment) / investment * 100
            }
        
        return cash_flow_analysis

# Factory function
def get_project_economics() -> ProjectEconomics:
    """Factory per ProjectEconomics"""
    return ProjectEconomics()

def create_cost_estimate(equipment_costs: Dict[str, float], 
                        project_params: Dict) -> Dict:
    """
    Crea stima costi completa del progetto
    
    Args:
        equipment_costs: Costi apparecchiature per categoria
        project_params: Parametri progetto (potenza, tipo, etc.)
    
    Returns:
        Dict con stima costi completa
    """
    economics = ProjectEconomics()
    
    # Calcolo costo totale progetto
    total_cost_analysis = economics.calculate_total_project_cost(equipment_costs)
    
    # Calcolo costo per kVA
    total_kva = project_params.get('total_kva', 800)
    if total_kva > 0:
        total_cost_analysis['cost_per_kva'] = total_cost_analysis['total_project_cost'] / total_kva
    
    # Stima costi energetici annuali
    annual_energy_cost = estimate_annual_energy_cost(project_params)
    
    # Analisi LCC
    lcc_analysis = economics.calculate_lifecycle_costs(
        total_cost_analysis['total_project_cost'],
        annual_energy_cost
    )
    
    # Analisi finanziamento
    financing_analysis = economics.calculate_financing_options(
        total_cost_analysis['total_project_cost']
    )
    
    return {
        'project_cost_analysis': total_cost_analysis,
        'lifecycle_cost_analysis': lcc_analysis,
        'financing_analysis': financing_analysis,
        'cost_per_kva': total_cost_analysis.get('cost_per_kva', 0),
        'annual_energy_cost': annual_energy_cost,
        'summary': {
            'total_investment': total_cost_analysis['total_project_cost'],
            'annual_operating_cost': annual_energy_cost + (total_cost_analysis['total_project_cost'] * 0.02),
            'lcc_25_years': lcc_analysis['total_lcc'],
            'recommended_financing': financing_analysis['recommendation']
        }
    }

def estimate_annual_energy_cost(project_params: Dict) -> float:
    """
    Stima costo energetico annuale basato sui parametri progetto
    
    Args:
        project_params: Parametri progetto
    
    Returns:
        Costo energetico annuale stimato
    """
    # Stima perdite trasformatore
    total_kva = project_params.get('total_kva', 800)
    transformer_losses_kw = total_kva * 0.012  # 1.2% perdite tipiche
    
    # Stima perdite quadri e cavi
    distribution_losses_kw = total_kva * 0.005  # 0.5% perdite distribuzione
    
    # Perdite totali
    total_losses_kw = transformer_losses_kw + distribution_losses_kw
    
    # Costo energetico (8760 ore/anno, €0.15/kWh)
    annual_loss_cost = total_losses_kw * 8760 * 0.15
    
    # Costi fissi (manutenzione, ispezioni)
    annual_maintenance_cost = total_kva * 5  # €5/kVA/anno
    
    return annual_loss_cost + annual_maintenance_cost

def analyze_investment_scenarios(base_config: Dict, 
                               alternative_configs: List[Dict]) -> Dict:
    """
    Analizza diversi scenari di investimento
    
    Args:
        base_config: Configurazione base
        alternative_configs: Liste configurazioni alternative
    
    Returns:
        Dict con confronto scenari
    """
    economics = ProjectEconomics()
    scenarios = {}
    
    # Scenario base
    base_costs = create_cost_estimate(
        base_config.get('equipment_costs', {}),
        base_config.get('project_params', {})
    )
    scenarios['base'] = {
        'description': base_config.get('description', 'Configurazione base'),
        'analysis': base_costs
    }
    
    # Scenari alternativi
    for i, alt_config in enumerate(alternative_configs):
        scenario_name = f'alternative_{i+1}'
        alt_costs = create_cost_estimate(
            alt_config.get('equipment_costs', {}),
            alt_config.get('project_params', {})
        )
        scenarios[scenario_name] = {
            'description': alt_config.get('description', f'Alternativa {i+1}'),
            'analysis': alt_costs
        }
    
    # Confronto scenari
    comparison = {}
    base_investment = scenarios['base']['analysis']['project_cost_analysis']['total_project_cost']
    base_lcc = scenarios['base']['analysis']['lifecycle_cost_analysis']['total_lcc']
    
    for scenario_name, scenario_data in scenarios.items():
        if scenario_name == 'base':
            continue
            
        investment = scenario_data['analysis']['project_cost_analysis']['total_project_cost']
        lcc = scenario_data['analysis']['lifecycle_cost_analysis']['total_lcc']
        
        comparison[scenario_name] = {
            'investment_difference': investment - base_investment,
            'lcc_difference': lcc - base_lcc,
            'investment_ratio': investment / base_investment,
            'lcc_ratio': lcc / base_lcc,
            'recommendation': _get_scenario_recommendation(
                investment - base_investment, lcc - base_lcc)
        }
    
    return {
        'scenarios': scenarios,
        'comparison': comparison,
        'best_investment': min(scenarios.keys(), 
                             key=lambda x: scenarios[x]['analysis']['project_cost_analysis']['total_project_cost']),
        'best_lcc': min(scenarios.keys(),
                       key=lambda x: scenarios[x]['analysis']['lifecycle_cost_analysis']['total_lcc'])
    }

def _get_scenario_recommendation(investment_diff: float, lcc_diff: float) -> str:
    """Raccomandazione per scenario alternativo"""
    if investment_diff <= 0 and lcc_diff <= 0:
        return "Superiore in tutti gli aspetti - Fortemente raccomandato"
    elif lcc_diff < -50000:  # Risparmio LCC significativo
        return "LCC molto vantaggioso - Raccomandato nonostante maggiore investimento"
    elif lcc_diff < 0:
        return "LCC vantaggioso - Da considerare"
    elif investment_diff < 0:
        return "Investimento minore ma LCC superiore - Valutare budget disponibile"
    else:
        return "Più costoso sia come investimento che LCC - Non raccomandato"
