"""
ABB ArTu - Configuratore Quadri BT Modulari
Solo serie ArTu L (compatta) e ArTu M (standard) per integrazione UniSec
Software Cabina MT/BT Professional v2.0
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum

class ArTuSeries(Enum):
    """Serie ArTu disponibili - SOLO L e M"""
    ARTU_L = "ArTu L - Compatto"
    ARTU_M = "ArTu M - Standard"

class BTLoadType(Enum):
    """Tipi di carico BT per distribuzione"""
    MOTORS = "motori"
    LIGHTING = "illuminazione" 
    OUTLETS = "prese"
    HEATING = "riscaldamento"
    HVAC = "climatizzazione"
    GENERAL = "generale"

@dataclass
class ArTuConfiguration:
    """Configurazione ArTu completa"""
    series: ArTuSeries
    max_current: int
    max_power_kva: int
    module_widths: List[int]  # mm disponibili
    max_feeders: int
    height_mm: int
    depth_mm: int
    protection_degree: str
    arc_fault_current: int  # kA
    suitable_for: List[str]
    base_price: int
    price_per_feeder: int
    
@dataclass
class ArTuFeeder:
    """Singola partenza ArTu"""
    name: str
    load_type: BTLoadType
    rated_current: int
    power_kw: float
    breaker_type: str  # Tmax o Emax
    protection_settings: Dict
    width_mm: int
    priority: str = "normal"  # essential, priority, normal

@dataclass
class ArTuPackage:
    """Pacchetto ArTu predefinito"""
    name: str
    series: ArTuSeries
    description: str
    suitable_for: str
    transformer_power_range: Tuple[int, int]  # kVA min, max
    configuration: ArTuConfiguration
    standard_feeders: List[ArTuFeeder]
    total_width: int
    included_features: List[str]
    estimated_price: int

class ArTuConfigurator:
    """Configuratore ArTu L e M per integrazione UniSec"""
    
    def __init__(self):
        self.configurations = self._load_artu_configurations()
        self.packages = self._load_standard_packages()
    
    def _load_artu_configurations(self) -> Dict[str, ArTuConfiguration]:
        """Carica configurazioni ArTu L e M"""
        return {
            "artu_l": ArTuConfiguration(
                series=ArTuSeries.ARTU_L,
                max_current=1600,
                max_power_kva=800,
                module_widths=[200, 400],  # Solo 2 larghezze per compattezza
                max_feeders=24,
                height_mm=2200,
                depth_mm=600,  # Più compatto
                protection_degree="IP31",
                arc_fault_current=50,  # kA
                suitable_for=[
                    "Piccole industrie", "Edifici commerciali", 
                    "Uffici", "Negozi", "Laboratori"
                ],
                base_price=12000,
                price_per_feeder=350
            ),
            
            "artu_m": ArTuConfiguration(
                series=ArTuSeries.ARTU_M,
                max_current=3200,
                max_power_kva=1600,
                module_widths=[200, 400, 600, 800],  # Tutte le larghezze standard
                max_feeders=48,
                height_mm=2200,
                depth_mm=800,  # Standard
                protection_degree="IP31",
                arc_fault_current=65,  # kA
                suitable_for=[
                    "Medie industrie", "Centri commerciali", 
                    "Ospedali", "Data center", "Stabilimenti"
                ],
                base_price=18000,
                price_per_feeder=450
            )
        }
    
    def _load_standard_packages(self) -> Dict[str, ArTuPackage]:
        """Pacchetti ArTu standard per abbinamento UniSec"""
        
        artu_l_config = self.configurations["artu_l"]
        artu_m_config = self.configurations["artu_m"]
        
        return {
            "basic_bt_400": ArTuPackage(
                name="ArTu L Basic per UniSec Basic (200-500kVA)",
                series=ArTuSeries.ARTU_L,
                description="Quadro BT compatto per trasformatori fino 500kVA",
                suitable_for="Abbinamento UniSec Basic - Piccole/medie utenze",
                transformer_power_range=(200, 500),
                configuration=artu_l_config,
                standard_feeders=[
                    ArTuFeeder("QG - Interruttore Generale", BTLoadType.GENERAL, 800, 400, "Emax2-E1.2", {}, 400, "essential"),
                    ArTuFeeder("Illuminazione", BTLoadType.LIGHTING, 63, 30, "Tmax-T4", {}, 200, "priority"),
                    ArTuFeeder("Prese Uffici", BTLoadType.OUTLETS, 100, 40, "Tmax-T5", {}, 200, "normal"),
                    ArTuFeeder("Motori", BTLoadType.MOTORS, 200, 100, "Tmax-T6", {}, 200, "priority"),
                    ArTuFeeder("HVAC", BTLoadType.HVAC, 125, 50, "Tmax-T5", {}, 200, "normal"),
                    ArTuFeeder("Servizi", BTLoadType.GENERAL, 80, 35, "Tmax-T5", {}, 200, "normal"),
                    ArTuFeeder("Riserva 1", BTLoadType.GENERAL, 100, 40, "Tmax-T5", {}, 200, "normal"),
                    ArTuFeeder("Riserva 2", BTLoadType.GENERAL, 100, 40, "Tmax-T5", {}, 200, "normal")
                ],
                total_width=1800,  # 400 + 8x200
                included_features=[
                    "✅ Struttura ArTu L IP31 certificata ABB",
                    "✅ Interruttore generale Emax2 con comando motorizzato",
                    "✅ Protezioni Tmax serie T4-T6 con PR221",
                    "✅ Cablaggio e sbarre rame 50°C",
                    "✅ Controllo remoto e segnalazioni LED",
                    "✅ Predisposizione Smart Building Integration",
                    "✅ Certificazioni CEI 23-51 e IEC 61439-2"
                ],
                estimated_price=28000
            ),
            
            "standard_bt_800": ArTuPackage(
                name="ArTu M Standard per UniSec Standard (500-1000kVA)",
                series=ArTuSeries.ARTU_M,
                description="Quadro BT standard per trasformatori 500-1000kVA",
                suitable_for="Abbinamento UniSec Standard - Medie industrie",
                transformer_power_range=(500, 1000),
                configuration=artu_m_config,
                standard_feeders=[
                    ArTuFeeder("QG - Interruttore Generale", BTLoadType.GENERAL, 1600, 800, "Emax2-E2.2", {}, 400, "essential"),
                    ArTuFeeder("Illuminazione Generale", BTLoadType.LIGHTING, 125, 60, "Tmax-T5", {}, 200, "priority"),
                    ArTuFeeder("Illuminazione Emergenza", BTLoadType.LIGHTING, 80, 35, "Tmax-T4", {}, 200, "essential"),
                    ArTuFeeder("Prese Uffici", BTLoadType.OUTLETS, 160, 80, "Tmax-T6", {}, 200, "normal"),
                    ArTuFeeder("Prese Laboratorio", BTLoadType.OUTLETS, 125, 60, "Tmax-T5", {}, 200, "normal"),
                    ArTuFeeder("Motori Produzione A", BTLoadType.MOTORS, 315, 150, "Tmax-T7", {}, 400, "priority"),
                    ArTuFeeder("Motori Produzione B", BTLoadType.MOTORS, 250, 120, "Tmax-T6", {}, 200, "priority"),
                    ArTuFeeder("HVAC Principale", BTLoadType.HVAC, 200, 100, "Tmax-T6", {}, 200, "normal"),
                    ArTuFeeder("HVAC Secondario", BTLoadType.HVAC, 125, 60, "Tmax-T5", {}, 200, "normal"),
                    ArTuFeeder("Servizi Ausiliari", BTLoadType.GENERAL, 100, 50, "Tmax-T5", {}, 200, "normal"),
                    ArTuFeeder("UPS/Emergency", BTLoadType.GENERAL, 125, 60, "Tmax-T5", {}, 200, "essential"),
                    ArTuFeeder("Riserva 1", BTLoadType.GENERAL, 160, 80, "Tmax-T6", {}, 200, "normal"),
                    ArTuFeeder("Riserva 2", BTLoadType.GENERAL, 160, 80, "Tmax-T6", {}, 200, "normal"),
                    ArTuFeeder("Riserva 3", BTLoadType.GENERAL, 125, 60, "Tmax-T5", {}, 200, "normal")
                ],
                total_width=3200,  # 400 + 13x200 + 1x400
                included_features=[
                    "✅ Tutto del Basic ArTu L +",
                    "✅ Struttura ArTu M IP31 con maggior capacità",
                    "✅ Interruttore generale Emax2 E2.2 con protezioni avanzate",
                    "✅ Doppia alimentazione ausiliari 24V/230V",
                    "✅ Sistema di monitoraggio carichi integrato",
                    "✅ Comunicazione ModBus RTU/TCP e IEC 61850",
                    "✅ Predisposizione Building Management System",
                    "✅ Protezione differenziale selettiva"
                ],
                estimated_price=45000
            ),
            
            "premium_bt_1200": ArTuPackage(
                name="ArTu M Premium per UniSec Premium (1000-1600kVA)",
                series=ArTuSeries.ARTU_M,
                description="Quadro BT premium per trasformatori 1000-1600kVA",
                suitable_for="Abbinamento UniSec Premium - Grandi industrie/criticità",
                transformer_power_range=(1000, 1600),
                configuration=artu_m_config,
                standard_feeders=[
                    ArTuFeeder("QG1 - Trafo 1", BTLoadType.GENERAL, 2000, 1000, "Emax2-E4.2", {}, 600, "essential"),
                    ArTuFeeder("QG2 - Trafo 2", BTLoadType.GENERAL, 2000, 1000, "Emax2-E4.2", {}, 600, "essential"),
                    ArTuFeeder("Accoppiamento", BTLoadType.GENERAL, 1600, 800, "Emax2-E2.2", {}, 400, "essential"),
                    ArTuFeeder("Illuminazione Normale", BTLoadType.LIGHTING, 200, 100, "Tmax-T6", {}, 200, "priority"),
                    ArTuFeeder("Illuminazione Sicurezza", BTLoadType.LIGHTING, 125, 60, "Tmax-T5", {}, 200, "essential"),
                    ArTuFeeder("Prese Processo", BTLoadType.OUTLETS, 250, 120, "Tmax-T7", {}, 200, "priority"),
                    ArTuFeeder("Motori Criticali", BTLoadType.MOTORS, 500, 250, "Emax2-E1.2", {}, 400, "essential"),
                    ArTuFeeder("Motori Processo A", BTLoadType.MOTORS, 400, 200, "Tmax-T8", {}, 200, "priority"),
                    ArTuFeeder("Motori Processo B", BTLoadType.MOTORS, 315, 150, "Tmax-T7", {}, 200, "priority"),
                    ArTuFeeder("HVAC Primario", BTLoadType.HVAC, 315, 150, "Tmax-T7", {}, 200, "priority"),
                    ArTuFeeder("HVAC Secondario", BTLoadType.HVAC, 200, 100, "Tmax-T6", {}, 200, "normal"),
                    ArTuFeeder("UPS Principale", BTLoadType.GENERAL, 200, 100, "Tmax-T6", {}, 200, "essential"),
                    ArTuFeeder("UPS Backup", BTLoadType.GENERAL, 125, 60, "Tmax-T5", {}, 200, "essential"),
                    ArTuFeeder("Servizi Critici", BTLoadType.GENERAL, 160, 80, "Tmax-T6", {}, 200, "essential"),
                    ArTuFeeder("Riserva 1", BTLoadType.GENERAL, 200, 100, "Tmax-T6", {}, 200, "normal"),
                    ArTuFeeder("Riserva 2", BTLoadType.GENERAL, 200, 100, "Tmax-T6", {}, 200, "normal")
                ],
                total_width=4800,  # 2x600 + 1x400 + 12x200
                included_features=[
                    "✅ Tutto dello Standard ArTu M +",
                    "✅ Doppia alimentazione con accoppiamento automatico",
                    "✅ Interruttori generali Emax2 E4.2 ridondanti",
                    "✅ Sistema SCADA integrato con HMI touch",
                    "✅ Analizzatori di rete multifunzione su ogni sezione",
                    "✅ Protezione arco elettrico avanzata",
                    "✅ Controllo automatico trasferimenti N-1",
                    "✅ Certificazione processo industriale critico",
                    "✅ Interfaccia Plant Management Systems"
                ],
                estimated_price=85000
            )
        }
    
    def find_compatible_packages(self, transformer_kva: float) -> List[str]:
        """Trova pacchetti ArTu compatibili con potenza trasformatore"""
        compatible = []
        for pkg_id, pkg in self.packages.items():
            min_power, max_power = pkg.transformer_power_range
            if min_power <= transformer_kva <= max_power:
                compatible.append(pkg_id)
        return compatible
    
    def get_artu_recommendation(self, transformer_kva: float, service_type: str, 
                               unisec_package: str) -> Optional[str]:
        """Raccomandazione ArTu basata su UniSec e requisiti"""
        
        compatible = self.find_compatible_packages(transformer_kva)
        
        if not compatible:
            return None
        
        # Abbinamento logico UniSec -> ArTu
        unisec_to_artu_mapping = {
            "basic_400": "basic_bt_400",
            "standard_800": "standard_bt_800", 
            "premium_1200": "premium_bt_1200",
            "compact_250": "basic_bt_400"  # Compact usa stesso ArTu del Basic
        }
        
        # Prima priorità: abbinamento diretto
        recommended = unisec_to_artu_mapping.get(unisec_package)
        if recommended and recommended in compatible:
            return recommended
        
        # Fallback: seleziona per servizio
        if service_type == "essenziale":
            return "premium_bt_1200" if "premium_bt_1200" in compatible else compatible[-1]
        elif service_type == "privilegiata":
            return "standard_bt_800" if "standard_bt_800" in compatible else compatible[0]
        else:
            return compatible[0]  # Più economico
    
    def calculate_artu_sizing(self, transformer_kva: float, load_factor: float = 0.8) -> Dict:
        """Calcola dimensionamento ArTu per trasformatore"""
        
        # Calcoli base
        rated_current_transformer = (transformer_kva * 1000) / (400 * 1.732)
        design_current = rated_current_transformer * load_factor
        
        # Seleziona serie appropriata
        if design_current <= 1200:
            recommended_series = "artu_l"
            max_feeders = 16  # Tipico per ArTu L
        else:
            recommended_series = "artu_m"
            max_feeders = 24  # Tipico per ArTu M
        
        return {
            "transformer_kva": transformer_kva,
            "rated_current_transformer": rated_current_transformer,
            "design_current": design_current,
            "recommended_series": recommended_series,
            "estimated_max_feeders": max_feeders,
            "estimated_width": max_feeders * 200 + 400,  # 200mm per feeder + 400mm per generale
            "configuration": self.configurations[recommended_series]
        }

# ===============================================================================
# FUNZIONI PUBBLICHE
# ===============================================================================

def get_artu_for_unisec(unisec_package_id: str, transformer_kva: float) -> Dict:
    """Funzione pubblica per abbinamento ArTu-UniSec"""
    
    configurator = ArTuConfigurator()
    
    # Raccomandazione automatica
    recommended_artu = configurator.get_artu_recommendation(
        transformer_kva, "standard", unisec_package_id
    )
    
    if not recommended_artu:
        return {"error": "Nessun pacchetto ArTu compatibile"}
    
    artu_package = configurator.packages[recommended_artu]
    sizing = configurator.calculate_artu_sizing(transformer_kva)
    
    return {
        "recommended_package": artu_package,
        "sizing_analysis": sizing,
        "compatibility": "optimal",
        "integration_notes": f"ArTu {artu_package.series.value} ottimizzato per {unisec_package_id}"
    }

def get_artu_summary() -> Dict:
    """Riepilogo capacità ArTu disponibili"""
    configurator = ArTuConfigurator()
    
    return {
        "available_series": ["ArTu L", "ArTu M"],
        "power_range": "200-1600 kVA",
        "current_range": "800-3200 A",
        "max_feeders": "16-48",
        "standard_packages": len(configurator.packages),
        "integration": "Ottimizzato per UniSec MT"
    }

# ===============================================================================
# ISTANZE GLOBALI
# ===============================================================================

# Istanza globale per uso nel software
artu_configurator = ArTuConfigurator()

# Export delle classi principali
__all__ = [
    'ArTuConfigurator',
    'ArTuConfiguration', 
    'ArTuPackage',
    'ArTuFeeder',
    'ArTuSeries',
    'BTLoadType',
    'get_artu_for_unisec',
    'get_artu_summary',
    'artu_configurator'
]
