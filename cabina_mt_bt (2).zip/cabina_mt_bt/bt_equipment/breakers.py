"""
ABB BT Breakers - Database Interruttori Bassa Tensione
Emax 2 (ACB) + Tmax Series (MCCB) con specifiche complete ABB
Software Cabina MT/BT Professional v2.0
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum

class BreakerType(Enum):
    """Tipi interruttori BT"""
    ACB = "Air Circuit Breaker"
    MCCB = "Molded Case Circuit Breaker"

class ProtectionClass(Enum):
    """Classi protezione"""
    A = "Classe A - Generale/Trasformatore"
    B = "Classe B - Distribuzione"
    C = "Classe C - Partenze terminali"

@dataclass
class BTBreakerSpec:
    """Specifica interruttore BT con dati ABB reali"""
    series: str
    product_code: str
    frame: str
    rated_current: int
    rated_voltage: int = 415
    breaking_capacity: int = 50  # kA
    type: BreakerType = BreakerType.MCCB
    protection_unit: str = "PR221"
    dimensions_mm: Tuple[int, int, int] = (0, 0, 0)  # L x W x H
    weight_kg: float = 0.0
    cost_estimate: int = 0
    selectivity_class: ProtectionClass = ProtectionClass.C
    applications: List[str] = field(default_factory=list)
    manufacturer: str = "ABB"
    description: str = ""
    mechanical_life: int = 10000  # operations
    electrical_life: int = 50  # operations at rated breaking

class BTBreakerDatabase:
    """Database completo interruttori BT ABB"""
    
    def __init__(self):
        self.emax_2 = self._load_emax_2_series()
        self.tmax = self._load_tmax_series()
    
    def _load_emax_2_series(self) -> Dict:
        """Database Emax 2 (ACB) con specifiche complete"""
        return {
            "series_info": {
                "name": "SACE Emax 2",
                "manufacturer": "ABB",
                "type": BreakerType.ACB,
                "description": "Interruttore aperto ACB",
                "applications": ["Main distribution", "Transformer protection", "Large feeders"],
                "standards": ["IEC 60947-2", "CEI 23-51"]
            },
            "frames": {
                "E1.2": {
                    "current_range": [800, 1000, 1200],
                    "breaking_capacity": [42, 50, 65],  # kA at 415V
                    "specs": {
                        "800A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA071201R1-E1.2B08",
                            frame="E1.2",
                            rated_current=800,
                            breaking_capacity=65,
                            type=BreakerType.ACB,
                            protection_unit="PR331/P",
                            dimensions_mm=(210, 297, 279),
                            weight_kg=32.0,
                            cost_estimate=12000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Transformer feeder", "Main distribution"],
                            description="ACB 800A per trasformatori 400-500kVA"
                        ),
                        "1000A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA071301R1-E1.2B10",
                            frame="E1.2",
                            rated_current=1000,
                            breaking_capacity=65,
                            type=BreakerType.ACB,
                            protection_unit="PR331/P",
                            dimensions_mm=(210, 297, 279),
                            weight_kg=32.0,
                            cost_estimate=13500,
                            selectivity_class=ProtectionClass.A,
                            applications=["Transformer feeder", "Main distribution"],
                            description="ACB 1000A per trasformatori 500-630kVA"
                        ),
                        "1200A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA071401R1-E1.2B12",
                            frame="E1.2",
                            rated_current=1200,
                            breaking_capacity=65,
                            type=BreakerType.ACB,
                            protection_unit="PR331/P",
                            dimensions_mm=(210, 297, 279),
                            weight_kg=32.0,
                            cost_estimate=15000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Transformer feeder", "Main distribution"],
                            description="ACB 1200A per trasformatori 630-800kVA"
                        )
                    }
                },
                "E2.2": {
                    "current_range": [1250, 1600, 2000],
                    "breaking_capacity": [50, 65, 85, 100],
                    "specs": {
                        "1250A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA072201R1-E2.2B13",
                            frame="E2.2",
                            rated_current=1250,
                            breaking_capacity=85,
                            type=BreakerType.ACB,
                            protection_unit="PR332/P",
                            dimensions_mm=(210, 431, 279),
                            weight_kg=45.0,
                            cost_estimate=18000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Transformer feeder", "Main distribution"],
                            description="ACB 1250A per trasformatori 800-1000kVA"
                        ),
                        "1600A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA072301R1-E2.2B16",
                            frame="E2.2",
                            rated_current=1600,
                            breaking_capacity=85,
                            type=BreakerType.ACB,
                            protection_unit="PR332/P",
                            dimensions_mm=(210, 431, 279),
                            weight_kg=45.0,
                            cost_estimate=21000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Transformer feeder", "Main distribution"],
                            description="ACB 1600A per trasformatori 1000-1250kVA"
                        ),
                        "2000A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA072401R1-E2.2B20",
                            frame="E2.2",
                            rated_current=2000,
                            breaking_capacity=100,
                            type=BreakerType.ACB,
                            protection_unit="PR332/P",
                            dimensions_mm=(210, 431, 279),
                            weight_kg=45.0,
                            cost_estimate=25000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Transformer feeder", "Main distribution"],
                            description="ACB 2000A per trasformatori 1250-1600kVA"
                        )
                    }
                },
                "E4.2": {
                    "current_range": [2500, 3200, 4000],
                    "breaking_capacity": [65, 85, 100, 130],
                    "specs": {
                        "2500A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA074201R1-E4.2B25",
                            frame="E4.2",
                            rated_current=2500,
                            breaking_capacity=130,
                            type=BreakerType.ACB,
                            protection_unit="PR333/P",
                            dimensions_mm=(297, 567, 381),
                            weight_kg=95.0,
                            cost_estimate=32000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Large transformer", "Main switchboard"],
                            description="ACB 2500A per trasformatori >1600kVA"
                        ),
                        "3200A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA074301R1-E4.2B32",
                            frame="E4.2",
                            rated_current=3200,
                            breaking_capacity=130,
                            type=BreakerType.ACB,
                            protection_unit="PR333/P",
                            dimensions_mm=(297, 567, 381),
                            weight_kg=95.0,
                            cost_estimate=38000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Large transformer", "Main switchboard"],
                            description="ACB 3200A per trasformatori >2000kVA"
                        ),
                        "4000A": BTBreakerSpec(
                            series="SACE Emax 2",
                            product_code="1SDA074401R1-E4.2B40",
                            frame="E4.2",
                            rated_current=4000,
                            breaking_capacity=130,
                            type=BreakerType.ACB,
                            protection_unit="PR333/P",
                            dimensions_mm=(297, 567, 381),
                            weight_kg=95.0,
                            cost_estimate=45000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Very large transformer", "Main switchboard"],
                            description="ACB 4000A per trasformatori >2500kVA"
                        )
                    }
                }
            }
        }
    
    def _load_tmax_series(self) -> Dict:
        """Database Tmax (MCCB) con specifiche complete"""
        return {
            "series_info": {
                "name": "Tmax Series",
                "manufacturer": "ABB",
                "type": BreakerType.MCCB,
                "description": "Interruttore scatolato MCCB",
                "applications": ["Distribution feeders", "Motor protection", "Branch circuits"],
                "standards": ["IEC 60947-2", "CEI 23-51"]
            },
            "frames": {
                "T4": {
                    "current_range": [160, 200, 250, 320, 400],
                    "breaking_capacity": [25, 36, 50, 65],
                    "specs": {
                        "160A": BTBreakerSpec(
                            series="Tmax T4",
                            product_code="1SDA054160R1-T4N160",
                            frame="T4",
                            rated_current=160,
                            breaking_capacity=36,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(105, 187, 86),
                            weight_kg=4.5,
                            cost_estimate=1800,
                            selectivity_class=ProtectionClass.C,
                            applications=["Lighting", "Small loads", "Outlets"],
                            description="MCCB 160A per illuminazione e carichi leggeri"
                        ),
                        "200A": BTBreakerSpec(
                            series="Tmax T4",
                            product_code="1SDA054200R1-T4N200",
                            frame="T4",
                            rated_current=200,
                            breaking_capacity=42,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(105, 187, 86),
                            weight_kg=4.5,
                            cost_estimate=1950,
                            selectivity_class=ProtectionClass.C,
                            applications=["Lighting", "Small loads", "Distribution"],
                            description="MCCB 200A per carichi piccoli-medi"
                        ),
                        "250A": BTBreakerSpec(
                            series="Tmax T4",
                            product_code="1SDA054250R1-T4N250",
                            frame="T4",
                            rated_current=250,
                            breaking_capacity=50,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(105, 187, 86),
                            weight_kg=4.5,
                            cost_estimate=2100,
                            selectivity_class=ProtectionClass.C,
                            applications=["Medium loads", "Distribution"],
                            description="MCCB 250A per carichi medi"
                        ),
                        "320A": BTBreakerSpec(
                            series="Tmax T4",
                            product_code="1SDA054320R1-T4N320",
                            frame="T4",
                            rated_current=320,
                            breaking_capacity=55,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(105, 187, 86),
                            weight_kg=4.5,
                            cost_estimate=2300,
                            selectivity_class=ProtectionClass.B,
                            applications=["Medium loads", "Motor feeders"],
                            description="MCCB 320A per carichi medi e motori"
                        ),
                        "400A": BTBreakerSpec(
                            series="Tmax T4",
                            product_code="1SDA054400R1-T4N400",
                            frame="T4",
                            rated_current=400,
                            breaking_capacity=65,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(105, 187, 86),
                            weight_kg=4.5,
                            cost_estimate=2500,
                            selectivity_class=ProtectionClass.B,
                            applications=["Distribution feeders", "Motor starters"],
                            description="MCCB 400A per distribuzione e motori"
                        )
                    }
                },
                "T5": {
                    "current_range": [400, 500, 630],
                    "breaking_capacity": [36, 50, 65, 70],
                    "specs": {
                        "400A": BTBreakerSpec(
                            series="Tmax T5",
                            product_code="1SDA055400R1-T5N400",
                            frame="T5",
                            rated_current=400,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(105, 297, 86),
                            weight_kg=7.5,
                            cost_estimate=3200,
                            selectivity_class=ProtectionClass.B,
                            applications=["Medium motors", "Distribution feeders"],
                            description="MCCB 400A per motori medi"
                        ),
                        "500A": BTBreakerSpec(
                            series="Tmax T5",
                            product_code="1SDA055500R1-T5N500",
                            frame="T5",
                            rated_current=500,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(105, 297, 86),
                            weight_kg=7.5,
                            cost_estimate=3600,
                            selectivity_class=ProtectionClass.B,
                            applications=["Medium motors", "Distribution feeders"],
                            description="MCCB 500A per motori e distribuzione"
                        ),
                        "630A": BTBreakerSpec(
                            series="Tmax T5",
                            product_code="1SDA055630R1-T5N630",
                            frame="T5",
                            rated_current=630,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(105, 297, 86),
                            weight_kg=7.5,
                            cost_estimate=4000,
                            selectivity_class=ProtectionClass.B,
                            applications=["Large motors", "Main feeders"],
                            description="MCCB 630A per motori grandi"
                        )
                    }
                },
                "T6": {
                    "current_range": [500, 630, 800],
                    "breaking_capacity": [36, 50, 65, 70],
                    "specs": {
                        "500A": BTBreakerSpec(
                            series="Tmax T6",
                            product_code="1SDA056500R1-T6N500",
                            frame="T6",
                            rated_current=500,
                            breaking_capacity=65,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(140, 297, 139),
                            weight_kg=10.0,
                            cost_estimate=4200,
                            selectivity_class=ProtectionClass.B,
                            applications=["Large motors", "Distribution feeders"],
                            description="MCCB 500A per motori grandi"
                        ),
                        "630A": BTBreakerSpec(
                            series="Tmax T6",
                            product_code="1SDA056630R1-T6N630",
                            frame="T6",
                            rated_current=630,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(140, 297, 139),
                            weight_kg=10.0,
                            cost_estimate=4500,
                            selectivity_class=ProtectionClass.B,
                            applications=["Large motors", "Main feeders"],
                            description="MCCB 630A rinforzato"
                        ),
                        "800A": BTBreakerSpec(
                            series="Tmax T6",
                            product_code="1SDA056800R1-T6N800",
                            frame="T6",
                            rated_current=800,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR221DS/P",
                            dimensions_mm=(140, 297, 139),
                            weight_kg=10.0,
                            cost_estimate=5200,
                            selectivity_class=ProtectionClass.B,
                            applications=["Large feeders", "Distribution"],
                            description="MCCB 800A per grandi partenze"
                        )
                    }
                },
                "T7": {
                    "current_range": [800, 1000, 1250, 1600],
                    "breaking_capacity": [36, 50, 65, 70],
                    "specs": {
                        "800A": BTBreakerSpec(
                            series="Tmax T7",
                            product_code="1SDA062801R1-T7S800",
                            frame="T7",
                            rated_current=800,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR222DS/P",
                            dimensions_mm=(140, 297, 139),
                            weight_kg=12.0,
                            cost_estimate=6000,
                            selectivity_class=ProtectionClass.A,
                            applications=["Main distribution", "Large feeders"],
                            description="MCCB 800A prestazioni elevate"
                        ),
                        "1000A": BTBreakerSpec(
                            series="Tmax T7",
                            product_code="1SDA063001R1-T7S1000",
                            frame="T7",
                            rated_current=1000,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR222DS/P",
                            dimensions_mm=(140, 297, 139),
                            weight_kg=12.0,
                            cost_estimate=7200,
                            selectivity_class=ProtectionClass.A,
                            applications=["Main distribution", "Large feeders"],
                            description="MCCB 1000A per distribuzione principale"
                        ),
                        "1250A": BTBreakerSpec(
                            series="Tmax T7",
                            product_code="1SDA063201R1-T7S1250",
                            frame="T7",
                            rated_current=1250,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR222DS/P",
                            dimensions_mm=(140, 297, 139),
                            weight_kg=12.0,
                            cost_estimate=8500,
                            selectivity_class=ProtectionClass.A,
                            applications=["Main distribution", "Large feeders"],
                            description="MCCB 1250A per distribuzione principale"
                        ),
                        "1600A": BTBreakerSpec(
                            series="Tmax T7",
                            product_code="1SDA063601R1-T7S1600",
                            frame="T7",
                            rated_current=1600,
                            breaking_capacity=70,
                            type=BreakerType.MCCB,
                            protection_unit="PR222DS/P",
                            dimensions_mm=(140, 297, 139),
                            weight_kg=12.0,
                            cost_estimate=9500,
                            selectivity_class=ProtectionClass.A,
                            applications=["Main distribution", "Large feeders"],
                            description="MCCB 1600A massima prestazione"
                        )
                    }
                }
            }
        }
    
    def get_main_breaker_for_transformer(self, transformer_kva: float) -> BTBreakerSpec:
        """Seleziona interruttore generale per trasformatore"""
        # Calcola corrente nominale trasformatore
        current_transformer = (transformer_kva * 1000) / (415 * 1.732)
        required_current = current_transformer * 1.25  # Margine sicurezza
        
        # Seleziona da Emax 2 per interruttori generali
        for frame_name, frame_data in self.emax_2["frames"].items():
            for current in frame_data["current_range"]:
                if current >= required_current:
                    return frame_data["specs"][f"{current}A"]
        
        # Fallback su massimo disponibile
        return self.emax_2["frames"]["E4.2"]["specs"]["3200A"]
    
    def get_feeder_breaker(self, load_current: float, application: str = "general") -> BTBreakerSpec:
        """Seleziona interruttore per partenza specifica"""
        required_current = load_current * 1.25
        
        # Logic: Tmax per < 800A, Emax per >= 800A
        if required_current < 800:
            # Cerca in Tmax
            for frame_name, frame_data in self.tmax["frames"].items():
                for current in frame_data["current_range"]:
                    if current >= required_current:
                        return frame_data["specs"][f"{current}A"]
        else:
            # Usa Emax
            return self.get_main_breaker_for_transformer(required_current * 415 * 1.732 / 1000)
        
        # Fallback Tmax più grande
        return self.tmax["frames"]["T7"]["specs"]["1600A"]
    
    def get_all_breakers_list(self) -> List[BTBreakerSpec]:
        """Restituisce lista completa di tutti gli interruttori"""
        all_breakers = []
        
        # Aggiungi Emax 2
        for frame_data in self.emax_2["frames"].values():
            all_breakers.extend(frame_data["specs"].values())
        
        # Aggiungi Tmax
        for frame_data in self.tmax["frames"].values():
            all_breakers.extend(frame_data["specs"].values())
        
        return all_breakers

# ===============================================================================
# ISTANZA GLOBALE
# ===============================================================================

bt_breaker_db = BTBreakerDatabase()

# Export
__all__ = [
    'BTBreakerSpec',
    'BreakerType',
    'ProtectionClass', 
    'BTBreakerDatabase',
    'bt_breaker_db'
]
