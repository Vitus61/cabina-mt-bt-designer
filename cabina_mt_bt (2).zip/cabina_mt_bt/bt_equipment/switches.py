"""
ABB BT Switches - Database Sezionatori Bassa Tensione
OTM (sezionatori rotativi) + OS (sezionatori sotto carico)
Software Cabina MT/BT Professional v2.0
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum

class SwitchType(Enum):
    """Tipi sezionatori BT"""
    ROTARY = "Sezionatore rotativo"
    LOAD_BREAK = "Sezionatore sotto carico"
    KNIFE = "Sezionatore a lama"

class SwitchApplication(Enum):
    """Applicazioni sezionatori"""
    ISOLATION = "Sezionamento per manutenzione"
    MAINTENANCE = "Isolamento per sicurezza"
    EMERGENCY = "Emergenza e soccorso"
    LOAD_SWITCHING = "Manovra sotto carico"

@dataclass
class BTSwitchSpec:
    """Specifica sezionatore BT con dati ABB completi"""
    series: str
    product_code: str
    rated_current: int
    rated_voltage: int = 415
    poles: int = 4
    switch_type: SwitchType = SwitchType.ROTARY
    breaking_capacity: int = 0  # kA - 0 per soli sezionatori
    dimensions_mm: Tuple[int, int, int] = (0, 0, 0)
    weight_kg: float = 0.0
    cost_estimate: int = 0
    applications: List[SwitchApplication] = field(default_factory=list)
    manufacturer: str = "ABB"
    description: str = ""
    standards: List[str] = field(default_factory=list)
    mechanical_life: int = 10000  # operations
    protection_degree: str = "IP40"

class BTSwitchDatabase:
    """Database completo sezionatori BT ABB"""
    
    def __init__(self):
        self.otm_series = self._load_otm_series()
        self.os_series = self._load_os_series()
    
    def _load_otm_series(self) -> Dict:
        """Database serie OTM (sezionatori rotativi)"""
        
        current_range = [125, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000]
        
        otm_specs = {}
        
        for current in current_range:
            # Calcolo costi e dimensioni basato su corrente
            base_cost = 320 + current * 0.8
            
            # Dimensioni progressive
            if current <= 200:
                dims = (120, 160, 100)
                weight = 2.5
            elif current <= 630:
                dims = (160, 200, 120)
                weight = 4.5
            elif current <= 1600:
                dims = (200, 250, 150)
                weight = 8.0
            else:
                dims = (250, 300, 180)
                weight = 15.0
            
            otm_specs[f"{current}A"] = BTSwitchSpec(
                series="OTM",
                product_code=f"1SCA022471R677{current//100}-OTM{current}F4CM230V",
                rated_current=current,
                rated_voltage=690,
                poles=4,
                switch_type=SwitchType.ROTARY,
                breaking_capacity=0,  # Solo sezionamento
                dimensions_mm=dims,
                weight_kg=weight,
                cost_estimate=int(base_cost),
                applications=[
                    SwitchApplication.ISOLATION,
                    SwitchApplication.MAINTENANCE,
                    SwitchApplication.EMERGENCY
                ],
                description=f"Sezionatore rotativo {current}A - Solo sezionamento",
                standards=["IEC 60947-3", "CEI 23-51"],
                mechanical_life=10000,
                protection_degree="IP40"
            )
        
        return {
            "series_info": {
                "name": "OTM Rotary Switch Disconnectors",
                "manufacturer": "ABB",
                "type": SwitchType.ROTARY,
                "description": "Sezionatori rotativi per isolamento",
                "max_voltage": 690,
                "standards": ["IEC 60947-3", "CEI 23-51"],
                "typical_applications": [
                    "Isolamento per manutenzione",
                    "Sezionamento di sicurezza", 
                    "Disconnessione emergenza"
                ]
            },
            "current_range": current_range,
            "specifications": otm_specs
        }
    
    def _load_os_series(self) -> Dict:
        """Database serie OS (sezionatori sotto carico)"""
        
        current_range = [160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600]
        
        os_specs = {}
        
        for current in current_range:
            # Costi superiori per capacità sotto carico
            base_cost = 580 + current * 1.2
            
            # Dimensioni maggiori per capacità interruzione
            if current <= 250:
                dims = (140, 180, 120)
                weight = 3.5
            elif current <= 630:
                dims = (180, 220, 140)
                weight = 6.0
            elif current <= 1000:
                dims = (220, 260, 160)
                weight = 10.0
            else:
                dims = (260, 300, 180)
                weight = 18.0
            
            os_specs[f"{current}A"] = BTSwitchSpec(
                series="OS",
                product_code=f"1SCA105{current//100}6{current%100}R1001-OS{current}J04",
                rated_current=current,
                rated_voltage=690,
                poles=4,
                switch_type=SwitchType.LOAD_BREAK,
                breaking_capacity=10,  # kA - può interrompere correnti di carico
                dimensions_mm=dims,
                weight_kg=weight,
                cost_estimate=int(base_cost),
                applications=[
                    SwitchApplication.LOAD_SWITCHING,
                    SwitchApplication.MAINTENANCE,
                    SwitchApplication.EMERGENCY
                ],
                description=f"Sezionatore sotto carico {current}A - Manovra carichi",
                standards=["IEC 60947-3", "CEI 23-51"],
                mechanical_life=8000,  # Minore per uso sotto carico
                protection_degree="IP40"
            )
        
        return {
            "series_info": {
                "name": "OS Load Break Switches",
                "manufacturer": "ABB",
                "type": SwitchType.LOAD_BREAK,
                "description": "Sezionatori sotto carico",
                "max_voltage": 690,
                "breaking_capacity": 10,  # kA
                "standards": ["IEC 60947-3", "CEI 23-51"],
                "typical_applications": [
                    "Manovra carichi sotto tensione",
                    "Commutazione sorgenti",
                    "Isolamento con interruzione carico"
                ]
            },
            "current_range": current_range,
            "specifications": os_specs
        }
    
    def get_switch_for_application(self, current: float, 
                                 load_break_required: bool = True,
                                 safety_margin: float = 1.1) -> BTSwitchSpec:
        """Seleziona sezionatore per applicazione specifica"""
        
        required_current = current * safety_margin
        
        # Seleziona serie appropriata
        if load_break_required:
            series_data = self.os_series
            series_name = "OS"
        else:
            series_data = self.otm_series
            series_name = "OTM"
        
        # Trova corrente standard >= richiesta
        selected_current = None
        for std_current in series_data["current_range"]:
            if std_current >= required_current:
                selected_current = std_current
                break
        
        if not selected_current:
            # Prendi il massimo disponibile
            selected_current = series_data["current_range"][-1]
        
        return series_data["specifications"][f"{selected_current}A"]
    
    def get_maintenance_switches_set(self, main_current: float) -> Dict[str, BTSwitchSpec]:
        """Set completo sezionatori per manutenzione quadro"""
        
        return {
            "main_isolation": self.get_switch_for_application(
                main_current, load_break_required=True
            ),
            "feeder_isolation_1": self.get_switch_for_application(
                main_current * 0.3, load_break_required=False
            ),
            "feeder_isolation_2": self.get_switch_for_application(
                main_current * 0.3, load_break_required=False
            ),
            "auxiliary_isolation": self.get_switch_for_application(
                25, load_break_required=False  # Ausiliari 25A tipici
            )
        }
    
    def get_emergency_switches_set(self, facility_type: str = "industrial") -> Dict[str, BTSwitchSpec]:
        """Set sezionatori emergenza per tipo impianto"""
        
        emergency_configs = {
            "industrial": {
                "main_emergency": 1600,
                "zone_emergency_1": 400,
                "zone_emergency_2": 400,
                "lighting_emergency": 160
            },
            "commercial": {
                "main_emergency": 800,
                "zone_emergency_1": 250,
                "zone_emergency_2": 250,
                "lighting_emergency": 125
            },
            "office": {
                "main_emergency": 400,
                "zone_emergency_1": 160,
                "lighting_emergency": 80
            }
        }
        
        config = emergency_configs.get(facility_type, emergency_configs["industrial"])
        
        emergency_set = {}
        for switch_name, current in config.items():
            # Emergenza sempre con capacità sotto carico
            emergency_set[switch_name] = self.get_switch_for_application(
                current, load_break_required=True
            )
        
        return emergency_set
    
    def get_all_switches_list(self) -> List[BTSwitchSpec]:
        """Lista completa di tutti i sezionatori disponibili"""
        all_switches = []
        
        # OTM series
        all_switches.extend(self.otm_series["specifications"].values())
        
        # OS series
        all_switches.extend(self.os_series["specifications"].values())
        
        return all_switches
    
    def get_switch_selection_guide(self) -> Dict:
        """Guida selezione sezionatori per applicazioni tipiche"""
        return {
            "maintenance_only": {
                "recommended_series": "OTM",
                "description": "Solo isolamento per manutenzione",
                "typical_use": "Sezionamento quadri durante interventi",
                "cost_factor": "Economico"
            },
            "load_switching": {
                "recommended_series": "OS",
                "description": "Manovra carichi e isolamento",
                "typical_use": "Commutazione sorgenti, bypass",
                "cost_factor": "Medio-alto"
            },
            "emergency_stop": {
                "recommended_series": "OS",
                "description": "Arresto emergenza con interruzione carico",
                "typical_use": "Sistemi di sicurezza, pulsanti emergenza",
                "cost_factor": "Alto"
            },
            "generator_transfer": {
                "recommended_series": "OS",
                "description": "Commutazione rete-gruppo elettrogeno",
                "typical_use": "Sistemi backup alimentazione",
                "cost_factor": "Alto"
            }
        }

# ===============================================================================
# ISTANZA GLOBALE
# ===============================================================================

bt_switch_db = BTSwitchDatabase()

# Export
__all__ = [
    'BTSwitchSpec',
    'SwitchType',
    'SwitchApplication',
    'BTSwitchDatabase',
    'bt_switch_db'
]
