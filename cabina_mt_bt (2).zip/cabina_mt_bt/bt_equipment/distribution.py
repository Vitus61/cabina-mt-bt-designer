"""
ABB BT Load Distribution - Template Distribuzione Carichi BT
Template predefiniti per distribuzione carichi secondo tipologia impianto
Software Cabina MT/BT Professional v2.0
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum

class LoadType(Enum):
    """Tipi di carico BT per distribuzione"""
    MOTORS = "motori"
    LIGHTING = "illuminazione"
    OUTLETS = "prese"
    HEATING = "riscaldamento"
    HVAC = "climatizzazione"
    GENERAL = "generale"
    UPS = "alimentazione_continuita"
    EMERGENCY = "emergenza"

class Priority(Enum):
    """Priorità carichi per gestione emergenze"""
    ESSENTIAL = "essenziale"      # Sistemi critici - sempre alimentati
    PRIORITY = "privilegiata"     # Sistemi importanti - alimentati da UPS
    NORMAL = "normale"            # Sistemi standard - primi da distaccare

class FacilityType(Enum):
    """Tipologie impianto"""
    INDUSTRIAL = "industriale"
    COMMERCIAL = "commerciale"
    OFFICE = "uffici"
    HOSPITAL = "ospedale"
    DATACENTER = "datacenter"
    RESIDENTIAL = "residenziale"

@dataclass
class BTLoadDistribution:
    """Distribuzione singolo carico BT"""
    load_name: str
    load_type: LoadType
    power_kw: float
    current_a: float
    protection_required: str  # Tipo interruttore richiesto
    priority: Priority = Priority.NORMAL
    diversity_factor: float = 1.0  # Fattore contemporaneità
    power_factor: float = 0.8  # Fattore di potenza
    utilization_factor: float = 0.8  # Fattore utilizzazione
    description: str = ""
    installation_notes: str = ""

@dataclass
class LoadDistributionTemplate:
    """Template completo distribuzione carichi per tipo impianto"""
    template_name: str
    facility_type: FacilityType
    transformer_kva: int
    description: str
    loads: List[BTLoadDistribution]
    total_power_kw: float
    total_current_a: float
    load_factor: float
    power_factor_avg: float
    safety_margin: float
    
    def calculate_totals(self) -> None:
        """Calcola totali template"""
        self.total_power_kw = sum(load.power_kw * load.diversity_factor for load in self.loads)
        self.total_current_a = sum(load.current_a * load.diversity_factor for load in self.loads)
        
        weighted_pf = sum(load.power_kw * load.power_factor for load in self.loads)
        self.power_factor_avg = weighted_pf / sum(load.power_kw for load in self.loads) if self.loads else 0.8

class BTLoadDistributionDatabase:
    """Database template distribuzione carichi BT"""
    
    def __init__(self):
        self.load_factors = self._load_electrical_factors()
        self.templates = self._load_distribution_templates()
    
    def _load_electrical_factors(self) -> Dict:
        """Fattori elettrici tipici per tipo carico"""
        return {
            LoadType.MOTORS: {
                "power_factor": 0.85,
                "utilization_factor": 0.8,
                "diversity_factor": 0.7,
                "typical_efficiency": 0.92,
                "starting_current": 6.0  # multiples of rated
            },
            LoadType.LIGHTING: {
                "power_factor": 0.9,
                "utilization_factor": 1.0,
                "diversity_factor": 0.8,
                "typical_efficiency": 0.85,
                "starting_current": 1.2
            },
            LoadType.OUTLETS: {
                "power_factor": 0.8,
                "utilization_factor": 0.6,
                "diversity_factor": 0.5,
                "typical_efficiency": 0.95,
                "starting_current": 1.0
            },
            LoadType.HEATING: {
                "power_factor": 1.0,
                "utilization_factor": 1.0,
                "diversity_factor": 0.9,
                "typical_efficiency": 0.98,
                "starting_current": 1.0
            },
            LoadType.HVAC: {
                "power_factor": 0.85,
                "utilization_factor": 0.9,
                "diversity_factor": 0.8,
                "typical_efficiency": 0.88,
                "starting_current": 5.0
            },
            LoadType.GENERAL: {
                "power_factor": 0.8,
                "utilization_factor": 0.8,
                "diversity_factor": 0.7,
                "typical_efficiency": 0.90,
                "starting_current": 1.5
            },
            LoadType.UPS: {
                "power_factor": 1.0,
                "utilization_factor": 0.8,
                "diversity_factor": 1.0,
                "typical_efficiency": 0.95,
                "starting_current": 1.0
            },
            LoadType.EMERGENCY: {
                "power_factor": 0.9,
                "utilization_factor": 1.0,
                "diversity_factor": 1.0,
                "typical_efficiency": 0.90,
                "starting_current": 1.2
            }
        }
    
    def _load_distribution_templates(self) -> Dict[str, LoadDistributionTemplate]:
        """Carica template predefiniti per tipologie impianto"""
        
        templates = {}
        
        # ================== PICCOLO IMPIANTO INDUSTRIALE ==================
        small_industrial = LoadDistributionTemplate(
            template_name="Piccolo Stabilimento 400kVA",
            facility_type=FacilityType.INDUSTRIAL,
            transformer_kva=400,
            description="Piccola industria manifatturiera",
            loads=[
                BTLoadDistribution(
                    "QG - Interruttore Generale", LoadType.GENERAL, 300, 433,
                    "Emax2-E1.2", Priority.ESSENTIAL, 1.0, 0.8, 1.0,
                    "Interruttore generale trasformatore",
                    "Protezione generale e sezionamento"
                ),
                BTLoadDistribution(
                    "Illuminazione Produzione", LoadType.LIGHTING, 30, 43,
                    "Tmax-T4", Priority.PRIORITY, 0.8, 0.9, 1.0,
                    "Illuminazione capannone produzione",
                    "Comando automatico crepuscolare"
                ),
                BTLoadDistribution(
                    "Illuminazione Uffici", LoadType.LIGHTING, 15, 22,
                    "Tmax-T4", Priority.NORMAL, 0.7, 0.9, 0.8,
                    "Illuminazione zone uffici",
                    "Controllo presenza + manuale"
                ),
                BTLoadDistribution(
                    "Prese Produzione", LoadType.OUTLETS, 40, 58,
                    "Tmax-T5", Priority.NORMAL, 0.5, 0.8, 0.6,
                    "Prese area produzione",
                    "Prese industriali 16A + 32A"
                ),
                BTLoadDistribution(
                    "Prese Uffici", LoadType.OUTLETS, 25, 36,
                    "Tmax-T4", Priority.NORMAL, 0.4, 0.8, 0.5,
                    "Prese zone uffici",
                    "Prese standard 10/16A"
                ),
                BTLoadDistribution(
                    "Motori Produzione A", LoadType.MOTORS, 100, 144,
                    "Tmax-T6", Priority.PRIORITY, 0.7, 0.85, 0.8,
                    "Linea produzione principale",
                    "Avviamento soft-start"
                ),
                BTLoadDistribution(
                    "Motori Ausiliari", LoadType.MOTORS, 30, 43,
                    "Tmax-T5", Priority.NORMAL, 0.6, 0.85, 0.7,
                    "Motori servizi ausiliari",
                    "Compressori, ventilatori"
                ),
                BTLoadDistribution(
                    "HVAC Principale", LoadType.HVAC, 50, 72,
                    "Tmax-T5", Priority.NORMAL, 0.8, 0.85, 0.9,
                    "Climatizzazione stabilimento",
                    "Controllo automatico temperatura"
                ),
                BTLoadDistribution(
                    "Illuminazione Emergenza", LoadType.EMERGENCY, 8, 12,
                    "Tmax-T4", Priority.ESSENTIAL, 1.0, 0.9, 1.0,
                    "Illuminazione sicurezza",
                    "Alimentazione da UPS"
                ),
                BTLoadDistribution(
                    "Riserva Futura", LoadType.GENERAL, 50, 72,
                    "Tmax-T5", Priority.NORMAL, 0.0, 0.8, 0.0,
                    "Espansione futura",
                    "Predisposizione ampliamenti"
                )
            ],
            total_power_kw=0,
            total_current_a=0,
            load_factor=0.75,
            power_factor_avg=0.82,
            safety_margin=1.2
        )
        small_industrial.calculate_totals()
        templates["small_industrial_400"] = small_industrial
        
        # ================== MEDIO IMPIANTO INDUSTRIALE ==================
        medium_industrial = LoadDistributionTemplate(
            template_name="Medio Stabilimento 800kVA",
            facility_type=FacilityType.INDUSTRIAL,
            transformer_kva=800,
            description="Media industria con processi automatizzati",
            loads=[
                BTLoadDistribution(
                    "QG - Interruttore Generale", LoadType.GENERAL, 600, 866,
                    "Emax2-E2.2", Priority.ESSENTIAL, 1.0, 0.8, 1.0,
                    "Interruttore generale trasformatore"
                ),
                BTLoadDistribution(
                    "Illuminazione Produzione", LoadType.LIGHTING, 60, 87,
                    "Tmax-T5", Priority.PRIORITY, 0.8, 0.9, 1.0,
                    "Illuminazione capannoni produzione"
                ),
                BTLoadDistribution(
                    "Illuminazione Uffici/Servizi", LoadType.LIGHTING, 25, 36,
                    "Tmax-T4", Priority.NORMAL, 0.7, 0.9, 0.8,
                    "Illuminazione zone terziarie"
                ),
                BTLoadDistribution(
                    "Prese Produzione", LoadType.OUTLETS, 80, 115,
                    "Tmax-T6", Priority.NORMAL, 0.5, 0.8, 0.6,
                    "Prese area produzione e laboratori"
                ),
                BTLoadDistribution(
                    "Prese Uffici", LoadType.OUTLETS, 35, 51,
                    "Tmax-T5", Priority.NORMAL, 0.4, 0.8, 0.5,
                    "Prese zone uffici e servizi"
                ),
                BTLoadDistribution(
                    "Motori Linea Produzione A", LoadType.MOTORS, 150, 217,
                    "Tmax-T7", Priority.PRIORITY, 0.7, 0.85, 0.8,
                    "Linea produzione principale automatizzata"
                ),
                BTLoadDistribution(
                    "Motori Linea Produzione B", LoadType.MOTORS, 120, 173,
                    "Tmax-T6", Priority.PRIORITY, 0.7, 0.85, 0.8,
                    "Linea produzione secondaria"
                ),
                BTLoadDistribution(
                    "Motori Servizi", LoadType.MOTORS, 60, 87,
                    "Tmax-T5", Priority.NORMAL, 0.6, 0.85, 0.7,
                    "Compressori, pompe, ventilatori"
                ),
                BTLoadDistribution(
                    "HVAC Produzione", LoadType.HVAC, 100, 144,
                    "Tmax-T6", Priority.NORMAL, 0.8, 0.85, 0.9,
                    "Climatizzazione aree produzione"
                ),
                BTLoadDistribution(
                    "HVAC Uffici", LoadType.HVAC, 40, 58,
                    "Tmax-T5", Priority.NORMAL, 0.8, 0.85, 0.9,
                    "Climatizzazione zone uffici"
                ),
                BTLoadDistribution(
                    "UPS/Emergenza", LoadType.UPS, 30, 43,
                    "Tmax-T5", Priority.ESSENTIAL, 1.0, 1.0, 1.0,
                    "Sistemi critici e sicurezza"
                ),
                BTLoadDistribution(
                    "Illuminazione Emergenza", LoadType.EMERGENCY, 15, 22,
                    "Tmax-T4", Priority.ESSENTIAL, 1.0, 0.9, 1.0,
                    "Illuminazione sicurezza completa"
                ),
                BTLoadDistribution(
                    "Servizi Ausiliari", LoadType.GENERAL, 40, 58,
                    "Tmax-T5", Priority.NORMAL, 0.7, 0.8, 0.8,
                    "Mensa, spogliatoi, servizi"
                ),
                BTLoadDistribution(
                    "Riserva 1", LoadType.GENERAL, 50, 72,
                    "Tmax-T5", Priority.NORMAL, 0.0, 0.8, 0.0,
                    "Espansione futura zona A"
                ),
                BTLoadDistribution(
                    "Riserva 2", LoadType.GENERAL, 50, 72,
                    "Tmax-T5", Priority.NORMAL, 0.0, 0.8, 0.0,
                    "Espansione futura zona B"
                )
            ],
            total_power_kw=0,
            total_current_a=0,
            load_factor=0.78,
            power_factor_avg=0.84,
            safety_margin=1.2
        )
        medium_industrial.calculate_totals()
        templates["medium_industrial_800"] = medium_industrial
        
        # ================== CENTRO COMMERCIALE ==================
        commercial_center = LoadDistributionTemplate(
            template_name="Centro Commerciale 1000kVA",
            facility_type=FacilityType.COMMERCIAL,
            transformer_kva=1000,
            description="Centro commerciale medio-grande",
            loads=[
                BTLoadDistribution(
                    "QG - Interruttore Generale", LoadType.GENERAL, 750, 1083,
                    "Emax2-E2.2", Priority.ESSENTIAL, 1.0, 0.8, 1.0,
                    "Interruttore generale edificio"
                ),
                BTLoadDistribution(
                    "Illuminazione Negozi", LoadType.LIGHTING, 150, 217,
                    "Tmax-T7", Priority.PRIORITY, 0.9, 0.9, 1.0,
                    "Illuminazione aree vendita"
                ),
                BTLoadDistribution(
                    "Illuminazione Comuni", LoadType.LIGHTING, 80, 115,
                    "Tmax-T6", Priority.PRIORITY, 0.8, 0.9, 1.0,
                    "Corridoi, atri, servizi comuni"
                ),
                BTLoadDistribution(
                    "Prese Negozi", LoadType.OUTLETS, 200, 289,
                    "Tmax-T7", Priority.NORMAL, 0.6, 0.8, 0.7,
                    "Alimentazione attrezzature negozi"
                ),
                BTLoadDistribution(
                    "Prese Servizi", LoadType.OUTLETS, 50, 72,
                    "Tmax-T5", Priority.NORMAL, 0.5, 0.8, 0.6,
                    "Pulizie, manutenzione, uffici"
                ),
                BTLoadDistribution(
                    "HVAC Negozi", LoadType.HVAC, 180, 260,
                    "Tmax-T7", Priority.NORMAL, 0.85, 0.85, 0.9,
                    "Climatizzazione aree vendita"
                ),
                BTLoadDistribution(
                    "HVAC Comuni", LoadType.HVAC, 100, 144,
                    "Tmax-T6", Priority.NORMAL, 0.8, 0.85, 0.9,
                    "Climatizzazione aree comuni"
                ),
                BTLoadDistribution(
                    "Ascensori", LoadType.MOTORS, 60, 87,
                    "Tmax-T5", Priority.PRIORITY, 0.3, 0.85, 0.4,
                    "Ascensori e montacarichi"
                ),
                BTLoadDistribution(
                    "Scale Mobili", LoadType.MOTORS, 40, 58,
                    "Tmax-T5", Priority.NORMAL, 0.8, 0.85, 0.9,
                    "Scale mobili e tappeti"
                ),
                BTLoadDistribution(
                    "Illuminazione Emergenza", LoadType.EMERGENCY, 30, 43,
                    "Tmax-T5", Priority.ESSENTIAL, 1.0, 0.9, 1.0,
                    "Vie di fuga e sicurezza"
                ),
                BTLoadDistribution(
                    "UPS Sicurezza", LoadType.UPS, 25, 36,
                    "Tmax-T4", Priority.ESSENTIAL, 1.0, 1.0, 1.0,
                    "Sistemi antincendio e sicurezza"
                ),
                BTLoadDistribution(
                    "Riserva Commerciale", LoadType.GENERAL, 100, 144,
                    "Tmax-T6", Priority.NORMAL, 0.0, 0.8, 0.0,
                    "Espansione futura"
                )
            ],
            total_power_kw=0,
            total_current_a=0,
            load_factor=0.75,
            power_factor_avg=0.85,
            safety_margin=1.15
        )
        commercial_center.calculate_totals()
        templates["commercial_1000"] = commercial_center
        
        # ================== EDIFICIO UFFICI ==================
        office_building = LoadDistributionTemplate(
            template_name="Edificio Uffici 600kVA",
            facility_type=FacilityType.OFFICE,
            transformer_kva=600,
            description="Edificio uffici medio-grande",
            loads=[
                BTLoadDistribution(
                    "QG - Interruttore Generale", LoadType.GENERAL, 450, 650,
                    "Emax2-E1.2", Priority.ESSENTIAL, 1.0, 0.8, 1.0,
                    "Interruttore generale edificio"
                ),
                BTLoadDistribution(
                    "Illuminazione Uffici", LoadType.LIGHTING, 80, 115,
                    "Tmax-T6", Priority.PRIORITY, 0.8, 0.9, 0.9,
                    "Illuminazione postazioni lavoro"
                ),
                BTLoadDistribution(
                    "Illuminazione Comuni", LoadType.LIGHTING, 40, 58,
                    "Tmax-T5", Priority.PRIORITY, 0.7, 0.9, 0.8,
                    "Corridoi, atri, sale riunioni"
                ),
                BTLoadDistribution(
                    "Prese Uffici", LoadType.OUTLETS, 120, 173,
                    "Tmax-T6", Priority.NORMAL, 0.6, 0.8, 0.7,
                    "PC, stampanti, attrezzature ufficio"
                ),
                BTLoadDistribution(
                    "Prese Servizi", LoadType.OUTLETS, 30, 43,
                    "Tmax-T5", Priority.NORMAL, 0.4, 0.8, 0.5,
                    "Pulizie, manutenzione"
                ),
                BTLoadDistribution(
                    "HVAC Piano Terra", LoadType.HVAC, 60, 87,
                    "Tmax-T5", Priority.NORMAL, 0.85, 0.85, 0.9,
                    "Climatizzazione piano terra"
                ),
                BTLoadDistribution(
                    "HVAC Piani Superiori", LoadType.HVAC, 100, 144,
                    "Tmax-T6", Priority.NORMAL, 0.8, 0.85, 0.9,
                    "Climatizzazione piani 1-4"
                ),
                BTLoadDistribution(
                    "Ascensori", LoadType.MOTORS, 40, 58,
                    "Tmax-T5", Priority.PRIORITY, 0.4, 0.85, 0.5,
                    "Ascensori persone e montacarichi"
                ),
                BTLoadDistribution(
                    "UPS IT", LoadType.UPS, 50, 72,
                    "Tmax-T5", Priority.ESSENTIAL, 1.0, 1.0, 1.0,
                    "Server room e sistemi IT"
                ),
                BTLoadDistribution(
                    "Illuminazione Emergenza", LoadType.EMERGENCY, 20, 29,
                    "Tmax-T4", Priority.ESSENTIAL, 1.0, 0.9, 1.0,
                    "Vie di fuga e sicurezza"
                ),
                BTLoadDistribution(
                    "Riserva", LoadType.GENERAL, 40, 58,
                    "Tmax-T5", Priority.NORMAL, 0.0, 0.8, 0.0,
                    "Espansione futura"
                )
            ],
            total_power_kw=0,
            total_current_a=0,
            load_factor=0.70,
            power_factor_avg=0.85,
            safety_margin=1.2
        )
        office_building.calculate_totals()
        templates["office_600"] = office_building
        
        return templates
    
    def get_template_by_facility(self, facility_type: FacilityType, 
                               transformer_kva: float) -> Optional[LoadDistributionTemplate]:
        """Seleziona template più adatto per tipo impianto e potenza"""
        
        # Mapping potenza -> template
        template_mapping = {
            FacilityType.INDUSTRIAL: {
                (0, 500): "small_industrial_400",
                (500, 1000): "medium_industrial_800"
            },
            FacilityType.COMMERCIAL: {
                (0, 1200): "commercial_1000"
            },
            FacilityType.OFFICE: {
                (0, 800): "office_600"
            }
        }
        
        facility_templates = template_mapping.get(facility_type, {})
        
        for (min_kva, max_kva), template_key in facility_templates.items():
            if min_kva <= transformer_kva <= max_kva:
                return self.templates[template_key]
        
        return None
    
    def scale_template_to_power(self, template: LoadDistributionTemplate, 
                              target_kva: float) -> LoadDistributionTemplate:
        """Scala template per potenza trasformatore target"""
        
        scale_factor = target_kva / template.transformer_kva
        
        scaled_loads = []
        for load in template.loads:
            scaled_load = BTLoadDistribution(
                load_name=load.load_name,
                load_type=load.load_type,
                power_kw=load.power_kw * scale_factor,
                current_a=load.current_a * scale_factor,
                protection_required=load.protection_required,  # Da ricalcolare
                priority=load.priority,
                diversity_factor=load.diversity_factor,
                power_factor=load.power_factor,
                utilization_factor=load.utilization_factor,
                description=load.description,
                installation_notes=load.installation_notes
            )
            scaled_loads.append(scaled_load)
        
        scaled_template = LoadDistributionTemplate(
            template_name=f"{template.template_name} (Scalato {target_kva}kVA)",
            facility_type=template.facility_type,
            transformer_kva=int(target_kva),
            description=f"{template.description} - Scalato per {target_kva}kVA",
            loads=scaled_loads,
            total_power_kw=0,
            total_current_a=0,
            load_factor=template.load_factor,
            power_factor_avg=template.power_factor_avg,
            safety_margin=template.safety_margin
        )
        
        scaled_template.calculate_totals()
        return scaled_template
    
    def get_load_summary_by_type(self, template: LoadDistributionTemplate) -> Dict:
        """Riassunto carichi per tipologia"""
        
        summary = {}
        for load_type in LoadType:
            type_loads = [load for load in template.loads if load.load_type == load_type]
            
            if type_loads:
                total_power = sum(load.power_kw * load.diversity_factor for load in type_loads)
                total_current = sum(load.current_a * load.diversity_factor for load in type_loads)
                
                summary[load_type.value] = {
                    "count": len(type_loads),
                    "total_power_kw": total_power,
                    "total_current_a": total_current,
                    "percentage": (total_power / template.total_power_kw * 100) if template.total_power_kw > 0 else 0
                }
        
        return summary

# ===============================================================================
# ISTANZA GLOBALE
# ===============================================================================

bt_load_db = BTLoadDistributionDatabase()

# Export
__all__ = [
    'BTLoadDistribution',
    'LoadDistributionTemplate',
    'LoadType',
    'Priority',
    'FacilityType',
    'BTLoadDistributionDatabase',
    'bt_load_db'
]
