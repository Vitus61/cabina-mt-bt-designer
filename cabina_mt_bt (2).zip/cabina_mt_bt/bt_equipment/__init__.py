"""
BT Equipment Package - Componenti Bassa Tensione ABB
Moduli per configurazione quadri BT integrati con UniSec MT

Moduli disponibili:
- artu: Configuratore quadri ArTu L e M
- breakers: Database interruttori Emax 2 + Tmax
- switches: Database sezionatori OTM + OS
- distribution: Template distribuzione carichi
- selectivity: Regole selettività avanzate
"""

# ArTu system
from .artu import (
    ArTuConfigurator,
    ArTuConfiguration,
    ArTuPackage, 
    ArTuFeeder,
    ArTuSeries,
    BTLoadType,
    get_artu_for_unisec,
    get_artu_summary,
    artu_configurator
)

# Breakers database
from .breakers import (
    BTBreakerSpec,
    BreakerType,
    ProtectionClass,
    BTBreakerDatabase,
    bt_breaker_db
)

# Switches database
from .switches import (
    BTSwitchSpec,
    SwitchType,
    SwitchApplication,
    BTSwitchDatabase,
    bt_switch_db
)

# Load distribution templates
from .distribution import (
    BTLoadDistribution,
    LoadDistributionTemplate,
    LoadType,
    Priority,
    FacilityType,
    BTLoadDistributionDatabase,
    bt_load_db
)

# Selectivity system with ABB Integration
from .selectivity import (
    SelectivityRule,
    ProtectionSettings,
    SelectivityType,
    ProtectionLevel,
    BTSelectivityABBIntegrated,
    bt_selectivity_abb,
    ABB_DATABASE_AVAILABLE
)

# Alias per compatibilità
BTSelectivityDatabase = BTSelectivityABBIntegrated
bt_selectivity_db = bt_selectivity_abb

__all__ = [
    # ArTu module
    'ArTuConfigurator',
    'ArTuConfiguration',
    'ArTuPackage',
    'ArTuFeeder', 
    'ArTuSeries',
    'BTLoadType',
    'get_artu_for_unisec',
    'get_artu_summary',
    'artu_configurator',
    
    # Breakers
    'BTBreakerSpec',
    'BreakerType', 
    'ProtectionClass',
    'BTBreakerDatabase',
    'bt_breaker_db',
    
    # Switches
    'BTSwitchSpec',
    'SwitchType',
    'SwitchApplication', 
    'BTSwitchDatabase',
    'bt_switch_db',
    
    # Load distribution
    'BTLoadDistribution',
    'LoadDistributionTemplate',
    'LoadType',
    'Priority',
    'FacilityType',
    'BTLoadDistributionDatabase',
    'bt_load_db',
    
    # Selectivity with ABB Integration
    'SelectivityRule',
    'ProtectionSettings',
    'SelectivityType',
    'ProtectionLevel',
    'BTSelectivityABBIntegrated',
    'BTSelectivityDatabase',  # Alias per compatibilità
    'bt_selectivity_abb',
    'bt_selectivity_db',      # Alias per compatibilità
    'ABB_DATABASE_AVAILABLE'
]

__version__ = "1.0.0"
__author__ = "Software Cabina MT/BT Professional"
