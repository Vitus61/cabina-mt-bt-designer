"""
Sistema di Protezioni Cabina MT/BT
Moduli per coordinamento protezioni avanzato
"""

from .mt_protections import MTProtectionManager
from .bt_selectivity import BTSelectivityManager, ABBPatchSystem  
from .coordination import MTBTCoordinator
from .validation import ProtectionValidator
from .display_utils import ProtectionDisplayManager

# Classe orchestratrice principale
class ProtectionSystemManager:
    """Orchestratore principale per sistema protezioni Step 5"""
    
    def __init__(self):
        self.mt_manager = MTProtectionManager()
        self.bt_manager = BTSelectivityManager()
        self.coordinator = MTBTCoordinator()
        self.validator = ProtectionValidator()
        self.display = ProtectionDisplayManager()
        self.patch_system = ABBPatchSystem()
    
    def process_step_5(self, distributor_data, transformer_config, mt_design):
        """Processo completo Step 5 semplificato"""
        
        # 1. Calcoli base
        calculations = self._prepare_calculations(transformer_config)
        
        # 2. Sistema patch preventivo
        if self.patch_system.needs_patch(calculations['current_transformer_bt']):
            self.patch_system.apply_patch()
        
        # 3. Protezioni MT
        mt_settings = self.mt_manager.configure_protections(distributor_data)
        
        # 4. Sistema ABB BT
        bt_results = self.bt_manager.process_bt_selectivity(
            calculations['current_transformer_bt'],
            calculations['project_requirements']
        )
        
        # 5. Coordinamento
        coordination = self.coordinator.verify_coordination(
            mt_settings, calculations['current_transformer_bt']
        )
        
        # 6. Validazione finale
        validation = self.validator.validate_complete_system()
        
        return {
            'mt_settings': mt_settings,
            'bt_results': bt_results,
            'coordination': coordination,
            'validation': validation,
            'calculations': calculations
        }
    
    def display_results(self, results):
        """Visualizza risultati in Streamlit"""
        self.display.show_project_data(results['calculations'])
        self.display.show_mt_protections(results['mt_settings'])
        self.display.show_bt_selectivity(results['bt_results'])
        self.display.show_coordination(results['coordination'])
        self.display.show_validation(results['validation'])
    
    def _prepare_calculations(self, transformer_config):
        """Calcoli preliminari"""
        total_kva = transformer_config.get('total_power', 800)
        current_transformer_bt = (total_kva * 1000) / (415 * 1.732)
        
        return {
            'total_kva': total_kva,
            'current_transformer_bt': current_transformer_bt,
            'project_requirements': self._analyze_requirements(total_kva, current_transformer_bt)
        }
    
    def _analyze_requirements(self, total_kva, current_bt):
        """Analisi requisiti progetto"""
        return {
            'total_kva': total_kva,
            'current_bt': current_bt,
            'fault_currents': [int(current_bt * f) for f in [2, 5, 10, 15, 20]],
            'service_level': 'standard',
            'coordination_type': 'energy_selective'
        }

__all__ = [
    'ProtectionSystemManager',
    'MTProtectionManager', 
    'BTSelectivityManager',
    'MTBTCoordinator',
    'ProtectionValidator',
    'ProtectionDisplayManager',
    'ABBPatchSystem'
]
