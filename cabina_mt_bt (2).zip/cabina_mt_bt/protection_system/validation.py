"""
Validazione sistema protezioni
"""

import streamlit as st

class ProtectionValidator:
    """Validatore completo sistema protezioni"""
    
    def validate_complete_system(self):
        """Validazione completa del sistema di protezione"""
        
        validation = {
            'valid': True,
            'issues': [],
            'score': 100,
            'recommendations': []
        }
        
        # Verifica dati disponibili
        if not st.session_state.get('abb_selectivity_study'):
            validation['valid'] = False
            validation['issues'].append("Studio selettività BT non completato")
            validation['score'] -= 30
        
        # Verifica percentuale selettività
        abb_study = st.session_state.get('abb_selectivity_study', {})
        selectivity_percentage = abb_study.get('percentage', 0)
        
        if selectivity_percentage < 85:
            validation['issues'].append(
                f"Selettività BT sotto soglia minima ({selectivity_percentage:.1f}% < 85%)"
            )
            validation['score'] -= 20
        elif selectivity_percentage < 90:
            validation['recommendations'].append("Considerare ottimizzazioni per selettività >90%")
            validation['score'] -= 5
        
        # Verifica sistema avanzato
        if abb_study.get('advanced_system_used', False):
            validation['recommendations'].append(
                "Sistema ABB Emax 2 avanzato attivo - Prestazioni ottimali"
            )
            validation['score'] += 10
        
        return validation
    
    def display_required_optimizations(self, issues):
        """Mostra ottimizzazioni richieste"""
        st.error("**🔧 Ottimizzazioni Richieste:**")
        
        for i, issue in enumerate(issues, 1):
            st.error(f"{i}. {issue}")
        
        st.info("💡 Rivedere configurazioni e ripetere il calcolo")
