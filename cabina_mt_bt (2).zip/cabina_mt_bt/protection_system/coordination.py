"""
Coordinamento MT-BT e validazione sistema protezioni - NORMATIVA CEI CORRETTA
"""

import streamlit as st

class MTBTCoordinator:
    """Gestisce coordinamento tra protezioni MT e BT secondo CEI 0-16"""
    
    def verify_coordination(self, mt_settings, current_bt):
        """Verifica coordinamento MT-BT avanzato"""
        
        st.subheader("🔄 3. Coordinamento MT-BT Avanzato")
        
        analysis = self._perform_coordination_analysis(mt_settings, current_bt)
        self._display_coordination_results(analysis)
        
        return analysis
    
    def _perform_coordination_analysis(self, mt_settings, current_bt):
        """Analisi coordinamento MT-BT con logica CEI 0-16 CORRETTA"""
        
        analysis = {
            'temporal_coordination': True,
            'current_coordination': True,
            'energy_coordination': True,
            'issues': [],
            'recommendations': [],
            'overall_result': 'optimal'
        }
        
        # ✅ CORREZIONE NORMATIVA: Margini temporali secondo CEI 0-16
        mt_time = mt_settings.get('t_2', 0.4)
        
        # Verifica se sistema ABB ottimizzato per tempi più precisi
        is_abb_system = st.session_state.get('mt_final_design', {}).get('design_type') == 'abb_automatic'
        
        # 🎯 MARGINI SECONDO NORMATIVA CEI 0-16
        if is_abb_system:
            # Sistema ABB con relè digitali: margine minimo 120ms (CEI)
            bt_time_estimated = 0.12  # Tempo ottimizzato ABB Emax 2
            required_margin_ms = 150  # 150ms per sistema ABB digitale
        else:
            # Sistema standard: margine raccomandato 200ms (CEI)
            bt_time_estimated = 0.15  # Tempo standard
            required_margin_ms = 200  # 200ms per sistema standard
        
        required_margin = required_margin_ms / 1000  # Conversione in secondi
        time_margin_ms = (mt_time - bt_time_estimated) * 1000  # Margine in ms
        
        # 📋 VERIFICA CONFORMITÀ CEI 0-16
        if time_margin_ms < required_margin_ms:
            analysis['temporal_coordination'] = False
            analysis['issues'].append(
                f"Margine temporale non conforme CEI 0-16: {time_margin_ms:.0f}ms < {required_margin_ms}ms richiesti"
            )
            
            # Calcolo tempo MT conforme
            optimal_mt_time = bt_time_estimated + (required_margin_ms + 50) / 1000  # +50ms sicurezza
            analysis['recommendations'].append(
                f"Aumentare tempo MT a {optimal_mt_time:.2f}s per conformità CEI 0-16"
            )
            
            # Raccomandazione specifica per il tipo di sistema
            if is_abb_system:
                analysis['recommendations'].append(
                    "Sistema ABB: utilizzare margine minimo 150ms per relè digitali"
                )
            else:
                analysis['recommendations'].append(
                    "Sistema standard: utilizzare margine raccomandato 200ms CEI"
                )
        else:
            # Coordinamento temporale conforme
            conformity_level = "conforme" if time_margin_ms >= required_margin_ms else "al limite"
            analysis['recommendations'].append(
                f"Coordinamento temporale {conformity_level}: margine {time_margin_ms:.0f}ms ≥ {required_margin_ms}ms CEI"
            )
        
        # ✅ COORDINAMENTO AMPEROMETRICO SECONDO CEI 0-16
        mt_current = mt_settings.get('I_2', 250)
        
        # Calcolo corrente BT riferita al primario
        transformer_config = st.session_state.get('transformer_config', {})
        voltage_ratio = st.session_state.get('distributor_data', {}).get('voltage_kv', 20) / 0.4
        bt_current_primary = current_bt / voltage_ratio
        
        # 🎯 MARGINI AMPEROMETRICI SECONDO CEI 0-16
        # CEI raccomanda: protezioni indirette 15-20%, protezioni dirette 20-25%
        if is_abb_system:
            required_ratio = 1.2   # 20% margine per sistema ABB ottimizzato (CEI minimo)
            margin_type = "CEI minimo (20%)"
        else:
            required_ratio = 1.25  # 25% margine per sistema standard (CEI raccomandato)
            margin_type = "CEI raccomandato (25%)"
        
        actual_ratio = mt_current / bt_current_primary if bt_current_primary > 0 else 999
        margin_percentage = (actual_ratio - 1) * 100
        
        if actual_ratio < required_ratio:
            analysis['current_coordination'] = False
            required_percentage = (required_ratio - 1) * 100
            analysis['issues'].append(
                f"Margine amperometrico non conforme CEI: {margin_percentage:.1f}% < {required_percentage:.1f}% richiesto"
            )
            optimal_mt_current = int(bt_current_primary * required_ratio * 1.05)  # +5% sicurezza
            analysis['recommendations'].append(
                f"Aumentare I2 MT a {optimal_mt_current}A per {margin_type}"
            )
        else:
            # Coordinamento amperometrico conforme
            analysis['recommendations'].append(
                f"Coordinamento amperometrico conforme CEI: margine {margin_percentage:.1f}% ≥ {margin_type}"
            )
        
        # ✅ COORDINAMENTO ENERGETICO I²t 
        if is_abb_system or st.session_state.get('abb_system_used', False):
            i2t_coordination = self._verify_i2t_coordination_cei(mt_settings, current_bt, bt_current_primary)
            analysis['energy_coordination'] = i2t_coordination
            
            if not i2t_coordination:
                analysis['issues'].append("Coordinamento I²t non ottimale secondo CEI")
                analysis['recommendations'].append("Verificare coordinamento energetico con valori I²t reali")
            else:
                analysis['recommendations'].append("Coordinamento I²t verificato secondo CEI")
        
        # ✅ VALUTAZIONE COMPLESSIVA SECONDO CEI 0-16
        failed_coordinations = sum([
            not analysis['temporal_coordination'],
            not analysis['current_coordination'],
            not analysis['energy_coordination']
        ])
        
        if failed_coordinations == 0:
            analysis['overall_result'] = 'cei_compliant'
            analysis['coordination_quality'] = 'excellent'
        elif failed_coordinations == 1:
            if time_margin_ms >= (required_margin_ms * 0.9):  # Tolleranza 10%
                analysis['overall_result'] = 'acceptable_with_reserves'
                analysis['coordination_quality'] = 'good'
                analysis['recommendations'].append("Sistema accettabile con riserve secondo CEI 0-16")
            else:
                analysis['overall_result'] = 'needs_cei_compliance'
                analysis['coordination_quality'] = 'poor'
        else:
            analysis['overall_result'] = 'non_compliant'
            analysis['coordination_quality'] = 'poor'
        
        # Informazioni dettagliate per diagnosi
        analysis['debug_info'] = {
            'mt_time': mt_time,
            'bt_time_estimated': bt_time_estimated,
            'time_margin_ms': time_margin_ms,
            'required_margin_ms': required_margin_ms,
            'mt_current': mt_current,
            'bt_current_primary': bt_current_primary,
            'current_ratio': actual_ratio,
            'margin_percentage': margin_percentage,
            'is_abb_system': is_abb_system,
            'failed_coordinations': failed_coordinations,
            'cei_compliance_level': analysis['overall_result']
        }
        
        return analysis
    
    def _verify_i2t_coordination_cei(self, mt_settings, current_bt, bt_current_primary):
        """Verifica coordinamento I²t secondo principi CEI"""
        try:
            mt_current = mt_settings.get('I_2', 250)
            mt_time = mt_settings.get('t_2', 0.4)
            
            # I²t MT (protezione di monte)
            mt_i2t = (mt_current ** 2) * mt_time
            
            # I²t BT stimato (protezione di valle)
            bt_time_estimated = 0.12  # Tempo ABB Emax ottimizzato
            bt_i2t = (bt_current_primary ** 2) * bt_time_estimated
            
            # Coordinamento I²t secondo CEI: monte > valle con margine 25%
            coordination_margin = 1.25  # 25% margine CEI
            coordination_ok = mt_i2t > bt_i2t * coordination_margin
            
            return coordination_ok
            
        except Exception as e:
            st.warning(f"Calcolo I²t fallito: {e}")
            return True
    
    def _display_coordination_results(self, analysis):
        """Visualizza risultati coordinamento con riferimenti normativi CEI"""
        
        st.info("""
        **📖 Verifica coordinamento secondo CEI 0-16:**
        
        🔴 **Protezione MT (DG):** Backup selettivo con rete distributore
        🔵 **Protezione BT (Interruttore Generale):** Protezione primaria trasformatore
        ⚙️ **Coordinamento:** Margini temporali e amperometrici conformi a normativa CEI
        """)
        
        col1, col2, col3 = st.columns(3)
        
        debug_info = analysis.get('debug_info', {})
        
        with col1:
            status = "✅" if analysis['temporal_coordination'] else "❌"
            time_margin_ms = debug_info.get('time_margin_ms', 0)
            required_margin_ms = debug_info.get('required_margin_ms', 200)
            help_text = f"Margine: {time_margin_ms:.0f}ms (min: {required_margin_ms}ms CEI)"
            st.metric("Coordinamento Temporale CEI", f"{status}", help=help_text)
        
        with col2:
            status = "✅" if analysis['current_coordination'] else "❌"
            margin_percentage = debug_info.get('margin_percentage', 0)
            help_text = f"Margine amperometrico: {margin_percentage:.1f}%"
            st.metric("Coordinamento Corrente CEI", f"{status}", help=help_text)
        
        with col3:
            quality_emoji = {"excellent": "🏆", "good": "✅", "poor": "⚠️"}
            emoji = quality_emoji.get(analysis['coordination_quality'], "ℹ️")
            quality_text = analysis['coordination_quality'].title()
            st.metric("Conformità CEI 0-16", f"{emoji} {quality_text}")
        
        # Status finale con riferimenti normativi
        overall_result = analysis['overall_result']
        
        if overall_result == 'cei_compliant':
            st.success("✅ **COORDINAMENTO CONFORME CEI 0-16** - Sistema completamente validato")
        elif overall_result == 'acceptable_with_reserves':
            st.warning("⚠️ **SISTEMA ACCETTABILE CON RISERVE** - Margini al limite CEI 0-16")
        elif overall_result == 'needs_cei_compliance':
            st.error("❌ **RICHIESTA CONFORMITÀ CEI 0-16** - Modifiche necessarie")
        else:
            st.error("❌ **NON CONFORME CEI 0-16** - Revisione completa richiesta")
        
        # Mostra raccomandazioni con priorità CEI
        if analysis['recommendations']:
            positive_recs = [r for r in analysis['recommendations'] if 'conforme' in r.lower()]
            cei_issues = [r for r in analysis['recommendations'] if 'cei' in r.lower() and r not in positive_recs]
            other_recs = [r for r in analysis['recommendations'] if r not in positive_recs and r not in cei_issues]
            
            if positive_recs:
                st.success("**✅ Conformità CEI 0-16:**")
                for rec in positive_recs:
                    st.success(f"• {rec}")
            
            if cei_issues:
                st.error("**📖 Raccomandazioni CEI 0-16:**")
                for rec in cei_issues:
                    st.error(f"• {rec}")
            
            if other_recs:
                st.info("**💡 Ottimizzazioni Consigliate:**")
                for rec in other_recs:
                    st.info(f"• {rec}")
        
        # Problemi con priorità normativa
        if analysis['issues']:
            st.error("**❌ Non Conformità CEI 0-16 Rilevate:**")
            for issue in analysis['issues']:
                st.error(f"• {issue}")
        
        # Informazioni tecniche dettagliate
        with st.expander("📖 Analisi Dettagliata CEI 0-16", expanded=False):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**⏱️ Analisi Temporale:**")
                st.write(f"• Tempo MT (t2): {debug_info.get('mt_time', 'N/A')}s")
                st.write(f"• Tempo BT stimato: {debug_info.get('bt_time_estimated', 'N/A')}s") 
                st.write(f"• Margine attuale: {debug_info.get('time_margin_ms', 0):.0f}ms")
                st.write(f"• Margine CEI richiesto: {debug_info.get('required_margin_ms', 200):.0f}ms")
                
                margin_status = "✅ Conforme" if debug_info.get('time_margin_ms', 0) >= debug_info.get('required_margin_ms', 200) else "❌ Non conforme"
                st.write(f"• **Status CEI**: {margin_status}")
                
            with col2:
                st.markdown("**⚡ Analisi Amperometrica:**")
                st.write(f"• Corrente MT (I2): {debug_info.get('mt_current', 'N/A')}A")
                st.write(f"• Corrente BT primaria: {debug_info.get('bt_current_primary', 'N/A'):.1f}A")
                st.write(f"• Ratio attuale: {debug_info.get('current_ratio', 'N/A'):.2f}")
                st.write(f"• Margine percentuale: {debug_info.get('margin_percentage', 0):.1f}%")
                
                cei_requirement = "20% (ABB)" if debug_info.get('is_abb_system') else "25% (Standard)"
                st.write(f"• **Requisito CEI**: {cei_requirement}")
            
            st.markdown(f"**🎯 Livello Conformità CEI:** {debug_info.get('cei_compliance_level', 'N/A')}")


class ProtectionValidator:
    """Validatore completo sistema protezioni secondo CEI 0-16"""
    
    def validate_complete_system(self):
        """Validazione completa del sistema di protezione"""
        
        validation = {
            'valid': True,
            'issues': [],
            'score': 100,
            'recommendations': []
        }
        
        is_abb_system = st.session_state.get('mt_final_design', {}).get('design_type') == 'abb_automatic'
        
        # Verifica studio selettività secondo CEI
        abb_study = st.session_state.get('abb_selectivity_study', {})
        if not abb_study:
            validation['issues'].append("Studio selettività richiesto da CEI 0-16")
            validation['score'] -= 25
        
        # Verifica percentuale selettività
        selectivity_percentage = abb_study.get('selectivity_percentage', 0)
        
        # CEI 0-16 non impone percentuali specifiche ma raccomanda coordinamento ottimale
        if selectivity_percentage >= 90:
            validation['recommendations'].append(f"Selettività eccellente: {selectivity_percentage:.1f}%")
            validation['score'] += 10
        elif selectivity_percentage >= 80:
            validation['recommendations'].append(f"Selettività buona: {selectivity_percentage:.1f}%")
        elif selectivity_percentage >= 70:
            validation['issues'].append(f"Selettività migliorabile: {selectivity_percentage:.1f}%")
            validation['score'] -= 15
        else:
            validation['issues'].append(f"Selettività insufficiente: {selectivity_percentage:.1f}%")
            validation['score'] -= 30
        
        # Sistema considerato valido se conforme CEI (score >= 75)
        if validation['score'] < 75:
            validation['valid'] = False
            validation['issues'].append("Sistema non conforme requisiti CEI 0-16")
        
        return validation
    
    def display_required_optimizations(self, issues):
        """Mostra ottimizzazioni richieste secondo CEI"""
        st.error("**🔧 Modifiche Richieste per Conformità CEI 0-16:**")
        
        for i, issue in enumerate(issues, 1):
            st.error(f"{i}. {issue}")
        
        st.info("💡 Consultare CEI 0-16 Art. 7 per dettagli sul coordinamento protezioni")
