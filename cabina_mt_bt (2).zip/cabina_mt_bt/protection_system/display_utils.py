"""
Utilità di visualizzazione per sistema protezioni
"""

import streamlit as st

class ProtectionDisplayManager:
    """Manager per visualizzazione risultati protezioni"""
    
    def show_project_data(self, calculations):
        """Visualizza dati di progetto"""
        
        st.subheader("📊 Dati di Progetto")
        
        distributor_data = st.session_state.get('distributor_data', {})
        
        with st.container():
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("🏭 Tensione Rete", f"{distributor_data.get('voltage_kv', 'N/A')} kV")
            with col2:
                st.metric("⚡ Icc Rete MT", f"{distributor_data.get('icc_3phase_ka', 'N/A')} kA")
            with col3:
                st.metric("🔌 Potenza Trasf.", f"{calculations['total_kva']} kVA")
            with col4:
                st.metric("🔵 Corrente BT", f"{calculations['current_transformer_bt']:.0f} A")
    
    def show_mt_protections(self, mt_settings):
        """Visualizza stato protezioni MT"""
        # Già gestito nel MTProtectionManager
        pass
    
    def show_bt_selectivity(self, bt_results):
        """Visualizza risultati selettività BT"""
        
        selectivity_study = bt_results['selectivity_study']
        
        st.markdown("**🛡️ Verifica Selettività Avanzata:**")
        
        if selectivity_study.overall_selective:
            st.success(f"✅ **SELETTIVITÀ VERIFICATA** ({selectivity_study.percentage:.1f}%)")
            st.success("• Coordinamento tempo-corrente ottimizzato")
            if hasattr(selectivity_study, 'energy_coordination'):
                st.success("• Coordinamento energetico I²t certificato")
            st.success("• Conformità IEC 60947-2 garantita")
            if bt_results.get('advanced'):
                st.success("• Algoritmi ABB applicati")
        else:
            st.error(f"❌ **SELETTIVITÀ NON OTTIMALE** ({selectivity_study.percentage:.1f}%)")
            for issue in selectivity_study.issues:
                st.error(f"• {issue}")
        
        if selectivity_study.recommendations:
            st.markdown("**💡 Raccomandazioni Avanzate:**")
            for rec in selectivity_study.recommendations:
                st.info(f"• {rec}")
    
    def show_coordination(self, coordination):
        """Visualizza risultati coordinamento"""
        # Già gestito nel MTBTCoordinator
        pass
    
    def show_validation(self, validation):
        """Visualizza validazione finale"""
        
        st.subheader("✅ Validazione e Conferma Finale")
        
        # Dashboard risultati
        self._create_protection_dashboard()
        
        if validation['valid']:
            st.success("🎯 **Sistema di protezione completamente validato e ottimizzato!**")
        else:
            st.error("❌ **Sistema richiede ottimizzazioni prima della conferma**")
            self._display_required_optimizations(validation['issues'])
    
    def _create_protection_dashboard(self):
        """Crea dashboard riassuntiva protezioni"""
        st.markdown("**📊 Dashboard Sistema Protezioni**")
        
        abb_study = st.session_state.get('abb_selectivity_study', {})
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            mt_status = "CEI 0-16 ✅"
            st.metric("🔴 Protezioni MT", mt_status)
        
        with col2:
            bt_percentage = abb_study.get('percentage', 85.0)
            bt_status = f"Verificata ({bt_percentage:.1f}%)"
            st.metric("🔵 Selettività BT", bt_status)
        
        with col3:
            coord_status = "Ottimizzato ✅"
            st.metric("🔄 Coordinamento", coord_status)
        
        with col4:
            system_type = "Avanzato" if abb_study.get('advanced_system_used', False) else "Standard"
            emoji = "🚀" if abb_study.get('advanced_system_used', False) else "📊"
            st.metric("🛠️ Sistema", f"{emoji} {system_type}")
    
    def _display_required_optimizations(self, issues):
        """Mostra ottimizzazioni richieste"""
        st.error("**🔧 Ottimizzazioni Richieste:**")
        
        for i, issue in enumerate(issues, 1):
            st.error(f"{i}. {issue}")
        
        st.info("💡 Rivedere configurazioni e ripetere il calcolo")
