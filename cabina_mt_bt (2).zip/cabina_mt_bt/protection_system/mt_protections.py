"""
Gestione Protezioni MT secondo CEI 0-16
"""

import streamlit as st

class MTProtectionManager:
    """Manager per protezioni MT CEI 0-16"""
    
    def configure_protections(self, distributor_data):
        """Configura protezioni MT con interfaccia utente"""
        
        st.subheader("⚡ 1. Configurazione Protezioni MT (CEI 0-16)")
        
        # Calcola limiti da distributore
        earth_fault_limit = int(distributor_data.get('earth_fault_current_a', 20) * 1.4)
        
        # Interfaccia configurazione
        settings = self._create_ui_configuration(earth_fault_limit)
        
        # Verifica conformità
        compliance = self._verify_cei_016_compliance(settings, distributor_data)
        self._display_compliance_results(compliance)
        
        return settings
    
    def _create_ui_configuration(self, earth_fault_limit):
        """Crea interfaccia configurazione protezioni"""
        
        with st.expander("⚙️ Impostazioni Avanzate Protezioni MT", expanded=False):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**🔧 Protezioni di Sovracorrente**")
                i_overload = st.slider("I> Sovraccarico (xIn)", 0.5, 1.2, 0.9, 0.1, help="CEI 0-16: tipicamente 0.9xIn")
                t_overload = st.slider("t> Tempo sovraccarico (s)", 5.0, 20.0, 10.0, 1.0)
                
                i_moderate = st.slider("I>> CC Moderato (A)", 100, 300, 250, 25, help="CEI 0-16: massimo 250A")
                t_moderate = st.slider("t>> Tempo CC moderato (s)", 0.2, 0.6, 0.4, 0.1)
            
            with col2:
                st.markdown("**🌍 Protezioni di Terra**")
                io_sensitive = st.slider("Io> Terra sensibile (A)", 0.5, 3.0, 2.0, 0.5, help="CEI 0-16: massimo 2A")
                to_sensitive = st.slider("to> Tempo terra sens. (s)", 0.2, 0.5, 0.4, 0.1)
                
                io_main = st.slider(f"Io>> Terra principale (A)", 5, earth_fault_limit, 
                                   min(earth_fault_limit-5, 20), 5)
                to_main = st.slider("to>> Tempo terra princ. (s)", 0.05, 0.3, 0.15, 0.05)
        
        return {
            'I_1': i_overload, 't_1': t_overload,
            'I_2': i_moderate, 't_2': t_moderate,
            'I_3': 600, 't_3': 0.05,  # Fissi CEI 0-16
            'Io_1': io_sensitive, 'to_1': to_sensitive,
            'Io_2': io_main, 'to_2': to_main
        }
    
    def _verify_cei_016_compliance(self, settings, distributor_data):
        """Verifica conformità CEI 0-16"""
        issues = []
        
        if settings.get('I_2', 0) > 250:
            issues.append("I>> cortocircuito moderato > 250A (limite CEI 0-16)")
        if settings.get('t_2', 0) > 0.5:
            issues.append("Tempo cortocircuito moderato > 500ms (limite CEI 0-16)")
        if settings.get('I_3', 0) > 600:
            issues.append("I>>> cortocircuito elevato > 600A (limite CEI 0-16)")
        if settings.get('Io_1', 0) > 2:
            issues.append("Io> terra sensibile > 2A (limite CEI 0-16)")
        
        earth_limit = distributor_data.get('earth_fault_current_a', 20) * 1.4
        if settings.get('Io_2', 0) > earth_limit:
            issues.append(f"Io>> terra principale > {earth_limit:.0f}A (limite distributore)")
        
        return {'compliant': len(issues) == 0, 'issues': issues}
    
    def _display_compliance_results(self, compliance):
        """Mostra risultati conformità"""
        if compliance['compliant']:
            st.success("✅ **Impostazioni conformi CEI 0-16**")
        else:
            st.error("❌ **Non conformità CEI 0-16 rilevata**")
            for issue in compliance['issues']:
                st.error(f"• {issue}")
